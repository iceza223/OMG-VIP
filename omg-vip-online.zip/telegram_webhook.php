<?php
declare(strict_types=1);
require_once __DIR__ . '/telegram_lock_config.php';
require_once __DIR__ . '/system/a_func.php';
function tg_api(string $method, array $payload=[]): void {
    $ch=curl_init('https://api.telegram.org/bot'.TELEGRAM_BOT_TOKEN.'/'.$method);
    curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE),CURLOPT_HTTPHEADER=>['Content-Type: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>15]); curl_exec($ch); curl_close($ch);
}
$secret=$_SERVER['HTTP_X_TELEGRAM_BOT_API_SECRET_TOKEN']??'';
if (!hash_equals(TELEGRAM_WEBHOOK_SECRET,(string)$secret)) { http_response_code(403); exit('Forbidden'); }
$update=json_decode((string)file_get_contents('php://input'),true); if (!is_array($update)) { exit('OK'); }
try {
    $from=$update['message']['from']??$update['callback_query']['from']??[]; $chat_id=$update['message']['chat']['id']??$update['callback_query']['message']['chat']['id']??null; $text=(string)($update['message']['text']??'');
    $callback=$update['callback_query']??null;
    if ($callback) {
        $data=(string)($callback['data']??'');
        if ((string)($from['id']??'') === (string)TELEGRAM_ADMIN_ID && in_array($data, ['lock','unlock','status'], true)) {
            if ($data === 'lock') { @file_put_contents(TELEGRAM_LOCK_STATE_FILE, json_encode(['locked'=>true,'updated_at'=>date('c'),'updated_by'=>'telegram:'.TELEGRAM_ADMIN_ID], JSON_UNESCAPED_UNICODE), LOCK_EX); $reply='🔒 ล็อกเว็บไซต์เรียบร้อยแล้ว'; }
            elseif ($data === 'unlock') { @file_put_contents(TELEGRAM_LOCK_STATE_FILE, json_encode(['locked'=>false,'updated_at'=>date('c'),'updated_by'=>'telegram:'.TELEGRAM_ADMIN_ID], JSON_UNESCAPED_UNICODE), LOCK_EX); $reply='🔓 ปลดล็อกเว็บไซต์เรียบร้อยแล้ว'; }
            else { $s=is_file(TELEGRAM_LOCK_STATE_FILE)?json_decode((string)@file_get_contents(TELEGRAM_LOCK_STATE_FILE),true):[]; $reply=!empty($s['locked'])?'สถานะ: 🔒 ล็อกอยู่':'สถานะ: 🔓 เปิดใช้งานอยู่'; }
            tg_api('answerCallbackQuery',['callback_query_id'=>$callback['id'],'text'=>$reply]); tg_api('sendMessage',['chat_id'=>$chat_id,'text'=>$reply]); exit('OK');
        }
        exit('OK');
    }
    if ($chat_id===null || !$from) { exit('OK'); }
    if ((string)($from['id']??'') === (string)TELEGRAM_ADMIN_ID) {
        $reply='เลือกคำสั่ง:'; $cmd=strtolower(trim($text));
        if ($cmd==='/lock') { @file_put_contents(TELEGRAM_LOCK_STATE_FILE,json_encode(['locked'=>true,'updated_at'=>date('c'),'updated_by'=>'telegram:'.TELEGRAM_ADMIN_ID],JSON_UNESCAPED_UNICODE),LOCK_EX); $reply='🔒 ล็อกเว็บไซต์เรียบร้อยแล้ว'; }
        elseif ($cmd==='/unlock') { @file_put_contents(TELEGRAM_LOCK_STATE_FILE,json_encode(['locked'=>false,'updated_at'=>date('c'),'updated_by'=>'telegram:'.TELEGRAM_ADMIN_ID],JSON_UNESCAPED_UNICODE),LOCK_EX); $reply='🔓 ปลดล็อกเว็บไซต์เรียบร้อยแล้ว'; }
        elseif ($cmd==='/status') { $s=is_file(TELEGRAM_LOCK_STATE_FILE)?json_decode((string)@file_get_contents(TELEGRAM_LOCK_STATE_FILE),true):[]; $reply=!empty($s['locked'])?'สถานะ: 🔒 ล็อกอยู่':'สถานะ: 🔓 เปิดใช้งานอยู่'; }
        tg_api('sendMessage',['chat_id'=>$chat_id,'text'=>$reply,'reply_markup'=>['inline_keyboard'=>[[['text'=>'🔒 ล็อกเว็บไซต์','callback_data'=>'lock'],['text'=>'🔓 ปลดล็อก','callback_data'=>'unlock']],[['text'=>'ℹ️ ตรวจสอบสถานะ','callback_data'=>'status']]]]]);
    }
} catch (Throwable $e) {}
echo 'OK';
