<?php
require_once __DIR__ . '/../system/a_func.php';
if (!isset($_SESSION['id'])) {
    header('Location: ../?page=register');
    exit;
}
?>
```html
<!-- ปุ่มซื้อกลุ่มด้านบน -->
<a href="https://omgvip.shop" class="buy-group">
    🛒 ซื้อกลุ่ม - OMGMOD
    <span>omgvip.shop</span>
</a>

<div class="download-box">

    <div class="icon">⬇️</div>

    <div class="title">
        เตรียมดาวน์โหลด
    </div>

    <div class="description">
        กรุณารอสักครู่ ระบบกำลังเตรียมไฟล์ให้คุณ
    </div>

    <div id="countdown">15</div>

    <button id="downloadBtn" disabled>
        🔒 กรุณารอ 15 วินาที
    </button>

</div>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    min-height: 100vh;
    padding: 25px 16px;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;

    font-family: Arial, sans-serif;

    background:
        radial-gradient(circle at top, #303030, #111 50%, #050505);
}

/* ปุ่มซื้อกลุ่ม */
.buy-group {
    width: 100%;
    max-width: 420px;

    margin-bottom: 18px;
    padding: 15px 18px;

    display: flex;
    flex-direction: column;
    align-items: center;

    text-decoration: none;
    color: white;

    border-radius: 15px;

    background: linear-gradient(
        135deg,
        #00c853,
        #008f3d
    );

    box-shadow:
        0 0 20px rgba(0,200,83,.35);

    font-size: 18px;
    font-weight: bold;

    transition: .2s;
}

.buy-group span {
    margin-top: 4px;
    font-size: 13px;
    opacity: .8;
}

.buy-group:active {
    transform: scale(.96);
}

/* กล่องดาวน์โหลด */
.download-box {
    width: 100%;
    max-width: 420px;

    padding: 35px 22px;

    text-align: center;

    background: rgba(25,25,25,.94);

    border: 1px solid rgba(255,255,255,.12);

    border-radius: 25px;

    box-shadow: 0 15px 50px rgba(0,0,0,.6);
}

/* ไอคอน */
.icon {
    width: 75px;
    height: 75px;

    margin: 0 auto 18px;

    display: flex;
    align-items: center;
    justify-content: center;

    border-radius: 50%;

    font-size: 35px;

    background: linear-gradient(
        145deg,
        #00c853,
        #008f3d
    );

    box-shadow: 0 0 20px rgba(0,200,83,.5);
}

.title {
    color: white;
    font-size: 25px;
    font-weight: bold;
    margin-bottom: 8px;
}

.description {
    color: #aaa;
    font-size: 15px;
    margin-bottom: 25px;
}

#countdown {
    font-size: 42px;
    font-weight: bold;

    color: #ffd600;

    margin-bottom: 22px;

    text-shadow: 0 0 12px rgba(255,214,0,.45);
}

#downloadBtn {
    width: 100%;
    min-height: 58px;

    border: none;
    border-radius: 15px;

    font-size: 19px;
    font-weight: bold;

    color: #aaa;

    background: #444;

    cursor: not-allowed;
}

#downloadBtn.active {
    color: white;

    background: linear-gradient(
        135deg,
        #00e676,
        #00a844
    );

    cursor: pointer;

    box-shadow: 0 0 20px rgba(0,230,118,.45);
}

#downloadBtn.active:active {
    transform: scale(.96);
}
</style>

<script>
let seconds = 15;

const countdown =
    document.getElementById("countdown");

const downloadBtn =
    document.getElementById("downloadBtn");

const timer = setInterval(function () {

    countdown.innerHTML = seconds;

    downloadBtn.innerHTML =
        "🔒 กรุณารอ " + seconds + " วินาที";

    seconds--;

    if (seconds < 0) {

        clearInterval(timer);

        countdown.innerHTML = "✓";

        downloadBtn.disabled = false;

        downloadBtn.classList.add("active");

        downloadBtn.innerHTML =
            "⬇️ ดาวน์โหลดไฟล์";
    }

}, 1000);


/* ลิงก์ไฟล์ดาวน์โหลด */
downloadBtn.onclick = function () {

    if (!downloadBtn.disabled) {

        window.location.href =
            "https://www.mediafire.com/file/7mi3ohtegjbv69t/THLIVE-OMG.apk/file";

    }

};
</script>
```
