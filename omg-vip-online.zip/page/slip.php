<?php $bank = dd_q("SELECT * FROM bank WHERE 1")->fetch(PDO::FETCH_ASSOC); ?>
<?php
$recipient_name = trim(($bank['fname'] ?? '') . ' ' . ($bank['lname'] ?? ''));
?>

<div class="container-sm mt-4">
    <div class="xez-card p-4">
        <div class="mb-3">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <h4 class="fw-bold mb-0 text-dark">SLIP CHECK</h4>
                <span
                    class="badge bg-light-soft text-xez-primary border border-xez-primary rounded-pill px-3">รอแอดมินตรวจสอบ</span>
            </div>
            <p class="text-xez-primary small fw-bold mb-0"># ส่งสลิปให้แอดมินตรวจสอบก่อนเติมเงิน</p>
            <p class="text-muted x-small">หลีกเลี่ยงการโอนเงินช่วงเวลา 23:30 - 00:30 น. (ระบบธนาคารปิดปรับปรุง)</p>
        </div>

        <hr class="border-secondary opacity-10 mb-4">

        <div class="col-lg-12">
            <!-- Bank Info Card -->
            <div class="card border-0 bg-light rounded-4 p-4 mb-4 text-center">
                <div class="mb-3">
                    <img src="https://img_app.byshop.me/buy/img/bank/<?= htmlspecialchars($bank['tname'] == 'กสิกรไทย' ? 'kbank' : 'scb') ?>.png"
                        class="img-fluid rounded-circle shadow-sm" style="width: 70px; height: 70px;"
                        onerror="this.src='https://cdn-icons-png.flaticon.com/512/2830/2830284.png'">
                </div>
                <h5 class="fw-bold text-dark mb-1"><?= htmlspecialchars($bank['tname'] ?? 'ธนาคาร') ?></h5>
                <h4 class="fw-bold text-xez-primary mb-3" id="bankNumber">
                    <?= htmlspecialchars($bank['bnum'] ?? '000-0-00000-0') ?>
                </h4>
                <div class="p-3 bg-white rounded-3 border mb-3">
                    <p class="text-muted mb-1 small">ชื่อบัญชีผู้รับเงิน</p>
                    <h5 class="fw-bold text-dark mb-0"><?= htmlspecialchars($recipient_name) ?></h5>
                </div>
                <button class="btn btn-dark btn-sm rounded-pill px-4 py-2" onclick="copyAccountNumber()">
                    <i class="fa-solid fa-copy me-2"></i> คัดลอกเลขบัญชี
                </button>
            </div>

            <!-- Upload Zone -->
            <div class="upload-zone border-dashed rounded-4 p-5 text-center mb-4 cursor-pointer" id="dropZone"
                onclick="$('#slipInput').click()">
                <div id="uploadPlaceholder">
                    <i class="fa-solid fa-cloud-arrow-up text-xez-primary display-4 mb-3"></i>
                    <h5 class="fw-bold text-dark">แนบไฟล์สลิปการโอนเงินที่นี่</h5>
                    <p class="text-muted small">รองรับไฟล์ JPG, PNG, WEBP ระบบจะลดขนาดรูปให้อัตโนมัติ</p>
                </div>
                <div id="previewZone" class="d-none">
                    <img id="slipPreview" class="img-fluid rounded-3 shadow-sm mb-3" style="max-height: 300px;">
                    <p class="text-muted small">คลิกเพื่อเปลี่ยนรูปสลิป</p>
                </div>
                <input type="file" id="slipInput" accept="image/*" class="d-none">
            </div>

            <div id="processing" class="text-center d-none mb-4">
                <div class="spinner-border text-xez-primary mb-2" role="status"></div>
                <p class="text-muted small mb-0">กำลังอ่านข้อมูลสลิป...</p>
            </div>

            <div id="resultCard" class="card border-0 bg-light-soft rounded-4 p-4 d-none mb-4">
                <h6 class="fw-bold text-dark mb-4 text-center"><i class="fa-solid fa-receipt me-2"></i>
                    ตรวจสอบข้อมูลสลิป</h6>

                <div class="row g-3 mb-4">
                    <div class="col-6">
                        <div class="p-3 bg-white rounded-3 border text-center">
                            <p class="text-muted x-small mb-1">จำนวนเงิน</p>
                            <h5 class="fw-bold text-dark mb-0" id="resultAmount">-</h5>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="p-3 bg-white rounded-3 border text-center">
                            <p class="text-muted x-small mb-1">สถานะผู้รับเงิน</p>
                            <h5 class="fw-bold mb-0" id="resultRecipientStatus">-</h5>
                        </div>
                    </div>
                </div>

                <div class="bg-white rounded-3 border p-3 mb-4">
                    <p class="text-muted x-small mb-1">เลขอ้างอิงสลิป</p>
                    <p class="fw-medium text-dark mb-0 small" id="resultRef">-</p>
                </div>

                <button class="btn btn-success w-100 py-3 fw-bold rounded-3 fs-5" id="confirmBtn" disabled>
                    <i class="fa-solid fa-paper-plane me-2"></i> ส่งสลิปให้แอดมินตรวจสอบ
                </button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
<script>
    const expectedName = "<?= $recipient_name ?>";
    let extractedData = {};

    function copyAccountNumber() {
        var num = $("#bankNumber").text().replace(/-/g, '');
        navigator.clipboard.writeText(num);
        Swal.fire({ icon: 'success', title: 'คัดลอกเลขบัญชีแล้ว', timer: 1000, showConfirmButton: false });
    }

    $("#slipInput").change(async function (e) {
        if (!e.target.files.length) return;
        const file = e.target.files[0];
        const imageUrl = URL.createObjectURL(file);

        // Show preview
        $("#slipPreview").attr("src", imageUrl);
        $("#uploadPlaceholder").addClass("d-none");
        $("#previewZone").removeClass("d-none");

        $("#processing").removeClass("d-none");
        $("#resultCard").addClass("d-none");

        try {
            const worker = await Tesseract.createWorker('tha+eng');
            const result = await worker.recognize(imageUrl);

            // Cleanup Text: remove special chars but keep alphanum and Thai
            const textRaw = result.data.text;
            const text = textRaw.replace(/[^a-zA-Z0-9\u0E00-\u0E7F\.]/g, '');
            console.log("OCR Result Cleaned:", text);

            // 1. Extract Amount
            // Matches: 100.00, 1,000.00 (commas removed by clean regex above? No, clean regex removed commas. better keep commas for amount logic)
            // Let's use a cleaner text for amount specific search
            const textForAmount = textRaw.replace(/[^0-9\.]/g, ' '); // Keep only numbers and dots
            const amountMatches = textForAmount.match(/(\d+\.\d{2})/g);
            let amount = 0;
            if (amountMatches) {
                // Find the maximum value that looks like an amount (usually the transfer amount is meaningful)
                // Or simply pick the last one? Often amount is near the bottom or top.
                // Let's filter for reasonable amounts (e.g. > 0)
                amount = Math.max(...amountMatches.map(m => parseFloat(m)));
            }

            // 2. Extract Reference ID
            // Common lengths: KBank/SCB ~15-20 digits, some have letters. 
            // We look for long strings of digits/alphanum
            const refMatch = text.match(/[0-9A-Z]{10,25}/g);
            let ref = '';
            if (refMatch) {
                // Pick the longest string which is likely the Ref ID
                ref = refMatch.reduce((a, b) => a.length > b.length ? a : b, '');
            }

            // 3. Name Check (Strict)
            // Normalize expected name
            const cleanExpected = expectedName.replace(/[^a-zA-Z0-9\u0E00-\u0E7F]/g, '');
            const checkText = textRaw.replace(/[^a-zA-Z0-9\u0E00-\u0E7F]/g, ''); // Keep sequence

            // Check if substrings match
            const nameMatched = checkText.includes(cleanExpected);

            // InfinityFree จำกัดขนาด POST ค่อนข้างต่ำ จึงย่อรูปก่อนส่งขึ้นเซิร์ฟเวอร์
            // โดยยังใช้รูปต้นฉบับสำหรับ OCR เพื่อรักษาความแม่นยำ
            const uploadFile = await compressSlipImage(file);
            extractedData = {
                amount: amount,
                ref: ref,
                nameMatched: nameMatched,
                file: uploadFile
            };

            // Update UI
            $("#resultAmount").text(extractedData.amount > 0 ? extractedData.amount.toLocaleString(undefined, { minimumFractionDigits: 2 }) + ' ฿' : 'ค้นหาไม่พบ');
            $("#resultRef").text(extractedData.ref ? extractedData.ref : 'ค้นหาไม่พบ');

            const statusTarget = $("#resultRecipientStatus");
            if (nameMatched) {
                statusTarget.html('<i class="fa-solid fa-circle-check text-success me-1"></i> ถูกต้อง').addClass("text-success").removeClass("text-danger");
                $("#confirmBtn").prop("disabled", false);
            } else {
                statusTarget.html('<i class="fa-solid fa-clock text-warning me-1"></i> รอแอดมินตรวจสอบ').addClass("text-warning").removeClass("text-success text-danger");
                $("#confirmBtn").prop("disabled", false);

                let debugMsg = `
                    <div class="text-start bg-light p-2 rounded small mt-2">
                        <b>สิ่งที่ระบบมองหา:</b> ${expectedName}<br>
                        <b>ผลการอ่าน:</b> ไม่พบชื่อที่ตรงกัน
                    </div>`;

                Swal.fire({
                    icon: 'info',
                    title: 'ส่งตรวจสอบโดยแอดมิน',
                    html: `ระบบอ่านชื่อผู้รับไม่ชัดเจน รายการจะถูกส่งให้แอดมินตรวจสอบภายใน 24 ชั่วโมง ${debugMsg}`
                });
            }

            $("#processing").addClass("d-none");
            $("#resultCard").removeClass("d-none");

            await worker.terminate();

            // Handle Missing Data: Manual Input Fallback
            if (nameMatched) {
                if (extractedData.amount <= 0) {
                    // Prompt User
                    const { value: manualAmount } = await Swal.fire({
                        title: 'ระบุจำนวนเงิน',
                        text: 'ระบบอ่านจำนวนเงินไม่ได้ กรุณาระบุตามสลิป',
                        input: 'number',
                        inputAttributes: { min: 1, step: 0.01 },
                        confirmButtonText: 'ยืนยัน',
                        allowOutsideClick: false
                    });
                    if (manualAmount) {
                        extractedData.amount = parseFloat(manualAmount);
                        $("#resultAmount").text(extractedData.amount.toLocaleString() + ' ฿');
                    }
                }

                if (!extractedData.ref) {
                    const { value: manualRef } = await Swal.fire({
                        title: 'ระบุเลขอ้างอิง',
                        text: 'ระบบอ่านเลขอ้างอิงไม่ได้ กรุณาระบุ',
                        input: 'text',
                        confirmButtonText: 'ยืนยัน',
                        allowOutsideClick: false
                    });
                    if (manualRef) {
                        extractedData.ref = manualRef;
                        $("#resultRef").text(extractedData.ref);
                    }
                }
            }

        } catch (error) {
            $("#processing").addClass("d-none");
            Swal.fire({ icon: 'error', title: 'เกิดข้อผิดพลาดในการอ่านสลิป' });
            console.error(error);
        }
    });

    function compressSlipImage(file) {
        return new Promise((resolve) => {
            if (file.size <= 1500000 && file.type === 'image/jpeg') return resolve(file);
            const img = new Image();
            img.onload = () => {
                const maxSide = 1800;
                const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
                const canvas = document.createElement('canvas');
                canvas.width = Math.max(1, Math.round(img.width * scale));
                canvas.height = Math.max(1, Math.round(img.height * scale));
                canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
                canvas.toBlob((blob) => resolve(new File([blob], 'slip.jpg', {type: 'image/jpeg'})), 'image/jpeg', 0.82);
            };
            img.onerror = () => resolve(file);
            img.src = URL.createObjectURL(file);
        });
    }

    // Drag and Drop Support
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('slipInput');

    dropZone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropZone.classList.add('bg-light-soft');
        dropZone.style.borderColor = 'var(--xez-primary)';
    });

    dropZone.addEventListener('dragleave', (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-light-soft');
        dropZone.style.borderColor = '#dee2e6';
    });

    dropZone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropZone.classList.remove('bg-light-soft');
        dropZone.style.borderColor = '#dee2e6';

        if (e.dataTransfer.files.length) {
            fileInput.files = e.dataTransfer.files;
            $("#slipInput").trigger("change");
        }
    });

    $("#confirmBtn").click(async function () {
        if (extractedData.amount <= 0 || !extractedData.ref) {
            Swal.fire({ icon: 'warning', title: 'ข้อมูลไม่ครบ', text: 'กรุณาตรวจสอบจำนวนเงินและเลขที่อ้างอิง' });
            return;
        }

        Swal.fire({ title: 'กำลังตรวจสอบสลิป...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });

        const formData = new FormData();
        formData.append('amount', extractedData.amount);
        formData.append('ref', extractedData.ref);
        formData.append('slip_image', extractedData.file);

        $.ajax({
            type: 'POST',
            url: 'system/slip.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            if (res.status == 'success') {
                Swal.fire({ icon: 'success', title: 'ส่งตรวจสอบแล้ว', text: res.message }).then(() => location.href = '?page=profile&subpage=topuphis');
            } else {
                Swal.fire({ icon: 'error', title: 'ไม่สามารถเติมเงินได้', text: res.message });
            }
        }).fail(function (jqXHR) {
            let res = jqXHR.responseJSON;
            Swal.fire({ icon: 'error', title: 'ระบบขัดข้อง', text: res ? res.message : 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้' });
        });
    });
</script>

<style>
    .cursor-pointer {
        cursor: pointer;
    }

    .upload-zone {
        transition: all 0.2s ease-in-out;
        background: rgba(var(--xez-primary-rgb), 0.02);
    }

    .upload-zone:hover {
        background: rgba(var(--xez-primary-rgb), 0.05);
        border-color: var(--xez-primary) !important;
    }

    .bg-light-soft {
        background-color: rgba(var(--xez-primary-rgb), 0.05) !important;
    }

    .border-dashed {
        border: 2px dashed #dee2e6 !important;
    }
</style>
