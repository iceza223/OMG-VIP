<div class="container-sm py-5">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-7">
            <div class="xez-card p-4 p-lg-5">
                <div class="text-center mb-4">
                    <div class="bg-primary-soft d-inline-flex align-items-center justify-content-center rounded-circle mb-3"
                        style="width: 70px; height: 70px;">
                        <i class="fa-solid fa-user text-xez-primary fs-2"></i>
                    </div>
                    <h3 class="fw-bold mb-1">เข้าสู่ระบบ</h3>
                    <p class="text-muted small">กรอกข้อมูลเพื่อเข้าใช้งานระบบ</p>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold">ชื่อผู้ใช้</label>
                    <input type="text" class="form-control py-2" id="user" placeholder="Username">
                </div>
                <div class="mb-4">
                    <label class="form-label small fw-bold">รหัสผ่าน</label>
                    <input type="password" class="form-control py-2" id="pass" placeholder="Password">
                </div>

                <div class="mb-4 d-flex justify-content-center">
                    <div id="capcha" class="g-recaptcha" data-theme="light"></div>
                </div>

                <button class="btn xez-btn-cyan w-100 py-3 fw-bold mb-3" id="btn_regis">
                    <i class="fa-solid fa-arrow-right-to-bracket me-2"></i> เข้าสู่ระบบ
                </button>

                <div class="d-flex align-items-center gap-2 text-muted small my-3"><div class="flex-grow-1 border-top"></div><span>หรือ</span><div class="flex-grow-1 border-top"></div></div>
                <button type="button" class="btn btn-light border w-100 py-3 fw-bold mb-3" id="google-login-button">
                    <span style="font-size:1.15rem;font-weight:700;color:#4285f4;margin-right:.5rem">G</span> เข้าสู่ระบบด้วย Google
                </button>

                <div class="text-center">
                    <p class="text-muted small mb-0">
                        ยังไม่มีบัญชี?
                        <a href="?page=register" class="text-xez-primary fw-bold">สมัครสมาชิก</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

    <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit" async defer></script>
<script>
    var onloadCallback = function () {
        if (typeof grecaptcha !== 'undefined') {
            grecaptcha.render('capcha', { 'sitekey': '<?= $conf['sitekey'] ?>' });
        }
    };

    $("#btn_regis").click(function (e) {
        e.preventDefault();
        var formData = new FormData();
        formData.append('user', $("#user").val());
        formData.append('pass', $("#pass").val());
        formData.append('captcha', typeof grecaptcha !== 'undefined' ? grecaptcha.getResponse() : '');
        $('#btn_regis').attr('disabled', 'disabled');

        $.ajax({
            type: 'POST',
            url: 'system/login.php',
            data: formData,
            contentType: false,
            processData: false,
        }).done(function (res) {
            if (typeof grecaptcha !== 'undefined') grecaptcha.reset();
            if (res.status == "success") {
                Swal.fire({ icon: 'success', title: 'สำเร็จ', text: res.message }).then(() => location.href = '?page=home');
            } else {
                Swal.fire({ icon: 'error', title: 'ผิดพลาด', text: res.message });
                $('#btn_regis').removeAttr('disabled');
            }
        }).fail(function () {
            if (typeof grecaptcha !== 'undefined') grecaptcha.reset();
            Swal.fire({ icon: 'error', title: 'เกิดข้อผิดพลาด', text: 'ไม่สามารถติดต่อเซิร์ฟเวอร์ได้' });
            $('#btn_regis').removeAttr('disabled');
        });
    });

    // Google Identity Services will be enabled after the real Web OAuth Client ID
    // is added to this page. Never treat a placeholder as an authenticated user.
    $("#google-login-button").click(function () {
        Swal.fire({
            icon: 'info',
            title: 'Google Login ยังไม่พร้อมใช้งาน',
            text: 'กรุณาตั้งค่า Google Client ID ของเว็บไซต์ก่อน แล้วจึงเปิดใช้งานปุ่มนี้',
            confirmButtonText: 'ตกลง'
        });
    });

    $(function () {
        function rescaleCaptcha() {
            var width = $('.g-recaptcha').parent().width();
            var scale = width < 302 ? width / 302 : 1.0;
            $('.g-recaptcha').css({ 'transform': 'scale(' + scale + ')', 'transform-origin': '0 0' });
        }
        rescaleCaptcha();
        $(window).resize(rescaleCaptcha);
    });
</script>
