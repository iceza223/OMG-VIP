<style>
.buy-history-shell{background:linear-gradient(145deg,#111b29,#0a1019);border:1px solid #27364a;border-radius:16px;padding:20px;color:#e7edf7;box-shadow:0 16px 36px rgba(0,0,0,.24)}
.buy-history-shell h4{color:#f8fafc!important}.buy-history-shell p{color:#94a3b8!important}
.buy-history-shell .table{color:#dbeafe!important;margin-bottom:0}.buy-history-shell .table thead{background:#0d1623!important}.buy-history-shell .table thead th{color:#8fb9e8!important;letter-spacing:.02em}.buy-history-shell .table tbody tr{border-color:#243247!important}.buy-history-shell .table tbody tr:hover{background:rgba(22,129,255,.08)!important}.buy-history-shell .table td{color:#dbeafe!important;vertical-align:middle}.buy-history-shell .badge{background:#102b4c!important;color:#82b9ff!important;border:1px solid #24568d}.buy-history-shell .btn-primary{background:linear-gradient(135deg,#1681ff,#075bd8)!important;border-color:#3096ff!important;border-radius:9px}.buy-history-shell .btn-warning{background:#2b2110!important;color:#f1b84b!important;border:1px solid #5b4015!important;border-radius:9px}.buy-history-empty{background:#0d141f;border:1px dashed #334863;border-radius:12px;color:#94a3b8;padding:28px;text-align:center}
@media(max-width:640px){.buy-history-shell{padding:13px;border-radius:13px}.buy-history-shell .table{min-width:640px}.buy-history-shell .table-responsive{margin:0 -3px;padding-bottom:6px}.buy-history-shell h4{font-size:1.1rem}}
</style>
<div class="p-2 buy-history-shell">
    <div class="mb-4">
        <h4 class="fw-bold text-dark mb-1"><i class="fa-solid fa-clock-rotate-left text-xdvz-primary me-2"></i> ประวัติการสั่งซื้อ</h4>
        <p class="text-muted small">บันทึกรายการสั่งซื้อสินค้าที่คุณเคยทำรายการไว้ในระบบ</p>
    </div>

    <div class="table-responsive">
        <table class="table table-hover border-0" id="table">
            <thead class="bg-light">
                <tr>
                    <th class="border-0 py-3 ps-4 text-muted small fw-bold text-center">ลำดับ</th>
                    <th class="border-0 py-3 text-muted small fw-bold">หมวดหมู่ / รายการ</th>
                    <th class="border-0 py-3 text-muted small fw-bold">รายละเอียด / ของรางวัล</th>
                    <th class="border-0 py-3 pe-4 text-muted small fw-bold">วันที่สั่งซื้อ</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                    $q = dd_q("SELECT * FROM boxlog WHERE uid = ? ORDER BY id DESC", [$_SESSION['id']]);
                    $i = 1;
                    $has_orders = false;
                    while($row = $q->fetch(PDO::FETCH_ASSOC)){
                        $has_orders = true;
                        $purchase_time = (string)($row['date'] ?? '');
                        $purchase_date = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $purchase_time, new DateTimeZone('Asia/Bangkok'));
                        $purchase_display_time = $purchase_date
                            ? $purchase_date->setTimezone(new DateTimeZone('Asia/Bangkok'))->format('d/m/Y H:i:s')
                            : $purchase_time;
                ?>
                <tr class="align-middle border-bottom">
                    <td class="py-3 ps-4 text-center text-dark small fw-bold"><?= number_format($i) ?></td>
                    <td class="py-3">
                        <span class="badge bg-light-soft text-xdvz-primary px-3 py-2 rounded-3 small">
                           <?= htmlspecialchars($row['category']) ?>
                        </span>
                    </td>
                    <td class="py-3">
                        <?php
                            $purchase_value = trim((string)($row['prize_name'] ?? ''));
                            $is_purchase_url = filter_var($purchase_value, FILTER_VALIDATE_URL)
                                && preg_match('/^https?:\/\//i', $purchase_value);
                        ?>
                        <span class="text-dark small fw-medium"><?= htmlspecialchars($purchase_value, ENT_QUOTES, 'UTF-8') ?></span>
                        <?php if ($is_purchase_url): ?>
                            <a class="btn btn-sm btn-primary text-white fw-bold ms-2" href="<?= htmlspecialchars($purchase_value, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer">
                                <i class="fa-solid fa-arrow-up-right-from-square me-1"></i>เปิดลิงก์
                            </a>
                        <?php else: ?>
                            <button type="button" class="btn btn-sm btn-warning text-dark fw-bold ms-2 copy-purchase" data-copy="<?= htmlspecialchars($purchase_value, ENT_QUOTES, 'UTF-8') ?>" onclick="copyPurchase(this)">
                                <i class="fa-regular fa-copy me-1"></i>คัดลอก
                            </button>
                        <?php endif; ?>
                    </td>
                    <td class="py-3 pe-4 text-muted small"><?= htmlspecialchars($purchase_display_time, ENT_QUOTES, 'UTF-8') ?></td>
                </tr>
                <?php $i++; } ?>
                <?php if (!$has_orders): ?>
                <tr><td colspan="4"><div class="buy-history-empty"><i class="fa-solid fa-receipt fa-2x mb-2"></i><div>ยังไม่มีประวัติการสั่งซื้อ</div><small>รายการสั่งซื้อของคุณจะแสดงที่หน้านี้หลังทำรายการสำเร็จ</small></div></td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('#table').DataTable({
            "language": { "url": "//cdn.datatables.net/plug-ins/1.10.24/i18n/Thai.json" },
            "pageLength": 10
        });
    });
</script>
<script>
function copyPurchase(button) {
    const text = button.dataset.copy || '';
    const done = () => {
        const old = button.innerHTML;
        button.innerHTML = '<i class="fa-solid fa-check me-1"></i>คัดลอกแล้ว';
        setTimeout(() => { button.innerHTML = old; }, 1600);
    };
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done).catch(() => window.prompt('คัดลอกข้อมูลนี้:', text));
    } else {
        const area = document.createElement('textarea');
        area.value = text;
        area.style.position = 'fixed';
        area.style.opacity = '0';
        document.body.appendChild(area);
        area.select();
        try { document.execCommand('copy'); done(); } catch (e) { window.prompt('คัดลอกข้อมูลนี้:', text); }
        area.remove();
    }
}
</script>
