<?php
// Home Page - แสดงสินค้าและ Quick Navigation

$topup_redeem_enabled = (($config['topup_redeem_status'] ?? 'on') === 'on');
$topup_slip_enabled = (($config['topup_slip_status'] ?? 'on') === 'on');

// Get boost values from static table
$boost_members = 0;
$boost_categories = 0;
$boost_products = 0;
$boost_sold = 0;

$static_result = dd_q("SELECT * FROM static LIMIT 1");
if ($static_result && $static_result->rowCount() > 0) {
    $static_data = $static_result->fetch(PDO::FETCH_ASSOC);
    $boost_members = intval($static_data['m_count'] ?? 0);
    $boost_categories = intval($static_data['c_count'] ?? 0);
    $boost_products = intval($static_data['s_count'] ?? 0);
    $boost_sold = intval($static_data['sold_count'] ?? 0);
}

// Get real statistics
$real_users = 0;
$real_categories = 0;
$real_products = 0;
$real_sold = 0;

$users_result = dd_q("SELECT COUNT(*) as total FROM users");
if ($users_result)
    $real_users = intval($users_result->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

$cat_result = dd_q("SELECT COUNT(*) as total FROM category");
if ($cat_result)
    $real_categories = intval($cat_result->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

$stock_result = dd_q("SELECT COUNT(*) as total FROM box_stock");
if ($stock_result)
    $real_products = intval($stock_result->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

$sold_result = dd_q("SELECT COUNT(*) as total FROM boxlog");
if ($sold_result)
    $real_sold = intval($sold_result->fetch(PDO::FETCH_ASSOC)['total'] ?? 0);

// Combined totals
$total_users = $real_users + $boost_members;
$total_categories = $real_categories + $boost_categories;
$total_products = $real_products + $boost_products;
$total_sold = $real_sold + $boost_sold;
?>

<?php
$carousel_items = [];
$carousel_result = dd_q("SELECT id, link FROM carousel ORDER BY id ASC");
if ($carousel_result) {
    while ($carousel_row = $carousel_result->fetch(PDO::FETCH_ASSOC)) {
        // รองรับข้อมูลเก่าที่อาจมีเครื่องหมาย quote ติดมาจากการบันทึก URL
        $carousel_link = trim((string) ($carousel_row['link'] ?? ''), " \\\"'");
        if ($carousel_link !== '' && filter_var($carousel_link, FILTER_VALIDATE_URL)) {
            $carousel_items[] = [
                'id' => (int) ($carousel_row['id'] ?? 0),
                'link' => $carousel_link,
            ];
        }
    }
}
?>

<?php if (!empty($carousel_items)): ?>
<section class="home-carousel-section container-sm py-3" aria-label="ภาพสไลด์เว็บไซต์">
    <div id="homeCarousel" class="carousel slide home-carousel shadow-lg" data-bs-ride="carousel" data-bs-interval="5000">
        <?php if (count($carousel_items) > 1): ?>
            <div class="carousel-indicators">
                <?php foreach ($carousel_items as $carousel_index => $carousel_item): ?>
                    <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="<?= $carousel_index ?>"
                        class="<?= $carousel_index === 0 ? 'active' : '' ?>" aria-current="<?= $carousel_index === 0 ? 'true' : 'false' ?>"
                        aria-label="ภาพสไลด์ <?= $carousel_index + 1 ?>"></button>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

        <div class="carousel-inner">
            <?php foreach ($carousel_items as $carousel_index => $carousel_item): ?>
                <div class="carousel-item <?= $carousel_index === 0 ? 'active' : '' ?>">
                    <img src="<?= htmlspecialchars($carousel_item['link'], ENT_QUOTES, 'UTF-8') ?>"
                        class="d-block w-100" alt="ภาพสไลด์ <?= $carousel_index + 1 ?>"
                        loading="<?= $carousel_index === 0 ? 'eager' : 'lazy' ?>">
                </div>
            <?php endforeach; ?>
        </div>

        <?php if (count($carousel_items) > 1): ?>
            <button class="carousel-control-prev" type="button" data-bs-target="#homeCarousel" data-bs-slide="prev" aria-label="ภาพก่อนหน้า">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#homeCarousel" data-bs-slide="next" aria-label="ภาพถัดไป">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
            </button>
        <?php endif; ?>
    </div>
</section>
<?php endif; ?>

<!-- Hero Banner Section -->
<div class="home-hero-banner">
    <div class="home-hero-particles"></div>
    <div class="container position-relative" style="z-index: 2;">
        <div class="text-center py-5">
            <img src="<?= htmlspecialchars($site_logo ?? 'assets/omg-logo-transparent.webp', ENT_QUOTES, 'UTF-8') ?>" alt="Logo" class="home-hero-logo mb-4">
            <h1 class="home-hero-title"><?= strtoupper($config['name']) ?></h1>
            <div class="home-hero-tagline">
                <span><?= $config['des'] ?></span>
            </div>
            <div class="home-hero-buttons mt-4">
                <a href="?page=shop" class="btn home-btn-primary mx-2">
                    <i class="fa-solid fa-shopping-bag me-2"></i>ดูสินค้าทั้งหมด
                </a>
                <a href="?page=topup" class="btn home-btn-outline mx-2">
                    <i class="fa-solid fa-wallet me-2"></i>เติมเงินพอยท์
                </a>
            </div>

            <?php if (!empty($config['ann']) && (($config['announcement_status'] ?? 'on') === 'on')): ?>
                <!-- Announcement Bar -->
                <div class="home-announcement-bar mt-4">
                    <div class="announcement-icon">
                        <i class="fa-solid fa-bullhorn"></i>
                    </div>
                    <div class="announcement-content">
                        <marquee behavior="scroll" direction="left" scrollamount="3">
                            <?= htmlspecialchars($config['ann']) ?>
                        </marquee>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Statistics Bar -->
        <div class="home-stats-bar mt-4">
            <div class="home-stat-item">
                <div class="home-stat-info">
                    <span class="home-stat-label">สมาชิก</span>
                    <span class="home-stat-value"><?= number_format($total_users) ?><small>คน</small></span>
                </div>
                <div class="home-stat-icon">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
            <div class="home-stat-item">
                <div class="home-stat-info">
                    <span class="home-stat-label">หมวดหมู่</span>
                    <span class="home-stat-value"><?= number_format($total_categories) ?><small>กลุ่ม</small></span>
                </div>
                <div class="home-stat-icon">
                    <i class="fa-solid fa-layer-group"></i>
                </div>
            </div>
            <div class="home-stat-item">
                <div class="home-stat-info">
                    <span class="home-stat-label">พร้อมขาย</span>
                    <span class="home-stat-value"><?= number_format($total_products) ?><small>ชิ้น</small></span>
                </div>
                <div class="home-stat-icon">
                    <i class="fa-solid fa-box-open"></i>
                </div>
            </div>
            <div class="home-stat-item home-stat-highlight">
                <div class="home-stat-info">
                    <span class="home-stat-label">ขายแล้ว</span>
                    <span class="home-stat-value"><?= number_format($total_sold) ?><small>ชิ้น</small></span>
                </div>
                <div class="home-stat-icon">
                    <i class="fa-solid fa-check-circle"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-sm py-5">
    <!-- Announcement -->
    <?php if (!empty($config['ann']) && (($config['announcement_status'] ?? 'on') === 'on')): ?>
        <div class="announcement-bar shadow-sm mb-4">
            <div class="announcement-icon">
                <i class="fa-solid fa-bullhorn"></i>
            </div>
            <marquee class="flex-grow-1 fw-medium"><?= htmlspecialchars($config['ann']) ?></marquee>
        </div>
    <?php endif; ?>

    <!-- Featured Categories -->
    <div class="mb-5">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <h4 class="fw-bold mb-1"><i class="fa-solid fa-layer-group text-xez-primary me-2"></i>
                    หมวดหมู่แนะนำ</h4>
                <p class="text-muted small mb-0">เลือกชมสินค้าตามหมวดหมู่ที่คุณสนใจ</p>
            </div>
            <a href="?page=shop" class="btn xez-btn-outline btn-sm px-4">ดูทั้งหมด</a>
        </div>

        <div class="row g-4">
            <?php
            $cat_find = dd_q("SELECT * FROM category ORDER BY c_id DESC LIMIT 4");
            if ($cat_find && $cat_find->rowCount() > 0):
                while ($cat_row = $cat_find->fetch(PDO::FETCH_ASSOC)):
                    // box_product stores the category name in c_type (the shop page uses the same mapping).
                    // Count products by category name so the category cards show the actual total.
                    $category_key = $cat_row['c_name'] ?? '';
                    $item_count_q = dd_q("SELECT COUNT(*) as cnt FROM box_product WHERE c_type = ?", [$category_key]);
                    $item_count = $item_count_q ? intval($item_count_q->fetch(PDO::FETCH_ASSOC)['cnt'] ?? 0) : 0;
                    ?>
                    <div class="col-12 col-md-6">
                        <a href="?page=shop&category=<?= $cat_row['c_id'] ?>" class="text-decoration-none">
                            <div class="xez-card cat-card-horizontal">
                                <div class="cat-card-img">
<img src="<?= htmlspecialchars((strcasecmp(trim($cat_row['c_name'] ?? ''), 'redeem') === 0 || trim($cat_row['c_name'] ?? '') === 'แลกโค้ด') ? '/assets/redeem-icon.png' : ($cat_row['img'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                                        alt="<?= htmlspecialchars($cat_row['c_name'] ?? '') ?>"
                                        onerror="this.src='https://placehold.co/600x400?text=No+Image'">
                                </div>
                                <div class="cat-card-body">
                                    <div class="cat-card-info">
                                        <h5 class="fw-bold mb-1">
                                            <?= htmlspecialchars($cat_row['c_name'] ?? 'N/A') ?>
                                        </h5>
                                        <p class="text-muted small mb-0">
                                            <?= $item_count ?> รายการสินค้า
                                        </p>
                                    </div>
                                    <div class="cat-card-action">
                                        <i class="fa-solid fa-chevron-right text-xez-primary"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                <?php endwhile;
            else: ?>
                <div class="col-12 text-center py-4 bg-light rounded-4 border border-dashed">
                    <p class="text-muted mb-0">ยังไม่มีหมวดหมู่แนะนำ</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Navigation: controlled from the admin home-menu manager. -->
    <?php
    $home_nav_items = [];
    $home_nav_result = dd_q("SELECT title, icon, link, bg_color, icon_color FROM home_nav_items WHERE is_active = 1 ORDER BY sort_order ASC, id ASC");
    if ($home_nav_result) {
        $home_nav_items = $home_nav_result->fetchAll(PDO::FETCH_ASSOC);
    }
    if (empty($home_nav_items)) {
        $home_nav_items = [
            ['title' => 'เลือกซื้อสินค้า', 'icon' => 'fa-shop', 'link' => '?page=shop', 'bg_color' => '#211a05', 'icon_color' => '#ffb300'],
            ['title' => 'เติมเงิน', 'icon' => 'fa-wallet', 'link' => '?page=topup', 'bg_color' => '#06231a', 'icon_color' => '#66d63c'],
            ['title' => 'แลกโค้ด', 'icon' => 'fa-gift', 'link' => '?page=redeem', 'bg_color' => '#210b12', 'icon_color' => '#ff4d6d'],
            ['title' => 'Download (THLIVE-MOD-FREE)', 'icon' => 'fa-download', 'link' => isset($_SESSION['id']) ? '?page=download' : '?page=register', 'bg_color' => '#211a05', 'icon_color' => '#ffb300'],
            ['title' => 'แจ้งโอนเงิน', 'icon' => 'fa-receipt', 'link' => '?page=slip', 'bg_color' => '#071b24', 'icon_color' => '#7cff4d'],
        ];
    }
    ?>
    <div class="row g-3 mb-5 home-nav-grid">
        <?php foreach ($home_nav_items as $home_nav):
            $home_nav_link = trim((string)($home_nav['link'] ?? '?page=home'));
            if ($home_nav_link === '') $home_nav_link = '?page=home';
            $home_nav_icon = preg_match('/^fa-[a-z0-9-]+$/i', (string)($home_nav['icon'] ?? '')) ? $home_nav['icon'] : 'fa-circle';
            $home_nav_bg = preg_match('/^#[0-9a-f]{6}$/i', (string)($home_nav['bg_color'] ?? '')) ? $home_nav['bg_color'] : '#102313';
            $home_nav_icon_color = preg_match('/^#[0-9a-f]{6}$/i', (string)($home_nav['icon_color'] ?? '')) ? $home_nav['icon_color'] : '#b8d82e';
        ?>
        <div class="col-6 col-md-3">
            <a href="<?= htmlspecialchars($home_nav_link, ENT_QUOTES, 'UTF-8') ?>" class="text-decoration-none">
                <div class="xez-card text-center py-4 home-nav-card">
                    <div class="home-nav-icon" style="background: <?= htmlspecialchars($home_nav_bg, ENT_QUOTES, 'UTF-8') ?>;">
                        <?php if (!empty($home_nav['image_url']) && filter_var($home_nav['image_url'], FILTER_VALIDATE_URL)): ?>
                            <img src="<?= htmlspecialchars($home_nav['image_url'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars((string)($home_nav['title'] ?? 'เมนู'), ENT_QUOTES, 'UTF-8') ?>" style="width:100%;height:100%;object-fit:cover;border-radius:inherit;" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='inline-block';">
                        <?php endif; ?>
                        <i class="fa-solid <?= htmlspecialchars($home_nav_icon, ENT_QUOTES, 'UTF-8') ?>" style="color: <?= htmlspecialchars($home_nav_icon_color, ENT_QUOTES, 'UTF-8') ?>;<?= !empty($home_nav['image_url']) ? 'display:none;' : '' ?>"></i>
                    </div>
                    <h6 class="mb-0 fw-bold mt-3"><?= htmlspecialchars((string)($home_nav['title'] ?? 'เมนู'), ENT_QUOTES, 'UTF-8') ?></h6>
                </div>
            </a>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Featured Products -->
    <div class="mb-5">
        <div class="d-flex justify-content-between align-items-end mb-4">
            <div>
                <h4 class="fw-bold mb-1"><i class="fa-solid fa-fire-flame-curved text-xez-primary me-2"></i>
                    สินค้าแนะนำ</h4>
                <p class="text-muted small mb-0">สินค้ายอดนิยมในร้านของเรา</p>
            </div>
            <a href="?page=shop" class="btn xez-btn-outline btn-sm px-4">ดูทั้งหมด</a>
        </div>

        <div class="row g-4">
            <?php
            // อ่านสินค้าแนะนำตามลำดับที่ผู้ดูแลตั้งค่าไว้ในตาราง recom
            $recommended_products = [];
            $recom_result = dd_q("SELECT * FROM recom LIMIT 1");
            if ($recom_result) {
                $recom_data = $recom_result->fetch(PDO::FETCH_ASSOC) ?: [];
                for ($recommendation_index = 1; $recommendation_index <= 10; $recommendation_index++) {
                    $recommended_id = (int) ($recom_data['recom_' . $recommendation_index] ?? 0);
                    if ($recommended_id <= 0) {
                        continue;
                    }
                    $product_result = dd_q("SELECT * FROM box_product WHERE id = ? LIMIT 1", [$recommended_id]);
                    $recommended_product = $product_result ? $product_result->fetch(PDO::FETCH_ASSOC) : false;
                    if ($recommended_product) {
                        $recommended_products[] = $recommended_product;
                    }
                }
            }

            // ถ้ายังไม่ได้ตั้งค่าสินค้าแนะนำ ให้คง fallback สินค้าล่าสุดไว้แทนการปล่อยส่วนนี้ว่าง
            if (empty($recommended_products)) {
                $fallback_result = dd_q("SELECT * FROM box_product ORDER BY id DESC LIMIT 8");
                if ($fallback_result) {
                    while ($fallback_product = $fallback_result->fetch(PDO::FETCH_ASSOC)) {
                        $recommended_products[] = $fallback_product;
                    }
                }
            }

            $stock_counts = [];
            if (!empty($recommended_products)) {
                $product_ids = array_values(array_unique(array_map(static fn($product) => (int)($product['id'] ?? 0), $recommended_products)));
                $product_ids = array_values(array_filter($product_ids, static fn($id) => $id > 0));
                if (!empty($product_ids)) {
                    $placeholders = implode(',', array_fill(0, count($product_ids), '?'));
                    $stock_count_q = dd_q("SELECT p_id, COUNT(*) AS cnt FROM box_stock WHERE p_id IN ($placeholders) GROUP BY p_id", $product_ids);
                    if ($stock_count_q) {
                        while ($stock_row = $stock_count_q->fetch(PDO::FETCH_ASSOC)) {
                            $stock_counts[(int)$stock_row['p_id']] = (int)$stock_row['cnt'];
                        }
                    }
                }
            }

            if (!empty($recommended_products)):
                foreach ($recommended_products as $row):
                    $stock = $stock_counts[(int)($row['id'] ?? 0)] ?? 0;
                    ?>
                    <div class="col-6 col-md-4 col-lg-3">
                        <div class="xez-card h-100 p-3 text-center position-relative product-card">

                                <?php if ($row['price'] < 100): ?>
                                    <span class="badge bg-danger position-absolute"
                                        style="top: 15px; right: 15px; z-index: 5;">HOT</span>
                                <?php endif; ?>

                                <div class="mb-3 overflow-hidden rounded product-img-wrapper">
                                    <img src="<?= htmlspecialchars($row['img'] ?? '') ?>" class="w-100 h-100 product-img">
                                </div>

                                <h6 class="fw-bold mb-2 text-truncate"><?= htmlspecialchars($row['name'] ?? 'N/A') ?></h6>

                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <span class="text-xez-primary fw-bold"><?= number_format($row['price'] ?? 0) ?> ฿</span>
                                    <span class="text-muted small"><?= $stock ?> ชิ้น</span>
                                </div>

                                <a href="?page=product&id=<?= (int) $row['id'] ?>" class="btn xez-detail-btn w-100 mb-2">
                                    <i class="fa-solid fa-eye me-1"></i> ดูรายละเอียด
                                </a>
                                <?php if ((int) $stock > 0): ?>
                                    <a href="?page=product&id=<?= (int) $row['id'] ?>#purchase" class="btn xez-order-btn w-100">
                                        <i class="fa-solid fa-cart-shopping me-1"></i> สั่งซื้อ
                                    </a>
                                <?php else: ?>
                                    <button type="button" class="btn xez-soldout-btn w-100" disabled>
                                        <i class="fa-solid fa-ban me-1"></i> สินค้าหมด
                                    </button>
                                <?php endif; ?>
                            </div>
                    </div>
                    <?php
                endforeach;
            else:
                ?>
                <div class="col-12 text-center py-5">
                    <i class="fa-solid fa-box-open text-muted" style="font-size: 4rem;"></i>
                    <h5 class="text-muted mt-3">ยังไม่มีสินค้าในขณะนี้</h5>
                    <a href="?page=shop" class="btn xez-btn-cyan mt-3">
                        <i class="fa-solid fa-store me-2"></i>ไปหน้าร้านค้า
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
    /* Database carousel */
    .home-carousel-section {
        position: relative;
        z-index: 3;
    }

    .home-carousel {
        overflow: hidden;
        border: 1px solid rgba(var(--xez-primary-rgb), 0.45);
        border-radius: 18px;
        background: #160d17;
    }

    .home-carousel .carousel-item {
        aspect-ratio: 1920 / 600;
        min-height: 150px;
        background: #160d17;
    }

    .home-carousel .carousel-item img {
        width: 100%;
        height: 100%;
        min-height: 150px;
        object-fit: cover;
    }

    .home-carousel .carousel-indicators {
        margin-bottom: 0.7rem;
    }

    .home-carousel .carousel-indicators button {
        width: 24px;
        height: 4px;
        border: 0;
        border-radius: 999px;
        background-color: rgba(255, 255, 255, 0.55);
    }

    .home-carousel .carousel-indicators button.active {
        background-color: var(--xez-primary);
    }

    .home-carousel .carousel-control-prev-icon,
    .home-carousel .carousel-control-next-icon {
        filter: drop-shadow(0 2px 4px rgba(0, 0, 0, 0.8));
    }

    /* Hero Banner */
    .home-hero-banner {
        background: linear-gradient(180deg, #0a0a15 0%, #1a0a25 50%, #0f0f1a 100%);
        padding: 40px 0 60px;
        position: relative;
        overflow: hidden;
    }

    .home-hero-particles {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-image:
            radial-gradient(2px 2px at 20px 30px, rgba(255, 255, 255, 0.2), transparent),
            radial-gradient(2px 2px at 40px 70px, rgba(255, 255, 255, 0.15), transparent),
            radial-gradient(2px 2px at 50px 160px, rgba(255, 255, 255, 0.2), transparent),
            radial-gradient(3px 3px at 200px 200px, rgba(200, 150, 255, 0.3), transparent);
        background-size: 300px 300px;
        animation: hero-sparkle 5s linear infinite;
    }

    @keyframes hero-sparkle {
        from {
            transform: translateY(0);
        }

        to {
            transform: translateY(-300px);
        }
    }

    .home-hero-logo {
        max-width: 150px;
        height: auto;
        filter: drop-shadow(0 10px 30px rgba(200, 100, 255, 0.4));
        animation: hero-float 3s ease-in-out infinite;
    }

    @keyframes hero-float {

        0%,
        100% {
            transform: translateY(0);
        }

        50% {
            transform: translateY(-10px);
        }
    }

    .home-hero-title {
        font-size: 2.5rem;
        font-weight: 800;
        color: #fff !important;
        margin-bottom: 15px;
        text-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
    }

    .home-hero-tagline {
        background: linear-gradient(135deg, var(--xez-primary) 0%, var(--xez-secondary) 100%);
        display: inline-block;
        padding: 10px 40px;
        border-radius: 50px;
        box-shadow: 0 8px 30px rgba(var(--xez-primary-rgb), 0.4);
    }

    .home-hero-tagline span {
        color: #fff;
        font-weight: 500;
    }

    .home-btn-primary {
        background: var(--xez-primary);
        color: #fff;
        padding: 12px 30px;
        border-radius: 12px;
        font-weight: 600;
        box-shadow: 0 5px 25px rgba(var(--xez-primary-rgb), 0.4);
        transition: all 0.3s ease;
    }

    .home-btn-primary:hover {
        background: var(--xez-secondary);
        transform: translateY(-3px);
        color: #fff;
    }

    .home-btn-outline {
        background: rgba(255, 255, 255, 0.1);
        color: #fff;
        padding: 12px 30px;
        border-radius: 12px;
        font-weight: 600;
        border: 1px solid rgba(255, 255, 255, 0.2);
        transition: all 0.3s ease;
    }

    .home-btn-outline:hover {
        background: rgba(255, 255, 255, 0.2);
        color: #fff;
        transform: translateY(-3px);
    }

    /* Announcement Bar */
    .home-announcement-bar {
        display: flex;
        align-items: center;
        background: linear-gradient(135deg, rgba(var(--xez-primary-rgb), 0.2) 0%, rgba(var(--xez-primary-rgb), 0.1) 100%);
        border: 1px solid rgba(var(--xez-primary-rgb), 0.3);
        border-radius: 50px;
        padding: 10px 20px;
        backdrop-filter: blur(10px);
        max-width: 600px;
        margin: 0 auto;
    }

    .announcement-icon {
        background: var(--xez-primary);
        color: #fff;
        width: 35px;
        height: 35px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-right: 15px;
        flex-shrink: 0;
        animation: pulse-announcement 2s ease-in-out infinite;
    }

    @keyframes pulse-announcement {

        0%,
        100% {
            transform: scale(1);
        }

        50% {
            transform: scale(1.1);
        }
    }

    .announcement-content {
        flex: 1;
        overflow: hidden;
        color: #fff;
        font-weight: 500;
        font-size: 0.9rem;
    }

    .announcement-content marquee {
        color: #fff;
    }

    /* Stats Bar */
    .home-stats-bar {
        display: flex;
        background: rgba(0, 0, 0, 0.6);
        backdrop-filter: blur(20px);
        border-radius: 20px;
        overflow: hidden;
        border: 1px solid rgba(255, 255, 255, 0.1);
    }

    .home-stat-item {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 20px 25px;
        border-right: 1px solid rgba(255, 255, 255, 0.1);
    }

    .home-stat-item:last-child {
        border-right: none;
    }

    .home-stat-info {
        display: flex;
        flex-direction: column;
    }

    .home-stat-label {
        color: rgba(255, 255, 255, 0.6);
        font-size: 0.75rem;
        margin-bottom: 4px;
    }

    .home-stat-value {
        color: var(--xez-primary);
        font-size: 1.8rem;
        font-weight: 700;
        line-height: 1;
    }

    .home-stat-value small {
        font-size: 0.7rem;
        color: rgba(255, 255, 255, 0.5);
        margin-left: 4px;
        font-weight: 400;
    }

    .home-stat-icon {
        width: 45px;
        height: 45px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255, 255, 255, 0.1);
        border-radius: 12px;
    }

    .home-stat-icon i {
        font-size: 1.2rem;
        color: rgba(255, 255, 255, 0.6);
    }

    .home-stat-highlight .home-stat-icon {
        background: var(--xez-primary);
    }

    .home-stat-highlight .home-stat-icon i {
        color: #fff;
    }

    /* Nav Cards */
    .home-nav-card {
        transition: all 0.3s ease;
    }

    .home-nav-card:hover {
        transform: translateY(-5px);
    }

    .home-nav-icon {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    /* Product Cards */
    .product-card {
        transition: all 0.3s ease;
    }

    .product-card:hover {
        transform: translateY(-5px);
    }

    .product-img-wrapper {
        aspect-ratio: 1/1;
    }

    .product-img {
        object-fit: cover;
        transition: transform 0.3s ease;
    }

    .product-card:hover .product-img {
        transform: scale(1.08);
    }

    /* Footer */
    .home-footer {
        background: linear-gradient(180deg, transparent 0%, rgba(0, 0, 0, 0.3) 100%);
        padding: 50px 0;
    }

    /* Responsive */
    @media (max-width: 768px) {
        .home-hero-title {
            font-size: 1.8rem;
        }

        .home-hero-logo {
            max-width: 100px;
        }

        .home-stats-bar {
            flex-wrap: wrap;
            border-radius: 16px;
        }

        .home-stat-item {
            flex: 1 1 50%;
            padding: 15px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .home-stat-item:nth-child(2) {
            border-right: none;
        }

        .home-stat-item:nth-child(3),
        .home-stat-item:nth-child(4) {
            border-bottom: none;
        }

        .home-stat-value {
            font-size: 1.4rem;
        }

        .home-hero-buttons .btn {
            margin-bottom: 10px;
        }
    }
</style>
