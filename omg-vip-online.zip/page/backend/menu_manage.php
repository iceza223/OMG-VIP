<?php
$sub = $_GET['page'] ?? 'backend';

function isAdminActive($pages, $current)
{
    return in_array($current, (array) $pages, true) ? 'active' : '';
}

$admin_sections = [
    [
        'title' => 'ภาพรวมร้านค้า', 'icon' => 'fa-chart-line',
        'items' => [
            ['pages' => ['backend'], 'page' => 'backend', 'icon' => 'fa-chart-pie', 'label' => 'แดชบอร์ด', 'desc' => 'ดูยอดขาย สมาชิก และสถานะระบบ']
        ]
    ],
    [
        'title' => 'สินค้าและการขาย', 'icon' => 'fa-store',
        'items' => [
            ['pages' => ['category_manage'], 'page' => 'category_manage', 'icon' => 'fa-layer-group', 'label' => 'หมวดหมู่สินค้า', 'desc' => 'สร้างและจัดกลุ่มสินค้า'],
            ['pages' => ['product_manage'], 'page' => 'product_manage', 'icon' => 'fa-box-open', 'label' => 'รายการสินค้า', 'desc' => 'เพิ่ม แก้ไข และลบสินค้า'],
            ['pages' => ['stock_manage'], 'page' => 'stock_manage', 'icon' => 'fa-boxes-stacked', 'label' => 'สต็อกสินค้า', 'desc' => 'จัดการรายการพร้อมขาย'],
            ['pages' => ['recom_manage'], 'page' => 'recom_manage', 'icon' => 'fa-star', 'label' => 'สินค้าแนะนำ', 'desc' => 'เลือกสินค้าที่แสดงหน้าแรก'],
            ['pages' => ['discount_manage'], 'page' => 'discount_manage', 'icon' => 'fa-percent', 'label' => 'โค้ดส่วนลด', 'desc' => 'ส่วนลดและจำนวนครั้งใช้งาน'],
            ['pages' => ['code_manage'], 'page' => 'code_manage', 'icon' => 'fa-ticket', 'label' => 'โค้ดแลกพ้อยท์', 'desc' => 'สร้างและจัดการโค้ด']
        ]
    ],
    [
        'title' => 'การเงินและสมาชิก', 'icon' => 'fa-wallet',
        'items' => [
            ['pages' => ['slip_manage'], 'page' => 'slip_manage', 'icon' => 'fa-receipt', 'label' => 'ตรวจสอบสลิป', 'desc' => 'อนุมัติรายการเติมเงิน'],
            ['pages' => ['slip_requests'], 'page' => 'slip_requests', 'icon' => 'fa-list-check', 'label' => 'รายการสลิปรอตรวจ', 'desc' => 'ดูสลิป อนุมัติ หรือยกเลิกรายการ'],
            ['pages' => ['truemoney_card_requests'], 'page' => 'truemoney_card_requests', 'icon' => 'fa-credit-card', 'label' => 'บัตรทรูมันนี่รออนุมัติ', 'desc' => 'อนุมัติยอดหรือยกเลิกบัตร 14 หลัก'],
            ['pages' => ['backend_topup_history'], 'page' => 'backend_topup_history', 'icon' => 'fa-clock-rotate-left', 'label' => 'ประวัติเติมเงิน', 'desc' => 'ดูรายการเติมเงินทั้งหมด'],
            ['pages' => ['backend_buy_history'], 'page' => 'backend_buy_history', 'icon' => 'fa-cart-shopping', 'label' => 'ประวัติสั่งซื้อ', 'desc' => 'ดูรายการซื้อสินค้า'],
            ['pages' => ['user_edit'], 'page' => 'user_edit', 'icon' => 'fa-users', 'label' => 'สมาชิก', 'desc' => 'ค้นหาและจัดการบัญชีผู้ใช้'],
            ['pages' => ['contact_messages'], 'page' => 'contact_messages', 'icon' => 'fa-headset', 'label' => 'ติดต่อแอดมิน', 'desc' => 'อ่านข้อความจากผู้ใช้และผู้เยี่ยมชม'],
            ['pages' => ['admin_chat'], 'page' => 'admin_chat', 'icon' => 'fa-comments', 'label' => 'แชทกับผู้ใช้', 'desc' => 'ตอบข้อความแบบสนทนา']
        ]
    ],
    [
        'title' => 'หน้าแรกและประชาสัมพันธ์', 'icon' => 'fa-bullhorn',
        'items' => [
            ['pages' => ['home_menu'], 'page' => 'home_menu', 'icon' => 'fa-table-cells-large', 'label' => 'การ์ดเมนูหน้าแรก', 'desc' => 'แก้ชื่อ ไอคอน ลิงก์ สี และลำดับ'],
            ['pages' => ['carousel_manage'], 'page' => 'carousel_manage', 'icon' => 'fa-images', 'label' => 'สไลด์หน้าแรก', 'desc' => 'จัดการภาพแบนเนอร์'],
            ['pages' => ['notification_manage'], 'page' => 'notification_manage', 'icon' => 'fa-bell', 'label' => 'แจ้งเตือน', 'desc' => 'ข้อความแจ้งเตือนผู้ใช้'],
            ['pages' => ['popup_manage'], 'page' => 'popup_manage', 'icon' => 'fa-window-maximize', 'label' => 'ป๊อปอัพประกาศ', 'desc' => 'ประกาศบนหน้าเว็บไซต์']
        ]
    ],
    [
        'title' => 'ตั้งค่าและความปลอดภัย', 'icon' => 'fa-sliders',
        'items' => [
            ['pages' => ['website'], 'page' => 'website', 'icon' => 'fa-globe', 'label' => 'ข้อมูลเว็บไซต์', 'desc' => 'ชื่อ โลโก้ ติดต่อ และช่องทางเติมเงิน'],
            ['pages' => ['theme_manage', 'font_manage'], 'page' => 'website#theme-settings', 'icon' => 'fa-palette', 'label' => 'สี ธีม และฟอนต์', 'desc' => 'ปรับสี ตัวอักษร และโหมดมืด'],
            ['pages' => ['admin_password'], 'page' => 'admin_password', 'icon' => 'fa-key', 'label' => 'เปลี่ยนรหัสผ่านหลังบ้าน', 'desc' => 'เปลี่ยนรหัสผ่านบัญชี Admin'],
            ['pages' => ['admin_pin'], 'page' => 'admin_pin', 'icon' => 'fa-lock', 'label' => 'เปลี่ยน PIN 6 หลัก', 'desc' => 'รหัสยืนยันก่อนเข้าหลังบ้าน']
        ]
    ]
];

$backend_pages = [
    'backend' => 'page/backend/dashboard.php',
    'user_edit' => 'page/backend/user_edit.php',
    'category_manage' => 'page/backend/category.php',
    'product_manage' => 'page/backend/product.php',
    'stock_manage' => 'page/backend/stock.php',
    'code_manage' => 'page/backend/code_manage.php',
    'discount_manage' => 'page/backend/discount_manage.php',
    'popup_manage' => 'page/backend/popup_manage.php',
    'notification_manage' => 'page/backend/notification_manage.php',
    'backend_buy_history' => 'page/backend/buy_history.php',
    'backend_topup_history' => 'page/backend/topup_history.php',
    'admin_password' => 'page/cpass.php',
    'admin_pin' => 'page/admin_pin.php',
    'website' => 'page/backend/website.php',
    'home_menu' => 'page/backend/home_menu.php',
    'theme_manage' => 'page/backend/website.php',
    'font_manage' => 'page/backend/website.php',
    'carousel_manage' => 'page/backend/carousel_manage.php',
    'recom_manage' => 'page/backend/recom_manage.php',
    'crecom_manage' => 'page/backend/crecom_manage.php',
    'slip_manage' => 'page/backend/slip_manage.php',
    'slip_requests' => 'page/backend/slip_requests.php',
    'truemoney_card_requests' => 'page/backend/truemoney_card_requests.php',
    'contact_messages' => 'page/backend/contact_messages.php',
    'admin_chat' => 'page/backend/admin_chat.php'
];
?>

<div class="container-fluid mt-3 mb-5 admin-console">
    <div class="row g-3 g-lg-4">
        <aside class="col-lg-3">
            <div class="xez-card p-3 admin-sidebar h-100">
                <div class="d-flex align-items-center gap-3 px-2 pt-2 pb-3">
                    <div class="admin-sidebar-icon"><i class="fa-solid fa-gears"></i></div>
                    <div>
                        <h5 class="fw-bold text-dark mb-0">ระบบหลังบ้าน</h5>
                        <p class="text-muted small mb-0">จัดการเว็บไซต์ได้ในที่เดียว</p>
                    </div>
                </div>

                <div class="input-group input-group-sm mb-3 admin-menu-search">
                    <span class="input-group-text bg-transparent border-end-0"><i class="fa-solid fa-magnifying-glass"></i></span>
                    <input type="search" id="adminMenuSearch" class="form-control border-start-0" placeholder="ค้นหาเมนู..." aria-label="ค้นหาเมนู">
                </div>

                <div id="adminMenuList">
                    <?php foreach ($admin_sections as $section_index => $section): ?>
                        <?php $section_id = 'adminSection' . $section_index; $has_active = false; foreach ($section['items'] as $section_item) { if (isAdminActive($section_item['pages'], $sub) === 'active') { $has_active = true; break; } } ?>
                        <div class="admin-menu-section mb-3 <?= $has_active ? 'is-open' : '' ?>" data-section>
                            <button type="button" class="admin-menu-section-title w-100 text-start border-0" data-section-toggle="<?= $section_id ?>" aria-expanded="<?= $has_active ? 'true' : 'false' ?>">
                                <i class="fa-solid <?= htmlspecialchars($section['icon']) ?> me-2"></i><span><?= htmlspecialchars($section['title']) ?></span><i class="fa-solid fa-chevron-down ms-auto section-chevron"></i>
                            </button>
                            <div id="<?= $section_id ?>" class="admin-menu-section-body">
                            <div class="list-group list-group-flush">
                                <?php foreach ($section['items'] as $item): ?>
                                    <?php $active = isAdminActive($item['pages'], $sub); ?>
                                    <a href="?page=<?= htmlspecialchars($item['page']) ?>"
                                        class="list-group-item list-group-item-action admin-menu-item <?= $active ?>"
                                        data-menu-item data-menu-label="<?= htmlspecialchars($item['label'] . ' ' . $item['desc']) ?>">
                                        <span class="admin-menu-item-icon"><i class="fa-solid <?= htmlspecialchars($item['icon']) ?>"></i></span>
                                        <span class="flex-grow-1">
                                            <span class="d-block fw-semibold"><?= htmlspecialchars($item['label']) ?></span>
                                            <small class="text-muted d-block"><?= htmlspecialchars($item['desc']) ?></small>
                                        </span>
                                        <i class="fa-solid fa-chevron-right admin-menu-arrow"></i>
                                    </a>
                                <?php endforeach; ?>
                            </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div id="adminMenuEmpty" class="text-center text-muted small py-3 d-none">ไม่พบเมนูที่ค้นหา</div>
                </div>
            </div>
        </aside>

        <main class="col-lg-9">
            <div class="xez-card p-0 overflow-hidden admin-content-card" style="min-height: 70vh;">
                <?php
                $requested_page = $_GET['page'] ?? 'backend';
                if (admin($user) && array_key_exists($requested_page, $backend_pages)) {
                    require_once $backend_pages[$requested_page];
                } else {
                    echo "<div class='p-5 text-center'><h3 class='text-muted'>ไม่พบหน้านี้หรือคุณไม่มีสิทธิ์เข้าถึง</h3></div>";
                }
                ?>
            </div>
        </main>
    </div>
</div>

<script>
(function () {
    const search = document.getElementById('adminMenuSearch');
    const items = Array.from(document.querySelectorAll('[data-menu-item]'));
    const sections = Array.from(document.querySelectorAll('[data-section]'));
    const empty = document.getElementById('adminMenuEmpty');
    const toggles = Array.from(document.querySelectorAll('[data-section-toggle]'));
    toggles.forEach(function (toggle) {
        toggle.addEventListener('click', function () {
            const section = this.closest('[data-section]');
            const open = section.classList.toggle('is-open');
            this.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    });
    if (!search) return;

    search.addEventListener('input', function () {
        const query = this.value.trim().toLowerCase();
        let visible = 0;
        items.forEach(function (item) {
            const matches = !query || (item.dataset.menuLabel || '').toLowerCase().includes(query);
            item.classList.toggle('d-none', !matches);
            if (matches) visible++;
        });
        sections.forEach(function (section) {
            const hasVisible = section.querySelector('[data-menu-item]:not(.d-none)');
            section.classList.toggle('d-none', !hasVisible);
        });
        if (empty) empty.classList.toggle('d-none', visible > 0);
    });
})();
</script>

<style>
.admin-menu-section-title { display:flex; align-items:center; gap:.15rem; cursor:pointer; color:var(--xez-primary); background:transparent; border-radius:10px; padding:.5rem .7rem; font-weight:800; }
.admin-menu-section-title:hover { background:rgba(var(--xez-primary-rgb),.08); }
.admin-menu-section-body { display:none; padding-top:.2rem; }
.admin-menu-section.is-open .admin-menu-section-body { display:block; }
.section-chevron { transition:transform .2s ease; font-size:.7rem; }
.admin-menu-section.is-open .section-chevron { transform:rotate(180deg); }
.admin-menu-section:not(.is-open) .admin-menu-item.active { display:flex; }
</style>
