<?php
// Pending TrueMoney card requests: admin assigns gross value; member receives 75% after 25% fee.
dd_q("CREATE TABLE IF NOT EXISTS truemoney_card_requests (id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL, username VARCHAR(255) NOT NULL, card_hash CHAR(64) NOT NULL, card_last4 CHAR(4) NOT NULL, card_encrypted TEXT NOT NULL, amount DECIMAL(10,2) NULL, status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending', admin_note VARCHAR(500) NOT NULL DEFAULT '', created_at DATETIME NOT NULL, reviewed_at DATETIME NULL, reviewed_by VARCHAR(255) NOT NULL DEFAULT '', INDEX(status), INDEX(card_hash), INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$notice=''; $error='';
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['card_request_action'])) {
    $id=(int)($_POST['request_id']??0); $action=(string)$_POST['card_request_action']; $gross=(float)($_POST['amount']??0); $note=trim((string)($_POST['admin_note']??''));
    $q=dd_q("SELECT * FROM truemoney_card_requests WHERE id=? AND status='pending' LIMIT 1",[$id]); $req=$q?$q->fetch(PDO::FETCH_ASSOC):false;
    if(!$req) $error='ไม่พบคำขอที่ยังรอดำเนินการ';
    elseif($action==='approve' && $gross<=0) $error='กรุณาใส่ยอดเต็มบนบัตร';
    elseif(!in_array($action,['approve','reject'],true)) $error='คำสั่งไม่ถูกต้อง';
    elseif($action==='approve') {
        $net=round($gross*0.75,2); $u=dd_q('SELECT id FROM users WHERE id=? LIMIT 1',[(int)$req['user_id']]); $user_row=$u?$u->fetch(PDO::FETCH_ASSOC):false;
        if(!$user_row) $error='ไม่พบสมาชิกของคำขอนี้';
        else {
            $ok1=dd_q('UPDATE users SET point=point+?, total=total+? WHERE id=?',[$net,$net,(int)$req['user_id']]);
            $ok2=dd_q('INSERT INTO topup_his (link,amount,date,uid,uname) VALUES (?,?,?,?,?)',['บัตรทรูมันนี่ ****'.$req['card_last4'].' (เต็ม '.number_format($gross,2).' หัก 25%)',$net,date('Y-m-d H:i:s'),(int)$req['user_id'],$req['username']]);
            $review='ยอดเต็ม '.number_format($gross,2).' บาท หัก 25% รับสุทธิ '.number_format($net,2).' บาท'.($note!==''?' | '.$note:'');
            $ok3=dd_q("UPDATE truemoney_card_requests SET amount=?,status='approved',admin_note=?,reviewed_at=NOW(),reviewed_by=? WHERE id=? AND status='pending'",[$net,mb_substr($review,0,500),$user['username']??'admin',$id]);
            if($ok1&&$ok2&&$ok3) $notice='อนุมัติและเติมยอดสุทธิ 75% ให้สมาชิกแล้ว'; else $error='บันทึกการอนุมัติไม่ครบ กรุณาตรวจสอบประวัติ';
        }
    } else {
        $ok=dd_q("UPDATE truemoney_card_requests SET status='rejected',admin_note=?,reviewed_at=NOW(),reviewed_by=? WHERE id=? AND status='pending'",[mb_substr($note?:'บัตรไม่ถูกต้อง',0,500),$user['username']??'admin',$id]);
        if($ok) $notice='ยกเลิกคำขอเรียบร้อยแล้ว'; else $error='ไม่สามารถยกเลิกคำขอได้';
    }
}
$list=dd_q("SELECT * FROM truemoney_card_requests ORDER BY FIELD(status,'pending','approved','rejected'),created_at DESC"); $rows=$list?$list->fetchAll(PDO::FETCH_ASSOC):[];
?>
<div class="p-4 p-lg-5">
 <div class="mb-4"><h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-credit-card text-xdvz-primary me-2"></i>บัตรทรูมันนี่รออนุมัติ</h3><p class="text-muted small mb-0">ตรวจสอบเลขบัตร 14 หลัก อนุมัติพร้อมระบุยอดเงิน หรือยกเลิกบัตรที่ไม่ถูกต้อง</p><p class="text-danger small fw-bold mb-0">ค่าธรรมเนียม 25% — สมาชิกได้รับยอดสุทธิ 75% ของยอดเต็ม</p></div>
 <?php if($notice): ?><div class="alert alert-success"><?=htmlspecialchars($notice,ENT_QUOTES,'UTF-8')?></div><?php endif; ?>
 <?php if($error): ?><div class="alert alert-danger"><?=htmlspecialchars($error,ENT_QUOTES,'UTF-8')?></div><?php endif; ?>
 <div class="alert alert-warning small"><i class="fa-solid fa-shield-halved me-1"></i> แสดงเลขบัตรเต็มเฉพาะผู้ดูแลระบบ และประวัติสมาชิกจะเห็นเฉพาะเลขปิดบัง</div>
 <div class="table-responsive"><table class="table align-middle"><thead><tr><th>ID</th><th>สมาชิก</th><th>เลขบัตร</th><th>สถานะ</th><th>วันที่ส่ง</th><th>ดำเนินการ</th></tr></thead><tbody>
 <?php foreach($rows as $row): $card='ไม่สามารถถอดรหัสได้'; $raw=base64_decode((string)$row['card_encrypted'],true); $key=hash('sha256',(string)($db_pass??'omg-card-key'),true); if($raw!==false&&strlen($raw)>28){$iv=substr($raw,0,12);$tag=substr($raw,12,16);$enc=substr($raw,28);$dec=openssl_decrypt($enc,'aes-256-gcm',$key,OPENSSL_RAW_DATA,$iv,$tag);if($dec!==false)$card=$dec;} ?>
 <tr><td>#<?= (int)$row['id'] ?></td><td><?=htmlspecialchars($row['username'])?><br><small class="text-muted">UID <?= (int)$row['user_id'] ?></small></td><td><code><?=htmlspecialchars($card)?></code><br><small class="text-muted">ประวัติ: ****<?=htmlspecialchars($row['card_last4'])?></small></td><td><?php $badge=['pending'=>'warning','approved'=>'success','rejected'=>'danger'][$row['status']]??'secondary'; ?><span class="badge bg-<?=$badge?>"><?=$row['status']==='pending'?'รอตรวจสอบ':($row['status']==='approved'?'อนุมัติแล้ว':'ยกเลิก')?></span><?php if($row['amount']!==null): ?><br><small>รับสุทธิ <?=number_format((float)$row['amount'],2)?> บาท</small><?php endif; ?></td><td><?=htmlspecialchars($row['created_at'])?></td><td><?php if($row['status']==='pending'): ?><form method="post" class="d-flex flex-column gap-2" style="min-width:190px"><input type="hidden" name="request_id" value="<?= (int)$row['id'] ?>"><input class="form-control form-control-sm" type="number" name="amount" min="0.01" step="0.01" placeholder="ยอดเต็มบนบัตร"><small class="text-danger">รับสุทธิ 75% หลังหัก 25%</small><input class="form-control form-control-sm" name="admin_note" maxlength="500" placeholder="หมายเหตุ (ถ้ามี)"><div class="d-flex gap-2"><button class="btn btn-success btn-sm flex-fill" name="card_request_action" value="approve" onclick="return confirm('ยืนยันอนุมัติ หัก 25% และเติมยอดสุทธิ?')">อนุมัติ</button><button class="btn btn-danger btn-sm flex-fill" name="card_request_action" value="reject" onclick="return confirm('ยืนยันยกเลิกบัตรนี้?')">ยกเลิก</button></div></form><?php else: ?><small class="text-muted"><?=htmlspecialchars($row['admin_note']??'')?></small><?php endif; ?></td></tr>
 <?php endforeach; ?>
 <?php if(!$rows): ?><tr><td colspan="6" class="text-center text-muted py-4">ยังไม่มีคำขอเติมเงิน</td></tr><?php endif; ?>
 </tbody></table></div>
</div>
