<?php
// Keep users signed in during normal periods of inactivity on the shared host.
// The application timeout below is the authoritative timeout; PHP's garbage
// collector is also extended so the server does not remove the session early.
ini_set('session.gc_maxlifetime', '2592000');
session_set_cookie_params([
    'lifetime' => 2592000,
    'path' => '/',
    'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
    'httponly' => true,
    'samesite' => 'Lax'
]);
session_start();
// Telegram-controlled maintenance lock. The webhook endpoint remains available so the owner can unlock.
require_once __DIR__ . '/telegram_lock_guard.php';
// Auto logout after 10 minutes of inactivity.
$session_timeout = 600;
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - (int)$_SESSION['LAST_ACTIVITY']) > $session_timeout) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
    }
    session_destroy();
    header('Location: ?page=login&timeout=1');
    exit;
}
$_SESSION['LAST_ACTIVITY'] = time();

error_reporting(0);
// Buffer output so server-side redirects still work after shared-host templates begin rendering.
ob_start();
require_once("system/a_func.php");
require_once __DIR__ . '/admin_pin_config.php';
// Enforce one active login session per account.
if (isset($_SESSION['id'])) {
    $session_file = __DIR__ . '/system/sessions/' . (int) $_SESSION['id'] . '.token';
    $token_read = is_file($session_file) ? @file_get_contents($session_file) : false;
    $active_token = $token_read === false ? null : trim((string) $token_read);
    if (empty($_SESSION['single_session_token'])) {
        if ($active_token !== null && $active_token !== '') {
            $_SESSION['single_session_token'] = $active_token;
        } elseif ($active_token === '') {
            $new_token = bin2hex(random_bytes(32));
            if (file_put_contents($session_file, $new_token, LOCK_EX) !== false) {
                $_SESSION['single_session_token'] = $new_token;
                $active_token = $new_token;
            }
        }
    } elseif ($active_token !== null && ($active_token === '' || !hash_equals($active_token, (string) $_SESSION['single_session_token']))) {
        $_SESSION = [];
        session_destroy();
        $_GET['page'] = 'login';
    }
}
if (isset($_SESSION['id'])) {
    $q1 = dd_q("SELECT * FROM users WHERE id = ? LIMIT 1", [$_SESSION['id']]);
    if ($q1->rowCount() == 1) {
        $user = $q1->fetch(PDO::FETCH_ASSOC);
    } else {
        session_destroy();
        $_GET['page'] = "login";
    }
}
if (($_GET['page'] ?? '') === 'admin_chat_api') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id']) || !is_numeric($_SESSION['id'])) { http_response_code(401); echo json_encode(['ok'=>false,'login_required'=>true,'message'=>'กรุณาเข้าสู่ระบบก่อนใช้งานแชท'], JSON_UNESCAPED_UNICODE); exit; }
    if (($config['chat_status'] ?? 'on') !== 'on') { http_response_code(503); echo json_encode(['ok'=>false,'chat_disabled'=>true,'message'=>'ขณะนี้ระบบแชทปิดให้บริการ'], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $conn->exec("CREATE TABLE IF NOT EXISTS admin_chat_messages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,sender ENUM('user','admin') NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_chat_user_created (user_id,created_at),INDEX idx_chat_sender (sender)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        try { $conn->exec("ALTER TABLE admin_chat_messages ADD COLUMN admin_read_at TIMESTAMP NULL DEFAULT NULL, ADD COLUMN user_read_at TIMESTAMP NULL DEFAULT NULL"); } catch (Throwable $migrationError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_user_id ON admin_chat_messages (user_id, id)"); } catch (Throwable $indexError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_admin_unread ON admin_chat_messages (sender, admin_read_at)"); } catch (Throwable $indexError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_user_unread ON admin_chat_messages (user_id, sender, user_read_at)"); } catch (Throwable $indexError) {}
        try { $conn->exec("CREATE INDEX IF NOT EXISTS idx_chat_user_admin_read ON admin_chat_messages (user_id, sender, admin_read_at)"); } catch (Throwable $indexError) {}

        $uid=(int)$_SESSION['id'];
        if ($_SERVER['REQUEST_METHOD']==='GET') { $markRead=$conn->prepare("UPDATE admin_chat_messages SET user_read_at=NOW() WHERE user_id=? AND sender='admin' AND user_read_at IS NULL"); $markRead->execute([$uid]); $q=$conn->prepare('SELECT id,sender,message,created_at FROM admin_chat_messages WHERE user_id=? ORDER BY id ASC LIMIT 200'); $q->execute([$uid]); echo json_encode(['ok'=>true,'messages'=>$q->fetchAll(PDO::FETCH_ASSOC)],JSON_UNESCAPED_UNICODE); exit; }
        $msg=trim((string)($_POST['message']??'')); if($msg===''||mb_strlen($msg)>3000){http_response_code(400);echo json_encode(['ok'=>false,'message'=>'กรุณาพิมพ์ข้อความไม่เกิน 3,000 ตัวอักษร'],JSON_UNESCAPED_UNICODE);exit;}
        $q=$conn->prepare("INSERT INTO admin_chat_messages (user_id,sender,message) VALUES (?,'user',?)");$q->execute([$uid,$msg]);echo json_encode(['ok'=>true,'message'=>'ส่งข้อความแล้ว'],JSON_UNESCAPED_UNICODE);exit;
    } catch (Exception $e) { http_response_code(500); echo json_encode(['ok'=>false,'message'=>'ระบบแชทขัดข้องชั่วคราว'],JSON_UNESCAPED_UNICODE); exit; }
}
if (($_GET['page'] ?? '') === 'admin_chat_unread') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id'], $user) || ($user['rank'] ?? '') != '1') { http_response_code(403); echo json_encode(['ok'=>false], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $conn->exec("CREATE TABLE IF NOT EXISTS admin_chat_messages (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,sender ENUM('user','admin') NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_chat_user_created (user_id,created_at),INDEX idx_chat_sender (sender)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        try { $conn->exec("ALTER TABLE admin_chat_messages ADD COLUMN admin_read_at TIMESTAMP NULL DEFAULT NULL, ADD COLUMN user_read_at TIMESTAMP NULL DEFAULT NULL"); } catch (Throwable $migrationError) {}
        $count=(int)$conn->query("SELECT COUNT(*) FROM admin_chat_messages WHERE sender='user' AND admin_read_at IS NULL")->fetchColumn();
        echo json_encode(['ok'=>true,'unread'=>$count],JSON_UNESCAPED_UNICODE); exit;
    } catch (Exception $e) { http_response_code(500); echo json_encode(['ok'=>false,'unread'=>0],JSON_UNESCAPED_UNICODE); exit; }
}
if (($_GET['page'] ?? '') === 'truemoney_card_unread') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id'], $user) || ($user['rank'] ?? '') != '1') { http_response_code(403); echo json_encode(['ok'=>false], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $q = $conn->query("SELECT COUNT(*) FROM truemoney_card_requests WHERE status='pending'");
        echo json_encode(['ok'=>true,'pending'=>(int)$q->fetchColumn()], JSON_UNESCAPED_UNICODE); exit;
    } catch (Throwable $e) {
        echo json_encode(['ok'=>true,'pending'=>0], JSON_UNESCAPED_UNICODE); exit;
    }
}
if (($_GET['page'] ?? '') === 'user_chat_unread') {
    header('Content-Type: application/json; charset=utf-8');
    if (!isset($_SESSION['id']) || !is_numeric($_SESSION['id'])) { http_response_code(401); echo json_encode(['ok'=>false], JSON_UNESCAPED_UNICODE); exit; }
    if (($config['chat_status'] ?? 'on') !== 'on') { echo json_encode(['ok'=>true,'unread'=>0,'chat_disabled'=>true], JSON_UNESCAPED_UNICODE); exit; }
    try {
        $uid=(int)$_SESSION['id'];
        $q=$conn->prepare("SELECT COUNT(*) FROM admin_chat_messages a WHERE a.user_id=? AND a.sender='admin' AND a.user_read_at IS NULL");
        $q->execute([$uid]); echo json_encode(['ok'=>true,'unread'=>(int)$q->fetchColumn()],JSON_UNESCAPED_UNICODE); exit;
    } catch (Exception $e) { http_response_code(500); echo json_encode(['ok'=>false,'unread'=>0],JSON_UNESCAPED_UNICODE); exit; }
}
$get_static = dd_q("SELECT * FROM static");
$static = $get_static->fetch(PDO::FETCH_ASSOC);
$site_logo = $config['logo'] ?? 'assets/omg-logo-animated.gif';
// Use a local logo when the configured URL points to the retired external domain.
if (preg_match('#^https?://(?:www\.)?omgvip\.shop/#i', (string)$site_logo)) {
    $site_logo = 'assets/omg-logo-transparent.webp';
}
$requested_page_for_assets = $_GET['page'] ?? '';
$needs_recaptcha = in_array($requested_page_for_assets, ['login', 'register'], true);
$datatable_pages = ['user_edit', 'category_manage', 'product_manage', 'stock_manage', 'code_manage', 'discount_manage', 'popup_manage', 'notification_manage', 'backend_buy_history', 'backend_topup_history', 'carousel_manage'];
$needs_datatables = in_array($requested_page_for_assets, $datatable_pages, true);
if (in_array($site_logo, ['assets/omg-logo-new.webp', 'assets/omg-logo-animated.gif', 'assets/omg-logo-blue.webp', 'assets/omg-logo.webp', 'assets/omg-logo.png', 'assets/omg-logo-new.png'], true)) {
    $site_logo = 'assets/omg-logo-transparent.webp';
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="DOWNLOAD THLIVEMOD วิธีใช้งาน รายละเอียดและชื้อกลุ่มระบบอัตโนมัติ">
    <meta property="og:title" content="<?php echo $config['name']; ?> | Homepage">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://<?php echo $config['name']; ?>.ovdc.xyz">
    <meta property="og:image" content="<?php echo htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8'); ?>">
    <meta property="og:description" content="<?php echo $config['des']; ?>">
    <title>THLIVEMOD – กลุ่มTelegram</title>
    <link rel="shortcut icon" href="<?php echo htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8'); ?>" type="image/png" sizes="16x16">
    <link rel="stylesheet" href="system/css/second.css?v=20260902-navfix">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"
        integrity="sha512-pumBsjNRGGqkPzKHndZMaAG+bir374sORyzM3uulLV14lN5LyykqNk8eEeUlUkB3U0M4FApyaHraT65ihJhDpQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <?php if ($needs_datatables): ?>
    <link rel="stylesheet" href="//cdn.datatables.net/1.13.4/css/jquery.dataTables.min.css">
    <script src="//cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <?php endif; ?>
    <link href="https://kit-pro.fontawesome.com/releases/v6.2.0/css/pro.min.css" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php if ($needs_recaptcha): ?><script src="https://www.google.com/recaptcha/api.js" async defer></script><?php endif; ?>
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php
    $font_options = [
        'kanit' => ['url' => 'Kanit:wght@400;500;600;700', 'family' => "'Kanit', sans-serif"],
        'prompt' => ['url' => 'Prompt:wght@400;500;600;700', 'family' => "'Prompt', sans-serif"],
        'sarabun' => ['url' => 'Sarabun:wght@400;500;600;700', 'family' => "'Sarabun', sans-serif"],
        'ibm_plex_sans_thai' => ['url' => 'IBM+Plex+Sans+Thai:wght@400;500;600;700', 'family' => "'IBM Plex Sans Thai', sans-serif"],
    ];
    $selected_font = $font_options[$config['font_family'] ?? 'kanit'] ?? $font_options['kanit'];
    // Match the OMG logo: gold, amber orange, lime accents, and deep wine surfaces.
    $brand_main_color = strtolower(trim($config['main_color'] ?? '#b8d82e'));
    $brand_secondary_color = strtolower(trim($config['sec_color'] ?? '#ffb300'));
    $brand_border_color = strtolower(trim($config['border_color'] ?? '#214d2b'));
    if (!preg_match('/^#[0-9a-fA-F]{6}$/', $brand_border_color) || in_array($brand_border_color, ['#ff0000', '#1e3a8a'], true)) {
        $brand_border_color = '#214d2b';
    }
    $theme_colors = [
        'text_color' => '#f3ffe1',
        'bg_color' => '#050a06',
        'card_color' => '#0b160d',
        'button_color' => '#b8d82e',
        'success_color' => '#66d63c',
        'warning_color' => '#b8d82e',
        'danger_color' => '#ff4d4d',
        'info_color' => '#7cff4d',
    ];
    foreach ($theme_colors as $color_key => $color_fallback) {
        $color_value = strtolower(trim($config[$color_key] ?? $color_fallback));
        $theme_colors[$color_key] = preg_match('/^#[0-9a-fA-F]{6}$/', $color_value) ? $color_value : $color_fallback;
    }
    $legacy_palette = [
        ['#ff0000', '#ff0000'],
        ['#facc15', '#16a34a'],
        ['#2563eb', '#06b6d4'],
        ['#00d4ff', '#ff0080'],
    ];
    foreach ($legacy_palette as $legacy_colors) {
        if ($brand_main_color === $legacy_colors[0] && $brand_secondary_color === $legacy_colors[1]) {
            $brand_main_color = '#b8d82e';
            $brand_secondary_color = '#ffb300';
            break;
        }
    }
    // Migrate the previous blue/cyan and other legacy defaults to the logo-matched palette.
    if ($theme_colors['button_color'] === '#2563eb') {
        $theme_colors['button_color'] = '#b8d82e';
    }
    if ($theme_colors['bg_color'] === '#060b1a') {
        $theme_colors['bg_color'] = '#08070a';
    }
    if ($theme_colors['card_color'] === '#0f172a') {
        $theme_colors['card_color'] = '#0b160d';
    }
    if ($theme_colors['text_color'] === '#e2e8f0') {
        $theme_colors['text_color'] = '#f3ffe1';
    }
    if ($theme_colors['success_color'] === '#22c55e') {
        $theme_colors['success_color'] = '#b8d82e';
    }
    if ($theme_colors['warning_color'] === '#f59e0b') {
        $theme_colors['warning_color'] = '#b8d82e';
    }
    if ($theme_colors['danger_color'] === '#ef4444') {
        $theme_colors['danger_color'] = '#ff4d4d';
    }
    if ($theme_colors['info_color'] === '#38bdf8') {
        $theme_colors['info_color'] = '#7cff4d';
    }
    $font_url = 'https://fonts.googleapis.com/css2?family=' . $selected_font['url'] . '&display=swap';
    ?>
    <link href="<?= htmlspecialchars($font_url, ENT_QUOTES, 'UTF-8') ?>" rel="stylesheet">
    <link rel="stylesheet" href="system/css/option.css?v=20260902-navfix">
    <style>
        <?php
        function hexToRgb($hex)
        {
            $hex = str_replace("#", "", $hex);
            if (strlen($hex) == 3) {
                $r = hexdec(substr($hex, 0, 1) . substr($hex, 0, 1));
                $g = hexdec(substr($hex, 1, 1) . substr($hex, 1, 1));
                $b = hexdec(substr($hex, 2, 1) . substr($hex, 2, 1));
            } else {
                $r = hexdec(substr($hex, 0, 2));
                $g = hexdec(substr($hex, 2, 2));
                $b = hexdec(substr($hex, 4, 2));
            }
            return "$r, $g, $b";
        }
        ?>
        /* Dynamic Color Injection from Database */
        :root {
            --xez-primary:
                <?= htmlspecialchars($brand_main_color, ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-primary-rgb:
                <?= hexToRgb($brand_main_color) ?>
            ;
            --xez-secondary:
                <?= htmlspecialchars($brand_secondary_color, ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-text-color:
                <?= htmlspecialchars($theme_colors['text_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-border:
                <?= htmlspecialchars($brand_border_color, ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-bg:
                <?= htmlspecialchars($theme_colors['bg_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-card:
                <?= htmlspecialchars($theme_colors['card_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-button:
                <?= htmlspecialchars($theme_colors['button_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-success:
                <?= htmlspecialchars($theme_colors['success_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-success-rgb:
                <?= hexToRgb($theme_colors['success_color']) ?>
            ;
            --xez-warning:
                <?= htmlspecialchars($theme_colors['warning_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-danger:
                <?= htmlspecialchars($theme_colors['danger_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
            --xez-info:
                <?= htmlspecialchars($theme_colors['info_color'], ENT_QUOTES, 'UTF-8') ?>
            ;
        }
        .theme-light,
        body:not(.theme-dark) {
            --bg-body: var(--xez-bg);
            --bg-card: var(--xez-card);
            --bg-card-alt: var(--xez-card);
            --bg-input: var(--xez-card);
            --bg-secondary: var(--xez-card);
            --border-main: var(--xez-border);
            --border-light: var(--xez-border);
            --border-color: var(--xez-border);
        }
        .theme-dark {
            --bg-body: var(--xez-bg);
            --bg-card: var(--xez-card);
            --bg-card-alt: var(--xez-card);
            --bg-input: var(--xez-card);
            --bg-secondary: var(--xez-card);
            --border-main: var(--xez-border);
            --border-light: var(--xez-border);
            --border-color: var(--xez-border);
        }
        .xez-btn-cyan,
        .btn-login,
        .bg-main {
            background: var(--xez-button) !important;
            border-color: var(--xez-button) !important;
        }
        .btn-navbar-register {
            background: linear-gradient(135deg, var(--xez-button), var(--xez-secondary)) !important;
        }
        .xez-btn-cyan:hover,
        .btn-login:hover {
            background: var(--xez-secondary) !important;
        }
        /* Shop action buttons: warm gold/orange palette. */
        .xez-detail-btn {
            background: linear-gradient(135deg, #f59e0b 0%, #f97316 100%) !important;
            border-color: #f59e0b !important;
            color: #1c1917 !important;
            box-shadow: 0 0 14px rgba(249, 115, 22, 0.28);
        }
        .xez-detail-btn:hover,
        .xez-order-btn:hover {
            background: linear-gradient(135deg, #fbbf24 0%, #fb923c 100%) !important;
            border-color: #fbbf24 !important;
            color: #1c1917 !important;
        }
        .xez-order-btn {
            background: linear-gradient(135deg, #facc15 0%, #f97316 100%) !important;
            border-color: #facc15 !important;
            color: #1c1917 !important;
            box-shadow: 0 0 16px rgba(250, 204, 21, 0.32);
        }
        .xez-soldout-btn {
            background: #991b1b !important;
            border-color: #7f1d1d !important;
            color: #fff !important;
            opacity: 1 !important;
        }
        .bg-success,
        .btn-success {
            background-color: var(--xez-success) !important;
            border-color: var(--xez-success) !important;
        }
        .bg-warning,
        .btn-warning {
            background-color: var(--xez-warning) !important;
            border-color: var(--xez-warning) !important;
        }
        .bg-danger,
        .btn-danger {
            background-color: var(--xez-danger) !important;
            border-color: var(--xez-danger) !important;
        }
        .bg-info,
        .btn-info {
            background-color: var(--xez-info) !important;
            border-color: var(--xez-info) !important;
        }
        .text-success { color: var(--xez-success) !important; }
        .text-warning { color: var(--xez-warning) !important; }
        .text-danger { color: var(--xez-danger) !important; }
        .text-info { color: var(--xez-info) !important; }
        body {
            color: var(--xez-text-color);
        }
        .text-dark {
            color: var(--xez-text-color) !important;
        }
        *:not(i) {
            font-family: <?= $selected_font['family'] ?> !important;
        }
        body {
            font-size: <?= max(14, min(20, (int) ($config['font_size'] ?? 16))) ?>px;
        }
        /* Keep the logged-in account summary visible beside the mobile menu button. */
        .navbar-user-mobile {
            min-width: 112px;
            max-width: 190px;
            padding: 0.3rem 0.55rem;
            line-height: 1.15;
            border: 1px solid rgba(255, 209, 102, 0.72);
            border-radius: 10px;
            background: rgba(22, 13, 23, 0.94);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.18);
        }
        .navbar-user-mobile .nav-user-mobile-name {
            display: block;
            max-width: 100%;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            color: #ffffff !important;
            font-size: 0.9em;
        }
        .navbar-user-mobile .nav-user-mobile-balance {
            display: block;
            white-space: nowrap;
            color: #ffd166 !important;
            font-size: 0.82em;
        }
        @media (max-width: 575.98px) {
            .navbar-brand {
                min-width: 0;
                flex: 1 1 auto;
            }
            .navbar-brand img {
                max-width: 36px;
                height: auto;
            }
            .navbar-text-brand {
                min-width: 0;
                max-width: 38vw;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                font-size: 0.88em;
            }
            .navbar-user-mobile {
                flex: 0 1 auto;
                min-width: 100px;
                max-width: 36vw;
                padding: 0.28rem 0.45rem;
                margin-left: 0.3rem !important;
                margin-right: 0.3rem !important;
            }
            .navbar-user-mobile .nav-user-mobile-name {
                font-size: 0.8em;
            }
            .navbar-user-mobile .nav-user-mobile-balance {
                font-size: 0.74em;
            }
            .navbar-toggler {
                flex: 0 0 auto;
                padding: 0.25rem 0.45rem;
                color: #ffd166 !important;
                background: rgba(255, 179, 0, 0.12) !important;
                border: 1px solid rgba(255, 209, 102, 0.72) !important;
                border-radius: 8px;
            }
        }
    </style>
</head>

<body class="theme-<?= $config['theme_mode'] ?? 'light' ?>">
    <!-- Preloader -->
    <div id="preloader">
        <div class="loader-content">
            <div class="loader-logo">
                <img src="<?= htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8') ?>" alt="Logo">
            </div>
            <div class="loader-bar">
                <div class="loader-progress"></div>
            </div>
            <p class="loader-text mt-3 fw-bold"><?= $config['name'] ?></p>
        </div>
    </div>
    <nav class="navbar navbar-expand-lg sticky-top main-navbar">
        <div class="container container-sm">
            <a class="navbar-brand d-flex align-items-center" href="/?page=home">
                <img src="<?= htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8') ?>" height="40px" width="auto" class="me-2">
                <span class="navbar-text-brand fw-bold"><?= $config['name'] ?></span>
            </a>
            <?php if (isset($_SESSION['id']) && isset($user)): ?>
                <div class="navbar-user-mobile d-lg-none text-end" aria-label="ข้อมูลบัญชีผู้ใช้">
                    <span class="nav-user-mobile-name fw-bold"><?= htmlspecialchars($user['username'] ?? '', ENT_QUOTES, 'UTF-8') ?></span>
                    <span class="nav-user-mobile-balance text-xez-primary fw-bold">ยอดเงิน ฿<?= number_format((float) ($user['point'] ?? 0), 2) ?></span>
                </div>
            <?php endif; ?>
            <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent">
                <i class="fa-solid fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=home">
                            <i class="fa-solid fa-house me-1"></i> หน้าหลัก
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=topup">
                            <i class="fa-solid fa-coins me-1"></i> เติมเงิน
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="/?page=home">
                            <i class="fa-solid fa-shopping-basket me-2"></i> ร้านค้า
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link-xez nav-link" href="<?= isset($_SESSION['id']) ? '?page=profile&subpage=buyhis' : '?page=login' ?>">
                            <i class="fa-solid fa-clock-rotate-left me-1"></i> ประวัติการซื้อ
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link-xez nav-link dropdown-toggle" href="#" id="contactDropdown" role="button" data-bs-toggle="dropdown">
                            <i class="fa-solid fa-phone me-1"></i> ติดต่อ
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end border-0 shadow-sm" style="border-radius: 15px;">
                            <?php if(($config['contact_facebook'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_facebook'] ?>" target="_blank"><i class="fa-brands fa-facebook text-primary me-2"></i> Facebook</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_line'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_line'] ?>" target="_blank"><i class="fa-brands fa-line text-success me-2"></i> Line Official</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_discord'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_discord'] ?>" target="_blank"><i class="fa-brands fa-discord text-info me-2"></i> Discord</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_messenger'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_messenger'] ?>" target="_blank"><i class="fa-brands fa-facebook-messenger text-primary me-2"></i> Messenger</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram1'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_telegram1'] ?>" target="_blank"><i class="fa-brands fa-telegram text-info me-2"></i> Telegram 1</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram2'] ?? '#') != '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact_telegram2'] ?>" target="_blank"><i class="fa-brands fa-telegram text-info me-2"></i> Telegram 2</a></li>
                            <?php endif; ?>
                            <?php if(($config['contact'] ?? '#') != '#' && ($config['contact_facebook'] ?? '#') == '#'): ?>
                            <li><a class="dropdown-item py-2" href="<?= $config['contact'] ?>" target="_blank"><i class="fa-solid fa-link me-2"></i> ช่องทางอื่นๆ</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                </ul>
                <div class="d-flex align-items-center">
                    <div class="nav-separator mx-3 d-none d-lg-block"></div>
                    <?php if (!isset($_SESSION['id'])): ?>
                        <a href="?page=login" class="nav-link-xez nav-link fw-bold me-3">
                            <i class="fa-solid fa-sign-in me-1"></i> เข้าสู่ระบบ
                        </a>
                        <a href="?page=register" class="btn btn-navbar-register">
                            <i class="fa-solid fa-user-plus me-1"></i> สมัครสมาชิก
                        </a>
                    <?php else: ?>
                        <?php if (($config['chat_status'] ?? 'on') === 'on'): ?>
                        <?php if (($user['rank'] ?? '') == '1'): ?>
                            <a href="?page=admin_chat" id="adminChatBell" class="nav-link position-relative me-2" aria-label="ข้อความแชทใหม่" title="ข้อความแชทใหม่"><i class="fa-solid fa-bell"></i><span id="adminChatBellBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">0</span></a>
                            <a href="?page=truemoney_card_requests" id="cardRequestBell" class="nav-link position-relative me-2 text-warning" aria-label="บัตร TrueMoney ใหม่" title="มีคำขอบัตร TrueMoney ใหม่"><i class="fa-solid fa-credit-card"></i><span id="cardRequestBellBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">0</span></a>
                        <?php else: ?>
                            <a href="#" id="userChatBell" class="nav-link position-relative me-2" aria-label="ข้อความจากแอดมิน" title="ข้อความจากแอดมิน"><i class="fa-solid fa-bell"></i><span id="userChatBellBadge" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger d-none">0</span></a>
                            <a href="#" id="userChatNotifyFab" class="user-chat-notify-fab" aria-label="แอดมินตอบแชทแล้ว" title="แอดมินตอบแชทแล้ว"><i class="fa-solid fa-user-tie"></i><span id="userChatNotifyLabel" class="user-chat-notify-label">แอดมินตอบแชท</span><span id="userChatNotifyBadge" class="user-chat-notify-badge d-none">0</span></a>
                        <?php endif; ?>
                        <?php endif; ?>
                        <div class="dropdown">
                            <a class="nav-link dropdown-toggle fw-bold" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown">
                                <i class="fa-solid fa-circle-user me-1"></i>
                                <span class="nav-user-summary d-inline-flex align-items-center flex-wrap gap-2">
                                    <span class="nav-user-name"><?= htmlspecialchars($user["username"], ENT_QUOTES, 'UTF-8') ?></span>
                                    <span class="nav-user-balance bg-primary-soft text-xez-primary px-2 py-1 rounded-pill" title="ยอดเงินคงเหลือ">
                                        ยอดเงิน ฿<?= number_format((float) ($user['point'] ?? 0), 2) ?>
                                    </span>
                                </span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end shadow border-0 p-2">
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile"><i
                                            class="fa-solid fa-user me-2"></i> โปรไฟล์</a></li>
                                <li><a class="dropdown-item rounded-3 mb-1" href="?page=profile&subpage=buyhis"><i
                                            class="fa-solid fa-clock-rotate-left me-2"></i> ประวัติการสั่งซื้อ</a></li>
                                <?php if ($user["rank"] == "1"): ?>
                                    <li><a class="dropdown-item text-primary rounded-3 mb-1" href="?page=backend"><i
                                                class="fa-solid fa-shield-halved me-2"></i> จัดการหลังร้าน</a></li>
                                <?php endif; ?>
                                <li>
                                    <hr class="dropdown-divider">
                                </li>
                                <li><a class="dropdown-item text-danger rounded-3" href="?page=logout"><i
                                            class="fa-solid fa-sign-out me-2"></i> ออกจากระบบ</a></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <?php
    function admin($user)
    {
        return (isset($_SESSION['id']) && $user["rank"] == "1");
    }

    $page = $_GET['page'] ?? '';
    $backend_pages = ['backend', 'home_menu', 'theme_manage', 'font_manage', 'user_edit', 'category_manage', 'product_manage', 'stock_manage', 'code_manage', 'discount_manage', 'popup_manage', 'notification_manage', 'backend_buy_history', 'backend_topup_history', 'truemoney_card_requests', 'slip_requests', 'admin_password', 'admin_pin', 'website', 'carousel_manage', 'recom_manage', 'crecom_manage', 'apibyshop', 'apibyshop_his', 'slip_manage', 'contact_messages', 'admin_chat'];

    // Require a 6-digit PIN only for rank-1 administrators entering the backend.
    if (isset($_SESSION['id'], $user) && ($user['rank'] ?? '') == '1' && in_array($page, $backend_pages, true) && empty($_SESSION['admin_pin_verified'])) {
        $admin_pin_error = '';
        if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_pin'])) {
            $admin_pin = preg_replace('/\D+/', '', (string) $_POST['admin_pin']);
            if (hash_equals($admin_pin_hash, hash('sha256', $admin_pin))) {
                $_SESSION['admin_pin_verified'] = true;
                header('Location: ?page=backend');
                exit;
            }
            $admin_pin_error = 'รหัส PIN ไม่ถูกต้อง';
        }
        ob_clean();
        ?>
        <!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ยืนยัน PIN Admin</title>
        <style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#08070a;font-family:Arial,sans-serif}.pin-box{width:min(92vw,360px);padding:32px 24px;text-align:center;background:#160d17;color:#fff6df;border:1px solid #6b2145;border-radius:20px;box-shadow:0 15px 50px #000}.pin-box h2{margin:10px 0 8px}.pin-box p{color:#d7c5a5}.pin-input{width:100%;padding:14px 8px;box-sizing:border-box;text-align:center;font-size:28px;letter-spacing:12px;border-radius:10px;border:1px solid #ffb300;background:#08070a;color:#fff;outline:none}.pin-btn{margin-top:18px;width:100%;padding:13px;border:0;border-radius:10px;background:linear-gradient(135deg,#facc15,#f97316);font-weight:bold;font-size:16px;cursor:pointer}.error{color:#ff6b81;margin:12px 0}</style></head><body><main class="pin-box"><div style="font-size:42px">🔒</div><h2>ยืนยันสิทธิ์ Admin</h2><p>กรุณากรอกรหัส PIN 6 หลัก<br>เพื่อเข้าสู่หน้าจัดการหลังบ้าน</p><?php if ($admin_pin_error): ?><div class="error"><?= htmlspecialchars($admin_pin_error, ENT_QUOTES, 'UTF-8') ?></div><?php endif; ?><form method="post"><input class="pin-input" name="admin_pin" type="password" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" minlength="6" autocomplete="one-time-code" autofocus required><button class="pin-btn" type="submit">เข้าสู่หลังบ้าน</button></form></main></body></html>
        <?php
        exit;
    }

    // Backend access is protected by the existing rank-1 administrator session.
    $backend_locked = false;

    if ($page == "" || $page == "landing") {
        // หน้า Landing (http://localhost/)
        require_once('page/landing.php');
    } elseif ($page == "home") {
        // หน้า Home (http://localhost/?page=home)
        require_once('page/simple.php');
    } elseif ($page == "download") {
        require_once('download_page.php');
    } elseif ($page == "login" && !isset($_SESSION['id'])) {
        require_once('page/login.php');
    } elseif ($page == "register" && !isset($_SESSION['id'])) {
        require_once('page/register.php');
    } elseif ($page == "logout" && isset($_SESSION['id'])) {
        session_destroy();
        echo "<script>window.location.href = './';</script>";
    } elseif ($page == "profile" && isset($_SESSION['id'])) {
        require_once('page/profile.php');
    } elseif ($page == "buyhis" && isset($_SESSION['id'])) {
        $_GET['page'] = 'profile';
        $_GET['subpage'] = 'buyhis';
        require_once('page/profile.php');
    } elseif ($page == "topuphis" && isset($_SESSION['id'])) {
        $_GET['page'] = 'profile';
        $_GET['subpage'] = 'topuphis';
        require_once('page/profile.php');
    } elseif ($page == "topup" && isset($_SESSION['id'])) {
        require_once('page/topup.php');
    } elseif ($page == "slip" && isset($_SESSION['id'])) {
        if (($config['topup_slip_status'] ?? 'on') === 'on') {
            require_once('page/slip.php');
        } else {
            echo '<div class="container-sm mt-5"><div class="alert alert-warning text-center">ช่องทางเติมเงินนี้ถูกปิดให้บริการชั่วคราว</div></div>';
        }
    } elseif ($page == "redeem" && isset($_SESSION['id'])) {
        if (($config['topup_redeem_status'] ?? 'on') === 'on') {
            require_once('page/redeem.php');
        } else {
            echo '<div class="container-sm mt-5"><div class="alert alert-warning text-center">ช่องทางเติมเงินนี้ถูกปิดให้บริการชั่วคราว</div></div>';
        }
    } elseif ($page == "download") {
        require_once('page/member_download.php');
    } elseif ($page == "shop") {
        require_once('page/shop.php');
    } elseif ($page == "product" && isset($_GET['id'])) {
        require_once('page/product.php');
    } elseif (admin($user) && in_array($page, $backend_pages, true)) {
        require_once('page/backend/menu_manage.php');
    } else {
        require_once('page/landing.php');
    }
    ?>

    <!-- Modal Buy -->
    <div class="modal fade" id="buy_count" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content" style="border-radius: 15px; border: none;">
                <div class="modal-header border-0">
                    <h5 class="modal-title fw-bold" id="modal_title">สั่งซื้อสินค้า</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body p-4">
                    <!-- ล็อกและซ่อนจำนวนสินค้า: ซื้อได้ครั้งละ 1 ชิ้น -->
                    <input type="hidden" id="b_count" value="1">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="text-muted small">คงเหลือ: <span id="s" class="fw-bold text-dark">0</span>
                            ชิ้น</span>
                        <span class="badge bg-primary px-3 py-2" style="font-size: 1rem;">ราคา <span id="b">0</span>
                            ฿</span>
                    </div>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn xez-btn-cyan w-100" onclick="buybox()">ยืนยันการสั่งซื้อ</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Popup system removed -->

    <style>
        /* Multi-Page Popup Styles */
        .popup-content {
            border-radius: 24px !important;
            border: none !important;
            overflow: hidden;
            background: var(--bg-card);
            box-shadow: 0 25px 80px rgba(0, 0, 0, 0.3);
        }

        .popup-slides {
            position: relative;
            overflow: hidden;
        }

        .popup-slide {
            display: none;
            animation: slideIn 0.4s ease;
        }

        .popup-slide.active {
            display: block;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(30px);
            }

            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .popup-image {
            max-height: 200px;
            overflow: hidden;
        }

        .popup-image img {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .popup-body {
            padding: 24px;
            text-align: center;
        }

        .popup-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--xez-primary), var(--xez-secondary));
            color: #fff;
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
            margin-bottom: 12px;
            animation: pulse 2s infinite;
        }

        @keyframes pulse {

            0%,
            100% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.05);
            }
        }

        .popup-title {
            font-weight: 700;
            margin-bottom: 8px;
            color: var(--text-heading);
        }

        .popup-text {
            color: var(--text-body);
            margin-bottom: 0;
        }

        .popup-indicators {
            display: flex;
            justify-content: center;
            gap: 8px;
            padding: 0 24px 16px;
        }

        .indicator {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: var(--border-main);
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .indicator.active {
            width: 28px;
            border-radius: 10px;
            background: var(--xez-primary);
        }

        .popup-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 24px;
            background: var(--bg-card-alt);
            border-top: 1px solid var(--border-light);
        }

        .popup-btn {
            background: linear-gradient(135deg, var(--xez-primary), var(--xez-secondary));
            color: #fff;
            border: none;
            padding: 10px 24px;
            border-radius: 12px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .popup-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(var(--xez-primary-rgb), 0.4);
            color: #fff;
        }

        /* ปรับกล่องประกาศให้กะทัดรัดบนมือถือ */
        @media (max-width: 576px) {
            #xez_popup .modal-dialog {
                width: calc(100% - 24px);
                max-width: 420px;
                margin: 12px auto;
            }

            #xez_popup .modal-content {
                max-height: 78vh;
                border-radius: 18px !important;
                overflow-y: auto;
            }

            #xez_popup .modal-header {
                padding: 12px 16px;
            }

            #xez_popup .modal-title {
                font-size: 1.15rem;
            }

            #xez_popup img.popup-image {
                width: 100%;
                height: auto !important;
                max-height: none !important;
                object-fit: contain !important;
                display: block;
            }

            #xez_popup .popup-slide > div {
                padding: 16px !important;
            }

            #xez_popup .popup-slide h3 {
                font-size: 1.3rem;
                margin-bottom: 6px;
            }

            #xez_popup .popup-text {
                font-size: 0.95rem;
                line-height: 1.5;
            }

            #xez_popup .popup-footer {
                padding: 12px 16px;
                gap: 10px;
            }

            #xez_popup .popup-btn {
                padding: 8px 16px;
                font-size: 0.95rem;
            }
        }

        @media (max-width: 380px) {
            #xez_popup .modal-content {
                max-height: 82vh;
            }

            #xez_popup img.popup-image {
                height: auto !important;
                max-height: none !important;
            }

            #xez_popup .popup-slide h3 {
                font-size: 1.15rem;
            }
        }

        /* Floating Particles Effect */
        .particles {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 0;
            overflow: hidden;
        }

        .particle {
            position: absolute;
            width: 8px;
            height: 8px;
            background: var(--xez-primary);
            border-radius: 50%;
            opacity: 0.15;
            animation: float 15s infinite;
        }

        @keyframes float {

            0%,
            100% {
                transform: translateY(100vh) rotate(0deg);
                opacity: 0;
            }

            10% {
                opacity: 0.15;
            }

            90% {
                opacity: 0.15;
            }

            100% {
                transform: translateY(-100vh) rotate(720deg);
                opacity: 0;
            }
        }
    </style>

    <?php
    // Load active announcements for the homepage popup.
    $popup_rows = dd_q("SELECT * FROM popup_announcements WHERE is_active = 1 ORDER BY show_order ASC, id DESC");
    $popup_items = $popup_rows ? $popup_rows->fetchAll(PDO::FETCH_ASSOC) : [];
    if (!empty($popup_items)):
    ?>
    <div class="modal fade" id="xez_popup" tabindex="-1" aria-labelledby="xez_popup_title" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content overflow-hidden">
                <div class="modal-header border-0">
                    <h5 class="modal-title popup-title" id="xez_popup_title">
                        <i class="fa-solid fa-bullhorn text-xez-primary me-2"></i>ประกาศจากเว็บไซต์
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="ปิด"></button>
                </div>
                <div class="popup-slides">
                    <?php foreach ($popup_items as $popup_index => $popup): ?>
                        <div class="popup-slide <?= $popup_index === 0 ? 'active' : '' ?>" data-slide="<?= $popup_index + 1 ?>">
                            <?php if (!empty($popup['image_url'])): ?>
                                <img src="<?= htmlspecialchars($popup['image_url'], ENT_QUOTES, 'UTF-8') ?>" alt="<?= htmlspecialchars($popup['title'], ENT_QUOTES, 'UTF-8') ?>" class="img-fluid w-100 popup-image">
                            <?php endif; ?>
                            <div class="p-4 p-md-5">
                                <h3 class="popup-title"><?= htmlspecialchars($popup['title'], ENT_QUOTES, 'UTF-8') ?></h3>
                                <p class="popup-text"><?= nl2br(htmlspecialchars($popup['content'] ?? '', ENT_QUOTES, 'UTF-8')) ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php if (count($popup_items) > 1): ?>
                    <div class="popup-indicators">
                        <?php foreach ($popup_items as $popup_index => $popup): ?>
                            <button type="button" class="indicator <?= $popup_index === 0 ? 'active' : '' ?>" data-target="<?= $popup_index + 1 ?>" aria-label="ประกาศที่ <?= $popup_index + 1 ?>"></button>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                <div class="popup-footer">
                    <label class="form-check small mb-0">
                        <input class="form-check-input" type="checkbox" id="dontShowAgain">
                        <span class="form-check-label">ไม่ต้องแสดงอีก 1 ชั่วโมง</span>
                    </label>
                    <button type="button" class="popup-btn" id="popupNextBtn" data-total="<?= count($popup_items) ?>">
                        <span class="btn-text"><?= count($popup_items) > 1 ? 'ถัดไป' : 'ปิด' ?></span>
                        <i class="fa-solid <?= count($popup_items) > 1 ? 'fa-arrow-right' : 'fa-times' ?> ms-2"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script>
        $(document).ready(function () {
            // Only show popup on home page
            const urlParams = new URLSearchParams(window.location.search);
            const currentPage = urlParams.get('page') || 'home';
            let currentSlide = 1;
            const totalSlides = parseInt($('#popupNextBtn').data('total')) || 1;

            if (currentPage === 'home') {
                const popupShown = localStorage.getItem('xez_popup_shown_v2');
                const now = new Date().getTime();
                if (!popupShown || now > parseInt(popupShown)) {
                    setTimeout(() => {
                        if ($('#xez_popup').length) {
                            new bootstrap.Modal('#xez_popup').show();
                        }
                    }, 500);
                }

                // Add floating particles
                createParticles();
            }

            // Popup navigation
            $('#popupNextBtn').click(function () {
                // If only 1 popup or on last slide, close it
                if (totalSlides === 1 || currentSlide >= totalSlides) {
                    // Save preference
                    if ($('#dontShowAgain').is(':checked')) {
                        localStorage.setItem('xez_popup_shown_v2', new Date().getTime() + (3600 * 1000));
                    }
                    bootstrap.Modal.getInstance('#xez_popup').hide();
                } else {
                    // Go to next slide
                    currentSlide++;
                    updateSlide();
                }
            });

            // Indicator clicks
            $('.indicator').click(function () {
                currentSlide = parseInt($(this).data('target'));
                updateSlide();
            });

            function updateSlide() {
                // Update slides
                $('.popup-slide').removeClass('active');
                $(`.popup-slide[data-slide="${currentSlide}"]`).addClass('active');

                // Update indicators
                $('.indicator').removeClass('active');
                $(`.indicator[data-target="${currentSlide}"]`).addClass('active');

                // Update button text
                if (currentSlide === totalSlides) {
                    $('#popupNextBtn .btn-text').text('ปิด');
                    $('#popupNextBtn i').removeClass('fa-arrow-right').addClass('fa-times');
                } else {
                    $('#popupNextBtn .btn-text').text('ถัดไป');
                    $('#popupNextBtn i').removeClass('fa-times').addClass('fa-arrow-right');
                }
            }

            // Create floating particles
            function createParticles() {
                const container = $('<div class="particles"></div>');
                for (let i = 0; i < 15; i++) {
                    const particle = $('<div class="particle"></div>');
                    particle.css({
                        left: Math.random() * 100 + '%',
                        animationDelay: Math.random() * 15 + 's',
                        animationDuration: (15 + Math.random() * 10) + 's',
                        width: (4 + Math.random() * 8) + 'px',
                        height: (4 + Math.random() * 8) + 'px'
                    });
                    container.append(particle);
                }
                $('body').append(container);
            }
        });

        function tobuy(id, name, s, b) {
            $("#modal_title").text(name);
            $("#shop-btn").attr("data-id", id);
            $("#s").text(s);
            $("#b").text(b);
            $("#b_count").val(1);
            new bootstrap.Modal('#buy_count').show();
        }

        function buybox() {
            const formData = new FormData();
            formData.append('id', $("#shop-btn").attr("data-id"));
            formData.append('count', 1);
            Swal.fire({
                title: 'ยืนยันการสั่งซื้อ?',
                text: "คุณต้องการสั่งซื้อสินค้านี้ใช่หรือไม่",
                icon: 'question',
                showCancelButton: true,
                confirmButtonText: 'ซื้อเลย',
                cancelButtonText: 'ยกเลิก'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        type: 'POST',
                        url: 'system/buybox.php',
                        data: formData,
                        contentType: false,
                        processData: false,
                        success: function (res) {
                            if (res.status == "success") {
                                Swal.fire('สำเร็จ', res.message, 'success').then(() => window.location.reload());
                            } else {
                                Swal.fire('ล้มเหลว', res.message, 'error');
                            }
                        }
                    });
                }
            });
        }
        AOS.init();

        // Real-time login monitor: refresh the server-side activity timestamp
        // and detect an expired/replaced session without waiting for a click.
        <?php if (isset($_SESSION['id'])): ?>
        (function () {
            let sessionAlertShown = false;
            let authFailures = 0;
            let lastInteraction = Date.now();
            let lastTouchSent = 0;
            let warningShown = false;
            const IDLE_LIMIT = 10 * 60 * 1000;
            const WARNING_AT = 8 * 60 * 1000;
            async function checkLoginStatus(touch = false) {
                try {
                    const response = await fetch('system/session_status.php?touch=' + (touch ? '1' : '0') + '&_=' + Date.now(), {
                        method: 'GET',
                        credentials: 'same-origin',
                        cache: 'no-store',
                        headers: {'X-Requested-With': 'XMLHttpRequest'}
                    });
                    const result = await response.json();
                    if (!response.ok || !result.logged_in) {
                        authFailures++;
                        // Shared hosting can briefly return an incomplete
                        // response. Require several consecutive failures.
                        if (authFailures < 3) return;
                        if (sessionAlertShown) return;
                        sessionAlertShown = true;
                        Swal.fire({
                            icon: 'warning',
                            title: 'เซสชันสิ้นสุดแล้ว',
                            text: result.message || 'กรุณาเข้าสู่ระบบใหม่',
                            confirmButtonText: 'เข้าสู่ระบบใหม่',
                            allowOutsideClick: false
                        }).then(() => { window.location.href = '?page=login'; });
                    } else {
                        authFailures = 0;
                        if (touch) lastTouchSent = Date.now();
                    }
                } catch (error) {
                    // Do not log the user out on a temporary network failure.
                    console.debug('Login heartbeat temporarily unavailable');
                }
            }
            function recordActivity() {
                lastInteraction = Date.now();
                if (warningShown) {
                    warningShown = false;
                    if (typeof Swal !== 'undefined') Swal.close();
                }
                if (Date.now() - lastTouchSent > 15000) checkLoginStatus(true);
            }
            ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll'].forEach((eventName) => {
                window.addEventListener(eventName, recordActivity, {passive: true});
            });
            function showTimeoutWarning() {
                if (warningShown || sessionAlertShown) return;
                warningShown = true;
                const remaining = Math.max(0, Math.ceil((IDLE_LIMIT - (Date.now() - lastInteraction)) / 1000));
                Swal.fire({
                    icon: 'warning',
                    title: 'ใกล้หมดเวลาเซสชัน',
                    text: 'ไม่มีการใช้งาน ระบบจะออกจากระบบในประมาณ ' + Math.ceil(remaining / 60) + ' นาที',
                    confirmButtonText: 'ใช้งานต่อ',
                    showCancelButton: true,
                    cancelButtonText: 'ออกจากระบบ',
                    allowOutsideClick: false
                }).then((result) => {
                    if (result.isConfirmed) recordActivity();
                    else if (result.dismiss === Swal.DismissReason.cancel) window.location.href = '?page=logout';
                });
            }
            checkLoginStatus(false);
            setInterval(() => {
                const idle = Date.now() - lastInteraction;
                if (idle >= WARNING_AT && idle < IDLE_LIMIT) showTimeoutWarning();
                checkLoginStatus(false);
            }, 30000);
        })();
        <?php endif; ?>
    </script>

    <!-- Floating contact admin button -->
    <?php if (($config['chat_status'] ?? 'on') === 'on' && $page !== 'backend' && $page !== 'contact_messages' && $page !== 'admin_chat'): ?>
    <button type="button" id="contactAdminFab" aria-label="แชทกับแอดมิน"><i class="fa-solid fa-headset"></i><span>แชทกับแอดมิน</span><b id="contactAdminBadge" class="contact-admin-badge d-none">0</b></button>
    <div class="modal fade" id="contactAdminModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered"><div class="modal-content">
            <div class="modal-header chat-modal-header"><div class="chat-admin-title"><span class="chat-admin-avatar"><i class="fa-solid fa-user-tie"></i></span><span><strong>แชทกับแอดมิน</strong><small id="adminChatStatus">พร้อมให้บริการ</small></span></div><button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
            <?php if (!isset($_SESSION['id'])): ?>
            <div class="modal-body text-center py-4"><i class="fa-solid fa-lock fs-1 text-warning mb-3"></i><p class="mb-3">กรุณาเข้าสู่ระบบก่อนจึงจะส่งข้อความถึงแอดมินได้</p><a class="btn btn-primary" href="?page=login">เข้าสู่ระบบ</a></div>
            <?php else: ?>
            <div class="modal-body chat-modal-body"><div class="chat-reply-banner"><i class="fa-solid fa-bolt"></i><span>เมื่อแอดมินตอบกลับ จะแจ้งเตือนที่ไอคอนและปุ่มแชท</span></div><div id="adminChatMessages" class="chat-messages-box"><div class="text-center text-muted small">กำลังโหลดแชท...</div></div></div>
            <form id="adminChatForm" class="chat-composer"><div class="modal-footer"><input class="form-control" name="message" maxlength="3000" placeholder="พิมพ์ข้อความถึงแอดมิน..." required><button class="btn btn-primary" type="submit"><i class="fa-solid fa-paper-plane"></i><span>ส่ง</span></button></div></form>
            <?php endif; ?>
        </div></div>
    </div>
    <style>#contactAdminFab{position:fixed;left:14px;bottom:18px;z-index:2147483000;border:0;border-radius:999px;padding:10px 15px;background:linear-gradient(135deg,#ffb300,#ff6b35);color:#fff;font-weight:700;box-shadow:0 8px 22px rgba(0,0,0,.28);display:flex;align-items:center;gap:8px;cursor:pointer}#contactAdminFab:hover{transform:translateY(-2px)}#contactAdminModal{z-index:2147483001}#contactAdminModal.modal.show{display:block;background:rgba(0,0,0,.45)}@media(max-width:480px){#contactAdminFab{padding:11px;width:48px;height:48px;justify-content:center}#contactAdminFab span{display:none}}</style>
    <script>(function(){function ready(fn){if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',fn);else fn();}ready(function(){var fab=document.getElementById('contactAdminFab'),modalEl=document.getElementById('contactAdminModal'),form=document.getElementById('adminChatForm'),box=document.getElementById('adminChatMessages'),api='index.php?page=admin_chat_api';if(!fab||!modalEl)return;function loadChat(){if(!box)return;fetch(api,{credentials:'same-origin'}).then(function(r){return r.json();}).then(function(r){if(r.login_required){location.href='?page=login';return;}box.innerHTML='';(r.messages||[]).forEach(function(m){var row=document.createElement('div');row.className='d-flex mb-2 '+(m.sender==='user'?'justify-content-end':'justify-content-start');var bubble=document.createElement('div');bubble.className='p-2 rounded-3 '+(m.sender==='user'?'bg-primary text-white':'bg-white border');bubble.style.cssText='max-width:80%;white-space:pre-wrap';bubble.textContent=m.message;var time=document.createElement('small');time.className='d-block opacity-75';time.textContent=m.created_at;bubble.appendChild(time);row.appendChild(bubble);box.appendChild(row);});box.scrollTop=box.scrollHeight;}).catch(function(){box.innerHTML='<div class="text-center text-danger small">โหลดแชทไม่สำเร็จ</div>';});}function openChat(){modalEl.classList.add('show');modalEl.setAttribute('aria-hidden','false');document.body.classList.add('modal-open');loadChat();}function closeChat(){modalEl.classList.remove('show');modalEl.setAttribute('aria-hidden','true');document.body.classList.remove('modal-open');}fab.addEventListener('click',openChat);modalEl.querySelectorAll('[data-bs-dismiss="modal"],.btn-close').forEach(function(b){b.addEventListener('click',closeChat);});if(form)form.addEventListener('submit',function(e){e.preventDefault();var btn=form.querySelector('button[type=submit]');btn.disabled=true;fetch(api,{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(form))}).then(function(r){return r.json();}).then(function(r){if(r.login_required){location.href='?page=login';return;}if(!r.ok){alert(r.message);return;}form.reset();loadChat();}).catch(function(){alert('ไม่สามารถส่งข้อความได้');}).finally(function(){btn.disabled=false;});});});})();</script>
    <?php endif; ?>

    <!-- Footer Section -->
    <?php if ($page != "" && $page != "landing"): ?>
        <footer class="site-footer" id="contact-section">
            <div class="container">
                <div class="row g-4">
                    <!-- Logo & Description -->
                    <div class="col-lg-4 col-md-6">
                        <div class="footer-brand">
                            <img src="<?= htmlspecialchars($site_logo, ENT_QUOTES, 'UTF-8') ?>" alt="Logo" class="footer-logo">
                            <h4 class="footer-title">
                                <?= $config['name'] ?>
                            </h4>
                            <p class="footer-desc">
                                <?= $config['des'] ?>
                            </p>
                        </div>
                    </div>

                    <!-- Menu Links -->
                    <div class="col-lg-2 col-md-6">
                        <h5 class="footer-heading">เมนูหลัก</h5>
                        <ul class="footer-links">
                            <li><a href="?page=home"><i class="fa-solid fa-home me-2"></i>หน้าหลัก</a></li>
                            <li><a href="?page=shop"><i class="fa-solid fa-shopping-bag me-2"></i>สินค้า</a></li>
                            <li><a href="?page=topup"><i class="fa-solid fa-wallet me-2"></i>เติมเงิน</a></li>
                            <li><a href="?page=login"><i class="fa-solid fa-sign-in me-2"></i>เข้าสู่ระบบ</a></li>
                        </ul>
                    </div>

                    <!-- History Links -->
                    <div class="col-lg-2 col-md-6">
                        <h5 class="footer-heading">ประวัติต่างๆ</h5>
                        <ul class="footer-links">
                            <li><a href="?page=profile&subpage=buyhis"><i class="fa-solid fa-history me-2"></i>ประวัติซื้อสินค้า</a></li>
                            <li><a href="?page=profile&subpage=topuphis"><i class="fa-solid fa-receipt me-2"></i>ประวัติเติมเงิน</a></li>
                        </ul>
                    </div>

                    <!-- Social Widgets -->
                    <div class="col-lg-4 col-md-6">
                        <h5 class="footer-heading">ติดตามเรา</h5>
                        <div class="social-widgets d-flex gap-2 mb-3">
                            <?php if(($config['contact_facebook'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_facebook'] ?>" class="btn btn-primary btn-sm rounded-circle" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-facebook"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_line'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_line'] ?>" class="btn btn-success btn-sm rounded-circle" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-line"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_discord'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_discord'] ?>" class="btn btn-info btn-sm rounded-circle text-white" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-discord"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_messenger'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_messenger'] ?>" class="btn btn-primary btn-sm rounded-circle" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-facebook-messenger"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram1'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_telegram1'] ?>" class="btn btn-info btn-sm rounded-circle text-white" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-telegram"></i></a>
                            <?php endif; ?>
                            <?php if(($config['contact_telegram2'] ?? '#') != '#'): ?>
                            <a href="<?= $config['contact_telegram2'] ?>" class="btn btn-info btn-sm rounded-circle text-white" target="_blank" style="width: 35px; height: 35px; display: flex; align-items: center; justify-content: center;"><i class="fa-brands fa-telegram"></i></a>
                            <?php endif; ?>
                        </div>
                        <?php if(($config['discord_widget_status'] ?? 'off') === 'on' && ($config['discord_server'] ?? '') != ''): ?>
                        <div class="widget-content">
                            <iframe src="https://discord.com/widget?id=<?= $config['discord_server'] ?>&theme=dark"
                                width="100%" height="400" allowtransparency="true" frameborder="0"
                                sandbox="allow-popups allow-popups-to-escape-sandbox allow-same-origin allow-scripts"></iframe>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            </div>

            <!-- Copyright -->
            <div class="footer-bottom">
                <p>&copy;
                    <?= date('Y') ?>
                    <?= $config['name'] ?>. All rights reserved.
                </p>
                <p class="small opacity-75">Powered by OMG SHOP</p>
            </div>
            </div>
        </footer>
    <?php endif; ?>

    <style>
        /* Footer Styles */
        .site-footer {
            background: linear-gradient(135deg, var(--xez-primary) 0%, var(--xez-secondary) 100%);
            padding: 60px 0 30px;
            margin-top: 60px;
            color: #fff;
        }

        .footer-brand .footer-logo {
            width: 80px;
            height: 80px;
            object-fit: contain;
            margin-bottom: 15px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
        }

        .footer-title {
            font-weight: 700;
            color: #fff;
            margin-bottom: 10px;
        }

        .footer-desc {
            color: #94a3b8;
            font-size: 0.9rem;
            line-height: 1.6;
        }

        .footer-heading {
            color: var(--xez-primary);
            font-weight: 600;
            margin-bottom: 20px;
            font-size: 1rem;
        }

        .footer-links {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: #94a3b8;
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.3s ease;
        }

        .footer-links a:hover {
            color: var(--xez-primary);
            padding-left: 5px;
        }

        .widget-box {
            background: rgba(255, 255, 255, 0.05);
            border-radius: 15px;
            overflow: hidden;
            margin-bottom: 15px;
        }

        .widget-header {
            background: linear-gradient(135deg, #5865F2, #7289da);
            padding: 10px 15px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .widget-header i {
            font-size: 1.2rem;
        }

        .widget-content iframe {
            display: block;
        }

        .footer-bottom {
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            margin-top: 40px;
            padding-top: 30px;
            text-align: center;
            color: #64748b;
        }

        .footer-bottom p {
            margin: 5px 0;
        }
    </style>
    <script>
        AOS.init({
            duration: 800,
            once: true
        });

        // Optimized Preloader Logic
        (function () {
            const preloader = document.getElementById('preloader');
            const progress = document.querySelector('.loader-progress');

            // Initial progress animation
            if (progress) {
                setTimeout(() => progress.style.width = '30%', 100);
                setTimeout(() => progress.style.width = '70%', 500);
            }

            function hidePreloader() {
                if (!preloader || preloader.style.display === 'none') return;

                if (progress) progress.style.width = '100%';

                setTimeout(() => {
                    preloader.classList.add('fade-out');
                    setTimeout(() => {
                        preloader.style.display = 'none';
                    }, 400);
                }, 200);
            }

            // Hide when loaded or after a safe timeout
            window.addEventListener('load', hidePreloader);
            setTimeout(hidePreloader, 1000); // 2.5s absolute maximum wait
        })();
    </script>

<?php if (($config['chat_status'] ?? 'on') === 'on' && ($user['rank'] ?? '') == '1'): ?>
<script>(function(){var bell=document.getElementById('adminChatBell'),badge=document.getElementById('adminChatBellBadge'),last=0;if(!bell||!badge)return;function check(){fetch('index.php?page=admin_chat_unread',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(x){if(!x.ok)return;var n=parseInt(x.unread||0,10);badge.textContent=n>99?'99+':n;badge.classList.toggle('d-none',n<1);if(n>last&&last>0){bell.classList.add('text-danger');setTimeout(function(){bell.classList.remove('text-danger')},1800);}last=n;}).catch(function(){});}check();setInterval(check,10000);})();</script>
<script>(function(){var bell=document.getElementById('cardRequestBell'),badge=document.getElementById('cardRequestBellBadge'),last=0;if(!bell||!badge)return;function check(){fetch('index.php?page=truemoney_card_unread',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(x){if(!x.ok)return;var n=parseInt(x.pending||0,10);badge.textContent=n>99?'99+':n;badge.classList.toggle('d-none',n<1);if(n>last&&last>0){bell.classList.add('text-danger');setTimeout(function(){bell.classList.remove('text-danger')},2200);}last=n;}).catch(function(){});}check();setInterval(check,10000);})();</script>
<?php else: ?>
<script>(function(){var bell=document.getElementById('userChatBell'),badge=document.getElementById('userChatBellBadge'),notify=document.getElementById('userChatNotifyFab'),notifyBadge=document.getElementById('userChatNotifyBadge'),fabBadge=document.getElementById('contactAdminBadge'),last=0;if(!bell||!badge)return;function openChat(e){if(e)e.preventDefault();var fab=document.getElementById('contactAdminFab');if(fab)fab.click();else location.href='?page=home';}bell.addEventListener('click',openChat);if(notify)notify.addEventListener('click',openChat);function check(){fetch('index.php?page=user_chat_unread',{credentials:'same-origin'}).then(function(r){return r.json()}).then(function(x){if(!x.ok)return;var n=parseInt(x.unread||0,10),label=n>99?'99+':n;badge.textContent=label;badge.classList.toggle('d-none',n<1);bell.classList.toggle('chat-reply-unread',n>0);bell.setAttribute('aria-label',n>0?'แอดมินตอบแชทแล้ว '+label+' ข้อความ':'ข้อความจากแอดมิน');if(notifyBadge){notifyBadge.textContent=label;notifyBadge.classList.toggle('d-none',n<1);}if(fabBadge){fabBadge.textContent=label;fabBadge.classList.toggle('d-none',n<1);}if(n>last&&last>0){bell.classList.add('text-danger');if(notify)notify.classList.add('is-new');setTimeout(function(){bell.classList.remove('text-danger');if(notify)notify.classList.remove('is-new')},2200);}last=n;}).catch(function(){});}check();setInterval(check,10000);})();</script>
<?php endif; ?>
<script>
(function(){var timeout=300000,timer;function reset(){clearTimeout(timer);timer=setTimeout(function(){window.location.href='?page=login&timeout=1';},timeout);}['click','mousemove','keydown','scroll','touchstart','input'].forEach(function(e){document.addEventListener(e,reset,{passive:true});});reset();})();
</script>
</body>

</html>
<style>
/* OMGVIP black-red theme */
:root{--omg-red:#e50914;--omg-red-dark:#8b0000;--omg-red-soft:#ff3340;--omg-black:#070707;--omg-panel:#141414;--omg-panel-2:#1d1011;--omg-border:#4a171b;--omg-text:#f7f7f7;--omg-muted:#a7a7a7}
html,body{background:radial-gradient(circle at 50% -12%,#3b0b10 0,#0a0809 42%,#030303 100%)!important;color:var(--omg-text)!important}
body{background-color:var(--omg-black)!important}
.navbar,.main-navbar,header{background:linear-gradient(90deg,#090909,#260b0e 50%,#090909)!important;border-bottom:1px solid var(--omg-red)!important}
.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,#211112,#0f0f0f)!important;border:1px solid var(--omg-border)!important;border-radius:16px!important;box-shadow:0 16px 36px rgba(0,0,0,.38)!important}
.card:hover,.product-card:hover,.category-card:hover{border-color:#8f2028!important;box-shadow:0 0 24px rgba(229,9,20,.16)!important}
.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:linear-gradient(135deg,#e50914,#8b0000)!important;border-color:#ff3340!important;color:#fff!important;border-radius:10px!important}
.btn:hover,.btn-primary:hover,.btn-success:hover{background:linear-gradient(135deg,#ff3340,#b30000)!important;filter:brightness(1.08)}
.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#171010!important;border-color:#a51d27!important;color:#ff6970!important}
.btn-warning{background:linear-gradient(135deg,#e50914,#8b0000)!important;color:#fff!important;border-color:#ff3340!important}
.btn-danger{background:#b30000!important;border-color:#ff3340!important}
.form-control,.form-select,textarea,input{background:#121212!important;color:#fff!important;border:1px solid #552024!important;border-radius:9px!important}
.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:#e50914!important;box-shadow:0 0 0 .2rem rgba(229,9,20,.2)!important}
a{color:#ff6970!important}a:hover{color:#ffb0b4!important}h1,h2,h3,h4,h5,h6{color:#fff!important;text-shadow:0 0 16px rgba(229,9,20,.22)}
.badge,.hot,.tag{background:#e50914!important;color:#fff!important;border-color:#ff3340!important}
.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:linear-gradient(135deg,#241012,#120c0d)!important;color:#fff!important;border:1px solid #7d2028!important;border-radius:14px!important}
.table{color:#eee!important}.table thead{background:#211012!important}.table tbody tr{border-color:#3e191c!important}.table tbody tr:hover{background:rgba(229,9,20,.08)!important}
footer{background:#050505!important;border-top:1px solid #4a171b!important}
.omg-order-toggle{background:#160c0d!important;border-color:#7d2028!important}.omg-order-toggle i{background:#e50914!important;box-shadow:0 0 10px #e50914!important}
@media(max-width:600px){.card,.product-card,.category-card{border-radius:13px!important}}

</style>
<style>
/* OMGVIP modern premium layer */
:root{--modern-red:#ef233c;--modern-red-2:#b7091b;--modern-bg:#070708;--modern-surface:rgba(22,18,20,.82);--modern-surface-2:#171214;--modern-border:rgba(255,82,99,.24);--modern-text:#f8fafc;--modern-muted:#a9a3a6}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif!important;letter-spacing:.005em!important;background:radial-gradient(900px 480px at 50% -80px,rgba(239,35,60,.22),transparent 62%),linear-gradient(180deg,#0b0809 0,#050505 55%,#020202 100%)!important;color:var(--modern-text)!important}body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.18;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:34px 34px;mask-image:linear-gradient(to bottom,#000,transparent 80%);z-index:-1}.navbar,.main-navbar,header{background:rgba(7,7,8,.78)!important;backdrop-filter:blur(18px) saturate(140%);-webkit-backdrop-filter:blur(18px) saturate(140%);border-bottom:1px solid rgba(239,35,60,.32)!important;box-shadow:0 8px 30px rgba(0,0,0,.22)!important}.navbar-brand,.navbar a{font-weight:600}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,rgba(35,22,25,.92),rgba(12,11,12,.94))!important;border:1px solid var(--modern-border)!important;border-radius:20px!important;box-shadow:0 18px 50px rgba(0,0,0,.32),inset 0 1px rgba(255,255,255,.035)!important;transition:transform .2s ease,box-shadow .2s ease,border-color .2s ease!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{transform:translateY(-3px);border-color:rgba(239,35,60,.6)!important;box-shadow:0 22px 56px rgba(0,0,0,.42),0 0 28px rgba(239,35,60,.1)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{font-weight:700!important;letter-spacing:.01em;background:linear-gradient(135deg,var(--modern-red),var(--modern-red-2))!important;border:1px solid rgba(255,116,126,.6)!important;border-radius:12px!important;box-shadow:0 8px 18px rgba(183,9,27,.22)!important;transition:transform .18s ease,filter .18s ease,box-shadow .18s ease!important}.btn:hover,.btn-primary:hover,.btn-success:hover{filter:brightness(1.12);transform:translateY(-2px);box-shadow:0 12px 24px rgba(183,9,27,.35)!important}.form-control,.form-select,textarea,input{background:rgba(14,13,14,.9)!important;color:#fff!important;border:1px solid rgba(255,255,255,.12)!important;border-radius:12px!important;padding-top:.7rem!important;padding-bottom:.7rem!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--modern-red)!important;box-shadow:0 0 0 4px rgba(239,35,60,.12)!important}.badge,.hot,.tag{border-radius:999px!important;padding:.45em .75em!important;background:linear-gradient(135deg,var(--modern-red),var(--modern-red-2))!important;color:#fff!important}.table{--bs-table-bg:transparent!important;color:#f4f4f5!important}.table thead{background:rgba(239,35,60,.1)!important}.table tbody tr{border-color:rgba(255,255,255,.08)!important}.table tbody tr:hover{background:rgba(239,35,60,.08)!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{border-radius:16px!important;background:linear-gradient(135deg,rgba(42,16,20,.96),rgba(15,11,12,.96))!important;border:1px solid rgba(239,35,60,.42)!important;box-shadow:0 16px 40px rgba(0,0,0,.35)!important}footer{background:#030303!important;border-top:1px solid rgba(239,35,60,.25)!important;color:var(--modern-muted)!important}.omg-order-toggle{backdrop-filter:blur(14px);background:rgba(25,10,12,.86)!important;border-color:rgba(239,35,60,.5)!important;border-radius:999px!important;box-shadow:0 12px 30px rgba(0,0,0,.35)!important}@media(max-width:768px){.container,.container-fluid{padding-left:16px!important;padding-right:16px!important}.card,.product-card,.category-card,.feature-card,.shop-card{border-radius:16px!important}.btn{min-height:44px}.navbar{padding-top:.65rem!important;padding-bottom:.65rem!important}}
</style>
<style>
/* OMGVIP performance layer */
html{scroll-behavior:auto!important}body:before{display:none!important}.navbar,.main-navbar,header{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{transition:none!important;box-shadow:0 10px 24px rgba(0,0,0,.24)!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{transform:none!important;box-shadow:0 12px 28px rgba(0,0,0,.3)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{transition:filter .12s ease!important;box-shadow:0 5px 12px rgba(183,9,27,.18)!important}.btn:hover,.btn-primary:hover,.btn-success:hover{transform:none!important}.omg-order-toggle{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}img{content-visibility:auto;image-rendering:auto}iframe{loading:lazy} @media(max-width:768px){body{background:#050505!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{box-shadow:0 6px 16px rgba(0,0,0,.24)!important}.navbar,.main-navbar,header{background:#090708!important}} @media(prefers-reduced-motion:reduce){*,*::before,*::after{animation-duration:.001ms!important;animation-iteration-count:1!important;transition-duration:.001ms!important;scroll-behavior:auto!important}}
</style>
<style>
/* OMGVIP ruby wine palette */
:root{--ruby:#d81b45;--ruby-deep:#831b36;--wine:#260d18;--wine-2:#3a1423;--rose:#f08b9e;--gold:#e6b873;--ink:#080609;--surface:#171016;--line:rgba(240,139,158,.24)}
body{background:radial-gradient(900px 420px at 50% -100px,rgba(216,27,69,.22),transparent 65%),linear-gradient(180deg,#120a0f 0,#070608 55%,#030304 100%)!important;color:#fbf4f6!important}.navbar,.main-navbar,header{background:rgba(13,7,11,.94)!important;border-bottom-color:rgba(216,27,69,.55)!important}.navbar-brand,.navbar a{color:#fff!important}.navbar a:hover{color:var(--rose)!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,rgba(58,20,35,.9),rgba(16,10,15,.96))!important;border-color:var(--line)!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{border-color:rgba(240,139,158,.6)!important;box-shadow:0 12px 28px rgba(216,27,69,.18)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:linear-gradient(135deg,var(--ruby),var(--ruby-deep))!important;border-color:#f08b9e!important;color:#fff!important}.btn:hover,.btn-primary:hover,.btn-success:hover{background:linear-gradient(135deg,#ed4066,#a62248)!important}.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#21121a!important;border-color:#9e3654!important;color:#f08b9e!important}.btn-warning{background:linear-gradient(135deg,#c91843,#7e1733)!important;color:#fff!important;border-color:#f08b9e!important}.form-control,.form-select,textarea,input{background:#110b10!important;color:#fff!important;border-color:#5f263c!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--rose)!important;box-shadow:0 0 0 4px rgba(216,27,69,.14)!important}.badge,.hot,.tag{background:linear-gradient(135deg,var(--ruby),var(--ruby-deep))!important;color:#fff!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:linear-gradient(135deg,#351421,#160b12)!important;border-color:#963650!important;color:#fff!important}.table thead{background:rgba(216,27,69,.13)!important}.table tbody tr:hover{background:rgba(216,27,69,.08)!important}h1,h2,h3,h4,h5,h6{color:#fff!important}footer{background:#050406!important;border-top-color:rgba(216,27,69,.38)!important}.omg-order-toggle{background:rgba(38,13,24,.94)!important;border-color:#9e3654!important}.omg-order-toggle i{background:var(--ruby)!important;box-shadow:0 0 10px rgba(216,27,69,.65)!important}.admin-chat-page .col-lg-8 h5+div .bg-primary{background:linear-gradient(135deg,#d81b45,#831b36)!important;border-color:#f08b9e!important}.admin-chat-page .col-lg-8 form .btn{background:linear-gradient(135deg,#d81b45,#831b36)!important}
</style>

<style id="admin-theme-overrides">
:root{--admin-main:<?= htmlspecialchars($brand_main_color, ENT_QUOTES, 'UTF-8') ?>;--admin-secondary:<?= htmlspecialchars($brand_secondary_color, ENT_QUOTES, 'UTF-8') ?>;--admin-border:<?= htmlspecialchars($brand_border_color, ENT_QUOTES, 'UTF-8') ?>;--admin-text:<?= htmlspecialchars($theme_colors['text_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-bg:<?= htmlspecialchars($theme_colors['bg_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-card:<?= htmlspecialchars($theme_colors['card_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-button:<?= htmlspecialchars($theme_colors['button_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-success:<?= htmlspecialchars($theme_colors['success_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-warning:<?= htmlspecialchars($theme_colors['warning_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-danger:<?= htmlspecialchars($theme_colors['danger_color'], ENT_QUOTES, 'UTF-8') ?>;--admin-info:<?= htmlspecialchars($theme_colors['info_color'], ENT_QUOTES, 'UTF-8') ?>}
body{background:var(--admin-bg)!important;color:var(--admin-text)!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:var(--admin-card)!important;border-color:var(--admin-border)!important}.btn,.btn-primary,.button-primary,.bg-main{background:var(--admin-button)!important;border-color:var(--admin-border)!important}.btn-success{background:var(--admin-success)!important}.btn-warning{background:var(--admin-warning)!important}.btn-danger{background:var(--admin-danger)!important}.alert-info{border-color:var(--admin-info)!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--admin-main)!important;box-shadow:0 0 0 .2rem color-mix(in srgb,var(--admin-main) 20%,transparent)!important}a{color:var(--admin-main)!important}.badge{background:var(--admin-main)!important}
/* OMGVIP admin dynamic theme */
</style>

<?php $glow_speed = max(1, min(10, (int)($config['glow_speed'] ?? 5))); $glow_duration = number_format(3.8 - (($glow_speed - 1) * 0.28), 2, '.', ''); ?>
<style id="glow-settings-runtime">.product-card::before,.category-card::before,.shop-card::before,.card.product-card::before,.card.category-card::before,.card.shop-card::before,.product-card::after,.category-card::after,.shop-card::after,.card.product-card::after,.card.category-card::after,.card.shop-card::after{animation-duration:<?= $glow_duration ?>s!important}<?php if (($config['glow_enabled'] ?? 'on') !== 'on'): ?>.product-card::before,.category-card::before,.shop-card::before,.card.product-card::before,.card.category-card::before,.card.shop-card::before,.product-card::after,.category-card::after,.shop-card::after,.card.product-card::after,.card.category-card::after,.card.shop-card::after{display:none!important}<?php endif; ?></style>
<?php $rain_density = max(20, min(130, (int)($config['rain_density'] ?? 70))); ?>
<?php if (($config['rain_enabled'] ?? 'on') === 'on'): ?>
<!-- เอฟเฟกต์ฝนตก -->
<canvas id="rainCanvas" aria-hidden="true"></canvas>
<style>
#rainCanvas{position:fixed;inset:0;width:100%;height:100%;pointer-events:none;z-index:9999;opacity:.58}
@media(prefers-reduced-motion:reduce){#rainCanvas{display:none}}
</style>
<script>
(function(){
  const canvas=document.getElementById('rainCanvas');
  if(!canvas)return;
  const ctx=canvas.getContext('2d');
  let drops=[],width=0,height=0,dpr=1;
  function resizeCanvas(){
    dpr=Math.min(window.devicePixelRatio||1,2);
    width=window.innerWidth;height=window.innerHeight;
    canvas.width=Math.floor(width*dpr);canvas.height=Math.floor(height*dpr);
    canvas.style.width=width+'px';canvas.style.height=height+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
    createRain();
  }
  function createRain(){
    drops=[];
    const amount=<?= $rain_density ?>;
    for(let i=0;i<amount;i++)drops.push({
      x:Math.random()*width,y:Math.random()*height,
      length:Math.random()*28+10,speed:Math.random()*3.5+2.5,
      opacity:Math.random()*.38+.16,width:Math.random()*1.2+.45
    });
  }
  function drawRain(){
    ctx.clearRect(0,0,width,height);
    ctx.shadowBlur=0;
    for(const drop of drops){
      ctx.beginPath();ctx.moveTo(drop.x,drop.y);ctx.lineTo(drop.x-1,drop.y+drop.length);
      ctx.strokeStyle='rgba(255,255,255,'+drop.opacity+')';ctx.lineWidth=drop.width;ctx.stroke();
      drop.y+=drop.speed;
      if(drop.y>height+drop.length){drop.y=-drop.length;drop.x=Math.random()*width;}
    }
    requestAnimationFrame(drawRain);
  }
  let resizeTimer;window.addEventListener('resize',function(){clearTimeout(resizeTimer);resizeTimer=setTimeout(resizeCanvas,120)});
  resizeCanvas();drawRain();
})();
</script>
<?php endif; ?>

<style>
/* OMGVIP modern ocean blue theme */
:root{--ocean:#168cff;--ocean-deep:#075bd8;--cyan:#27d7ff;--navy:#071322;--navy-2:#0d1d32;--blue-line:rgba(39,215,255,.28);--blue-text:#e8f7ff}
body{background:radial-gradient(900px 440px at 50% -100px,rgba(22,140,255,.25),transparent 65%),linear-gradient(180deg,#071322 0,#04080f 58%,#020407 100%)!important;color:var(--blue-text)!important}.navbar,.main-navbar,header{background:rgba(4,12,24,.94)!important;border-bottom-color:rgba(39,215,255,.48)!important}.navbar-brand,.navbar a{color:#f3fbff!important}.navbar a:hover{color:var(--cyan)!important}.card,.card-body,.glass-card,.product-card,.category-card,.feature-card,.shop-card,.modal-content{background:linear-gradient(145deg,rgba(13,39,68,.92),rgba(5,14,27,.97))!important;border-color:var(--blue-line)!important}.card:hover,.product-card:hover,.category-card:hover,.shop-card:hover{border-color:rgba(39,215,255,.65)!important;box-shadow:0 14px 32px rgba(22,140,255,.2)!important}.btn,.btn-primary,.btn-success,.button-primary,.bg-main{background:linear-gradient(135deg,var(--ocean),var(--ocean-deep))!important;border-color:#67e5ff!important;color:#fff!important}.btn:hover,.btn-primary:hover,.btn-success:hover{background:linear-gradient(135deg,#39b6ff,#1266ed)!important}.btn-secondary,.btn-outline-primary,.btn-outline-danger{background:#0d2138!important;border-color:#277eff!important;color:#8eeaff!important}.btn-warning{background:linear-gradient(135deg,#168cff,#075bd8)!important;color:#fff!important;border-color:#67e5ff!important}.form-control,.form-select,textarea,input{background:#071523!important;color:#fff!important;border-color:#1e5685!important}.form-control:focus,.form-select:focus,textarea:focus,input:focus{border-color:var(--cyan)!important;box-shadow:0 0 0 4px rgba(39,215,255,.14)!important}.badge,.hot,.tag{background:linear-gradient(135deg,var(--ocean),var(--ocean-deep))!important;color:#fff!important}.alert,.toast,.latest-order-notification,.order-notification,.purchase-notification,.recent-order-toast{background:linear-gradient(135deg,#102d4a,#071523)!important;border-color:#277eff!important;color:#fff!important}.table thead{background:rgba(22,140,255,.16)!important}.table tbody tr:hover{background:rgba(22,140,255,.1)!important}h1,h2,h3,h4,h5,h6{color:#f3fbff!important}footer{background:#02060b!important;border-top-color:rgba(39,215,255,.4)!important}.omg-order-toggle{background:rgba(7,29,50,.95)!important;border-color:#277eff!important}.omg-order-toggle i{background:var(--ocean)!important;box-shadow:0 0 12px rgba(39,215,255,.7)!important}.admin-chat-page .col-lg-8 h5+div .bg-primary{background:linear-gradient(135deg,#168cff,#075bd8)!important;border-color:#67e5ff!important}.admin-chat-page .col-lg-8 form .btn{background:linear-gradient(135deg,#168cff,#075bd8)!important}
/* blue hover glow */
.product-card:hover::before,.category-card:hover::before,.shop-card:hover::before,.card.product-card:hover::before,.card.category-card:hover::before,.card.shop-card:hover::before{background:conic-gradient(from 0deg,transparent 0deg,transparent 35deg,#27d7ff 70deg,#168cff 100deg,transparent 140deg,transparent 360deg)!important;filter:drop-shadow(0 0 4px #27d7ff) drop-shadow(0 0 12px #168cff)!important}.product-card:hover::after,.category-card:hover::after,.shop-card:hover::after,.card.product-card:hover::after,.card.category-card:hover::after,.card.shop-card:hover::after{background:conic-gradient(from 0deg,transparent,rgba(39,215,255,.6),transparent 25%)!important}

</style>

<style id="force-order-red-final">
.xez-order-btn,.product-buy-btn{background:linear-gradient(135deg,#ef4444,#b91c1c)!important;border:1px solid #f87171!important;color:#fff!important;box-shadow:0 0 16px rgba(239,68,68,.3)!important}.xez-order-btn:hover,.product-buy-btn:hover{background:linear-gradient(135deg,#f87171,#dc2626)!important;border-color:#fecaca!important;color:#fff!important;box-shadow:0 0 20px rgba(239,68,68,.45)!important}
</style>

<style>
.user-chat-notify-fab{position:fixed;right:20px;bottom:92px;width:58px;height:58px;display:flex;align-items:center;justify-content:center;border-radius:18px;background:linear-gradient(145deg,#ffb300 0%,#e50914 70%,#8b0000 100%);color:#fff!important;box-shadow:0 10px 28px rgba(229,9,20,.45),inset 0 1px 0 rgba(255,255,255,.3);z-index:1060;text-decoration:none;transition:transform .2s,filter .2s,box-shadow .2s}
.user-chat-notify-fab:hover,.user-chat-notify-fab.is-new{transform:translateY(-3px) scale(1.06);filter:brightness(1.15);box-shadow:0 14px 34px rgba(229,9,20,.6),inset 0 1px 0 rgba(255,255,255,.35)}
.user-chat-notify-fab.is-new:before{content:'';position:absolute;inset:-5px;border:2px solid rgba(255,179,0,.65);border-radius:22px;animation:chatNotifyPulse 1.6s ease-out infinite}
.user-chat-notify-fab i{font-size:22px;filter:drop-shadow(0 2px 2px rgba(0,0,0,.3))}
@keyframes chatNotifyPulse{0%{transform:scale(.92);opacity:.9}100%{transform:scale(1.2);opacity:0}}
.user-chat-notify-label{position:absolute;right:68px;white-space:nowrap;bottom:12px;padding:7px 10px;border-radius:10px;background:rgba(23,16,16,.96);color:#ffe3a3;font:700 12px/16px Arial,sans-serif;box-shadow:0 5px 16px rgba(0,0,0,.34);border:1px solid rgba(255,179,0,.28)}.user-chat-notify-badge{position:absolute;right:-4px;top:-5px;min-width:21px;height:21px;padding:2px 5px;border-radius:999px;background:#ff1744;color:#fff;font:700 12px/17px Arial,sans-serif;text-align:center;border:2px solid #080808}
@media(max-width:600px){.user-chat-notify-fab{right:14px;bottom:82px;width:48px;height:48px}}
</style>

<style id="admin-chat-background-theme">
#contactAdminModal .modal-dialog{max-width:560px}
#contactAdminModal .modal-content{background:linear-gradient(145deg,#241015 0%,#10090d 48%,#070609 100%)!important;border:1px solid #7d263d!important;border-radius:18px!important;box-shadow:0 24px 80px rgba(0,0,0,.72),0 0 28px rgba(229,9,20,.16)!important;overflow:hidden}
#contactAdminModal .modal-header{background:linear-gradient(90deg,#3a101c,#170b11)!important;border-bottom:1px solid #7d263d!important;color:#fff!important}
#contactAdminModal .modal-title{color:#fff!important;font-weight:700}
#contactAdminModal .modal-body{background:radial-gradient(circle at 15% 10%,rgba(229,9,20,.13),transparent 32%),radial-gradient(circle at 85% 90%,rgba(255,179,0,.08),transparent 28%),#0a080b!important;padding:14px!important}
#contactAdminModal #adminChatMessages{background:linear-gradient(180deg,rgba(33,13,20,.94),rgba(8,7,10,.98))!important;border:1px solid #421827!important;border-radius:13px!important;min-height:280px;max-height:420px!important;padding:14px!important;scrollbar-color:#a52a4d #100b10}
#contactAdminModal #adminChatMessages>div{margin-bottom:10px!important}
#contactAdminModal #adminChatMessages .bg-primary{background:linear-gradient(135deg,#d81b45,#831b36)!important;border:1px solid #f08b9e!important;color:#fff!important;box-shadow:0 5px 14px rgba(216,27,69,.18)}
#contactAdminModal #adminChatMessages .bg-white{background:linear-gradient(135deg,#2b1820,#171015)!important;border:1px solid #6c3044!important;color:#ffeef2!important;box-shadow:0 5px 14px rgba(0,0,0,.22)}
#contactAdminModal #adminChatMessages small{color:rgba(255,255,255,.65)!important}
#contactAdminModal #adminChatForm{background:#160b11!important;border-top:1px solid #5d2034!important;padding-top:12px}
#contactAdminModal #adminChatForm input{background:#0c080c!important;color:#fff!important;border:1px solid #7d263d!important}
#contactAdminModal #adminChatForm input::placeholder{color:#c99aa6!important}
#contactAdminModal #adminChatForm button{background:linear-gradient(135deg,#d81b45,#831b36)!important;border-color:#f08b9e!important;color:#fff!important}
#contactAdminModal .btn-close{filter:invert(1);opacity:.85}
</style>

<style id="member-chat-reply-alert">
#userChatBell.chat-reply-unread{color:#ff6b88!important;filter:drop-shadow(0 0 7px rgba(255,72,112,.8));animation:memberChatBellPulse 1.5s ease-in-out infinite}
#userChatBell.chat-reply-unread i{animation:memberChatBellShake .8s ease-in-out infinite}
@keyframes memberChatBellPulse{0%,100%{opacity:1}50%{opacity:.62}}
@keyframes memberChatBellShake{0%,100%{transform:rotate(0)}25%{transform:rotate(-14deg)}75%{transform:rotate(14deg)}}
</style>

<style id="admin-chat-modern-ui">
#contactAdminFab{padding:11px 16px!important;background:linear-gradient(135deg,#ffb300,#e50914)!important;border:1px solid rgba(255,255,255,.22)!important;box-shadow:0 10px 28px rgba(229,9,20,.42)!important}
#contactAdminFab:hover{transform:translateY(-3px) scale(1.03)!important}
#contactAdminFab .contact-admin-badge{position:absolute;right:-7px;top:-8px;min-width:22px;height:22px;padding:2px 5px;border-radius:999px;background:#ff1744;color:#fff;font:700 12px/18px Arial,sans-serif;border:2px solid #080808;text-align:center}
#contactAdminModal .chat-modal-header{padding:14px 16px!important;background:linear-gradient(135deg,#3a101c,#160b11)!important}
.chat-admin-title{display:flex;align-items:center;gap:10px;color:#fff}.chat-admin-title small{display:block;color:#ffcf8a;font-size:11px;margin-top:2px}.chat-admin-avatar{display:grid;place-items:center;width:38px;height:38px;border-radius:13px;background:linear-gradient(135deg,#ffb300,#d81b45);color:#fff;font-size:18px}
#contactAdminModal .chat-modal-body{padding:12px!important;background:#08070a!important}.chat-reply-banner{display:flex;gap:8px;align-items:center;padding:8px 10px;margin-bottom:10px;border:1px solid rgba(255,179,0,.25);border-radius:10px;background:rgba(255,179,0,.08);color:#ffd166;font-size:11px}.chat-messages-box{height:340px;overflow:auto;background:radial-gradient(circle at 10% 0,rgba(216,27,69,.18),transparent 35%),#100b10!important;border:1px solid #542033;border-radius:14px;padding:14px!important;scrollbar-color:#a52a4d #100b10}
#contactAdminModal .chat-composer{background:#160b11!important;border-top:1px solid #5d2034}.chat-composer .modal-footer{gap:8px;padding:12px!important}.chat-composer input{background:#0b080c!important;color:#fff!important;border:1px solid #7d263d!important}.chat-composer button{border:0!important;background:linear-gradient(135deg,#d81b45,#831b36)!important}.chat-composer button i{margin-right:5px}
@media(max-width:480px){#contactAdminFab{padding:11px!important}.chat-messages-box{height:300px}.chat-reply-banner{font-size:10px}}
</style>
