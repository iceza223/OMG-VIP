<?php
declare(strict_types=1);

date_default_timezone_set('Asia/Bangkok');

const ADMIN_USERNAME = 'ADMINOMG';
const ADMIN_PASSWORD_HASH = '$2y$10$uzAJea8un0T4nac/MH0IsOrhhYo/DGGn/jjM/R56KNnp9Q2TKRUMq';
const MAX_FILE_SIZE = 500 * 1024 * 1024;
const DOWNLOAD_DIR = __DIR__ . DIRECTORY_SEPARATOR . 'files' . DIRECTORY_SEPARATOR;

const ALLOWED_EXTENSIONS = [
    'apk', 'zip', 'rar', '7z', 'pdf', 'txt',
    'jpg', 'jpeg', 'png', 'gif', 'webp',
    'mp4', 'mp3', 'm4a', 'mov', 'avi'
];

if (!is_dir(DOWNLOAD_DIR)) {
    mkdir(DOWNLOAD_DIR, 0755, true);
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
    session_start();
}
