<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/discord_webhook.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    header('Allow: POST');
    jsonResponse(405, ['ok' => false, 'error' => 'POST required']);
}

$providedKey = (string)($_SERVER['HTTP_X_NOTIFY_KEY'] ?? '');
if (NOTIFY_API_KEY === '' || $providedKey === '' || !hash_equals(NOTIFY_API_KEY, $providedKey)) {
    jsonResponse(401, ['ok' => false, 'error' => 'Unauthorized']);
}

try {
    $data = requestData();
    $type = cleanText($data['type'] ?? 'เว็บไซต์แจ้งเตือน', 100);
    $username = cleanText($data['username'] ?? 'ไม่ระบุ', 100);
    $email = cleanText($data['email'] ?? 'ไม่ระบุ', 254);
    $product = cleanText($data['product'] ?? 'ไม่ระบุ', 200);
    $amount = cleanText($data['amount'] ?? 'ไม่ระบุ', 100);
    $message = cleanText($data['message'] ?? '-', 1000);

    if ($email !== 'ไม่ระบุ' && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email = 'รูปแบบอีเมลไม่ถูกต้อง';
    }

    $webhook = new DiscordWebhook(DISCORD_WEBHOOK_URL);
    $webhook->sendEmbed($type, $message, [
        ['name' => 'ผู้ใช้', 'value' => $username, 'inline' => true],
        ['name' => 'สินค้า', 'value' => $product, 'inline' => true],
        ['name' => 'อีเมล', 'value' => $email, 'inline' => true],
        ['name' => 'จำนวนเงิน', 'value' => $amount, 'inline' => true],
    ]);

    jsonResponse(200, ['ok' => true, 'message' => 'ส่งการแจ้งเตือนแล้ว']);
} catch (Throwable $e) {
    error_log('[discord-notify] ' . $e->getMessage());
    jsonResponse(502, ['ok' => false, 'error' => 'ส่งการแจ้งเตือนไม่สำเร็จ']);
}
