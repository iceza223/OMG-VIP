<?php
// Apache จะคงสถานะ 403 ของคำขอเดิมไว้เมื่อเรียกไฟล์นี้เป็น ErrorDocument
?>
<!DOCTYPE html>
<html lang="th">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>403 Forbidden - OMGVIP</title>

<style>
*{
    box-sizing:border-box;
}

body{
    margin:0;
    min-height:100vh;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:20px;
    font-family:Arial,sans-serif;
    color:#fff;
    background:
        radial-gradient(circle at top,#450000,#160000 40%,#050505 80%);
}

.popup{
    width:100%;
    max-width:430px;
    padding:35px 25px;
    text-align:center;
    border-radius:25px;
    background:rgba(15,15,15,.95);
    border:1px solid rgba(255,40,40,.45);
    box-shadow:
        0 0 25px rgba(255,0,0,.25),
        0 0 70px rgba(255,0,0,.12);
    animation:show .4s ease;
}

@keyframes show{
    from{
        opacity:0;
        transform:scale(.75);
    }
    to{
        opacity:1;
        transform:scale(1);
    }
}

.icon{
    width:85px;
    height:85px;
    margin:0 auto 18px;
    display:flex;
    align-items:center;
    justify-content:center;
    border-radius:50%;
    font-size:42px;
    background:linear-gradient(145deg,#700000,#ff2222);
    box-shadow:0 0 30px rgba(255,0,0,.55);
}

h1{
    margin:0;
    font-size:36px;
    color:#ff3636;
    text-shadow:0 0 15px red;
}

.subtitle{
    margin-top:8px;
    font-size:19px;
    font-weight:bold;
}

.message{
    margin-top:12px;
    color:#999;
    line-height:1.7;
}

.code{
    display:inline-block;
    margin-top:15px;
    padding:7px 15px;
    border-radius:20px;
    background:#280000;
    color:#ff4d4d;
    border:1px solid #650000;
    font-weight:bold;
}

.back{
    display:block;
    width:100%;
    margin-top:25px;
    padding:15px;
    border-radius:12px;
    text-decoration:none;
    color:#fff;
    font-size:17px;
    font-weight:bold;
    background:linear-gradient(90deg,#a90000,#ff3030);
    box-shadow:0 0 18px rgba(255,0,0,.25);
}

.brand{
    margin-top:20px;
    font-size:12px;
    color:#555;
}
</style>
</head>

<body>

<div class="popup">

    <div class="icon">🔒</div>

    <h1>403</h1>

    <div class="subtitle">
        Forbidden
    </div>

    <div class="message">
        ไม่พบไฟล์หรือคุณไม่มีสิทธิ์เข้าถึงหน้านี้
        <br>
        กรุณากลับไปยังหน้าแรก
    </div>

    <div class="code">
        ACCESS DENIED
    </div>

    <a
        href="https://omgvip.shop/"
        class="back"
    >
        🏠 กลับไปหน้าแรก
    </a>

    <div class="brand">
        OMGVIP • ADMIN FILE MANAGER
    </div>

</div>

</body>
</html>
