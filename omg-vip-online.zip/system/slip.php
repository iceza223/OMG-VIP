<?php
error_reporting(0);
header('Content-Type: application/json; charset=utf-8');
require_once './a_func.php';
function slip_respond($ok,$msg,$data=[]){http_response_code($ok?200:400);exit(json_encode(['status'=>$ok?'success':'error','message'=>$msg,'data'=>$data],JSON_UNESCAPED_UNICODE));}
if($_SERVER['REQUEST_METHOD']!=='POST') slip_respond(false,'Method not allowed');
if(!isset($_SESSION['id'])) slip_respond(false,'กรุณาเข้าสู่ระบบก่อน');
$bank=dd_q('SELECT * FROM bank LIMIT 1'); if(!$bank||!$bank->fetch(PDO::FETCH_ASSOC)) slip_respond(false,'ระบบธนาคารยังไม่ได้ตั้งค่า');
$userq=dd_q('SELECT id,username FROM users WHERE id=? LIMIT 1',[$_SESSION['id']]); $usr=$userq?$userq->fetch(PDO::FETCH_ASSOC):false; if(!$usr) slip_respond(false,'ไม่พบข้อมูลผู้ใช้');
if(!isset($_FILES['slip_image'])) slip_respond(false,'ไม่พบไฟล์สลิปที่ส่งมา กรุณาเลือกรูปใหม่');
$uploadError=(int)$_FILES['slip_image']['error'];
if($uploadError!==UPLOAD_ERR_OK){
    $uploadMsg=[UPLOAD_ERR_INI_SIZE=>'ไฟล์มีขนาดใหญ่เกินข้อจำกัดของเซิร์ฟเวอร์',UPLOAD_ERR_FORM_SIZE=>'ไฟล์มีขนาดใหญ่เกินกำหนด',UPLOAD_ERR_PARTIAL=>'อัปโหลดไฟล์ไม่ครบ กรุณาลองใหม่',UPLOAD_ERR_NO_FILE=>'กรุณาแนบไฟล์สลิป',UPLOAD_ERR_NO_TMP_DIR=>'เซิร์ฟเวอร์ไม่มีโฟลเดอร์ชั่วคราว',UPLOAD_ERR_CANT_WRITE=>'เซิร์ฟเวอร์ไม่สามารถเขียนไฟล์ได้'];
    slip_respond(false,$uploadMsg[$uploadError]??'ไม่สามารถอัปโหลดไฟล์สลิปได้');
}
$file=$_FILES['slip_image']; if((int)$file['size']>5*1024*1024) slip_respond(false,'ไฟล์สลิปต้องมีขนาดไม่เกิน 5MB');
$mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']); $allowed=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp']; if(!isset($allowed[$mime])) slip_respond(false,'รองรับเฉพาะไฟล์ JPG, PNG หรือ WEBP');
$amount=(float)($_POST['amount']??0); $ref=trim((string)($_POST['ref']??'')); if($amount<=0) slip_respond(false,'จำนวนเงินไม่ถูกต้อง'); if(!preg_match('/^[A-Za-z0-9._-]{6,80}$/',$ref)) slip_respond(false,'เลขอ้างอิงสลิปไม่ถูกต้อง');
$hash=hash_file('sha256',$file['tmp_name']);
dd_q("CREATE TABLE IF NOT EXISTS slip_requests (id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,username VARCHAR(255) NOT NULL,amount DECIMAL(10,2) NOT NULL,ref VARCHAR(255) NOT NULL,image_hash CHAR(64) NOT NULL,image_path VARCHAR(500) NOT NULL,status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',admin_note VARCHAR(500) NOT NULL DEFAULT '',created_at DATETIME NOT NULL,reviewed_at DATETIME NULL,reviewed_by VARCHAR(255) NOT NULL DEFAULT '',INDEX(status),INDEX(ref),INDEX(image_hash),INDEX(user_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
$dup=dd_q("SELECT id FROM slip_requests WHERE (ref=? OR image_hash=?) AND status IN ('pending','approved') LIMIT 1",[$ref,$hash]); if($dup&&$dup->fetch(PDO::FETCH_ASSOC)) slip_respond(false,'สลิปหรือเลขอ้างอิงนี้ถูกส่งตรวจสอบแล้ว');
$dup2=dd_q('SELECT id FROM kbank_trans WHERE ref=? OR qr=? LIMIT 1',[$ref,$hash]); if($dup2&&$dup2->fetch(PDO::FETCH_ASSOC)) slip_respond(false,'สลิปนี้ถูกใช้งานไปแล้ว');
$dir=dirname(__DIR__).'/assets/uploads/slips'; if(!is_dir($dir)&&!@mkdir($dir,0755,true)) slip_respond(false,'ไม่สามารถเตรียมพื้นที่เก็บสลิปได้');
$name=date('YmdHis').'_'.bin2hex(random_bytes(6)).'.'.$allowed[$mime]; $target=$dir.'/'.$name; if(!move_uploaded_file($file['tmp_name'],$target)) slip_respond(false,'ไม่สามารถบันทึกไฟล์สลิปได้');
$path='assets/uploads/slips/'.$name; $ins=dd_q('INSERT INTO slip_requests (user_id,username,amount,ref,image_hash,image_path,status,created_at) VALUES (?,?,?,?,?,?,\'pending\',NOW())',[(int)$usr['id'],$usr['username'],$amount,$ref,$hash,$path]);
if(!$ins){@unlink($target);slip_respond(false,'ไม่สามารถบันทึกคำขอตรวจสอบได้');}
slip_respond(true,'ส่งสลิปเรียบร้อยแล้ว กรุณารอแอดมินตรวจสอบภายใน 24 ชั่วโมง',['ref'=>$ref]);
