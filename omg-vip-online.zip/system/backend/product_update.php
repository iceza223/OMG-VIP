<?php
error_reporting(E_ALL);
ini_set('display_errors', '0');

require_once '../a_func.php';

function dd_return($status, $message)
{
    http_response_code($status ? 200 : 400);
    header('Content-Type: application/json; charset=utf-8');
    exit(json_encode(['message' => $message], JSON_UNESCAPED_UNICODE));
}

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}

if (!isset($_SESSION['id'])) {
    dd_return(false, 'เข้าสู่ระบบก่อน');
}

$admin = dd_q('SELECT id FROM users WHERE id = ? AND rank = 1 LIMIT 1', [(int) $_SESSION['id']]);
if (!$admin || $admin->rowCount() < 1) {
    session_destroy();
    dd_return(false, 'เซสชั่นผิดพลาด โปรดล็อกอินใหม่');
}

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$name = trim((string) ($_POST['name'] ?? ''));
$image = trim((string) ($_POST['img'] ?? ''));
$price_raw = trim((string) ($_POST['price'] ?? ''));
$description = trim((string) ($_POST['des'] ?? ''));
$type_raw = trim((string) ($_POST['type'] ?? ''));
$category = trim((string) ($_POST['c_type'] ?? ''));

if ($id === false || $name === '' || $image === '' || $price_raw === '' || $description === '' || $type_raw === '' || $category === '') {
    dd_return(false, 'กรุณากรอกข้อมูลให้ครบทุกช่อง');
}

if (!is_numeric($price_raw) || (float) $price_raw < 0) {
    dd_return(false, 'กรุณาระบุราคาเป็นตัวเลขที่ไม่ติดลบ');
}

if (!in_array($type_raw, ['0', '1'], true)) {
    dd_return(false, 'ประเภทการแจกไม่ถูกต้อง');
}

if (strlen($name) > 255 || strlen($image) > 255 || strlen($description) > 1000 || strlen($category) > 225) {
    dd_return(false, 'ข้อมูลยาวเกินขนาดที่ระบบรองรับ');
}

$price = (int) round((float) $price_raw);
$type = (int) $type_raw;
$description = preg_replace('~\R~u', "\n", $description) ?? $description;

$update = dd_q(
    'UPDATE box_product SET name = ?, img = ?, price = ?, des = ?, type = ?, c_type = ? WHERE id = ?',
    [$name, $image, $price, $description, $type, $category, $id]
);

if (!$update) {
    dd_return(false, 'SQL ผิดพลาด ไม่สามารถแก้ไขสินค้าได้');
}

dd_return(true, 'บันทึกสำเร็จ');
?>
