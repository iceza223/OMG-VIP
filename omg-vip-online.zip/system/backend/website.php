<?php
error_reporting(0);
ini_set('display_errors', '0');

require_once '../a_func.php';

function dd_return($status, $message)
{
    $json = ['message' => $message];
    if ($status) {
        http_response_code(200);
        die(json_encode($json));
    } else {
        http_response_code(400);
        die(json_encode($json));
    }
}

//////////////////////////////////////////////////////////////////////////

header('Content-Type: application/json; charset=utf-8;');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['id'])) {

        if ($_POST['name'] != "" AND $_POST['logo'] != "" AND $_POST['bg'] != "" AND $_POST['phone'] != "" AND $_POST['main_color'] != "" AND $_POST['sec_color'] != "" AND $_POST['des'] != "") {
            $q_1 = dd_q('SELECT * FROM users WHERE id = ? AND rank = 1 ', [$_SESSION['id']]);
            if ($q_1->rowCount() >= 1) {
                // Auto-migrate settings columns so older installations can save new switches safely.
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS how_to_text TEXT");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS rules_text TEXT");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS announcement_status ENUM('on','off') NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS stats_status ENUM('on','off') NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS discord_topup_notify ENUM('on','off') NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS discord_purchase_notify ENUM('on','off') NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS topup_card_status ENUM('on','off') NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS text_color VARCHAR(7) NOT NULL DEFAULT '#fff6df'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS font_family VARCHAR(40) NOT NULL DEFAULT 'kanit'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS font_size INT NOT NULL DEFAULT 16");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS border_color VARCHAR(7) NOT NULL DEFAULT '#6b2145'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS bg_color VARCHAR(7) NOT NULL DEFAULT '#08070a'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS card_color VARCHAR(7) NOT NULL DEFAULT '#160d17'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS button_color VARCHAR(7) NOT NULL DEFAULT '#ffb300'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS success_color VARCHAR(7) NOT NULL DEFAULT '#b8d82e'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS warning_color VARCHAR(7) NOT NULL DEFAULT '#ffb300'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS danger_color VARCHAR(7) NOT NULL DEFAULT '#ef476f'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS info_color VARCHAR(7) NOT NULL DEFAULT '#ff944d'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS rain_enabled VARCHAR(3) NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS rain_density INT NOT NULL DEFAULT 70");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS glow_enabled VARCHAR(3) NOT NULL DEFAULT 'on'");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS glow_speed INT NOT NULL DEFAULT 5");
                dd_q("ALTER TABLE setting ADD COLUMN IF NOT EXISTS chat_status ENUM('on','off') NOT NULL DEFAULT 'on'");
                $allowed_fonts = ['kanit', 'prompt', 'sarabun', 'ibm_plex_sans_thai'];
                $font_family = in_array($_POST['font_family'] ?? '', $allowed_fonts, true) ? $_POST['font_family'] : 'kanit';
                $font_size = (int) ($_POST['font_size'] ?? 16);
                $font_size = max(14, min(20, $font_size));
                $des = preg_replace('~\R~u', "\n", $_POST['des']);
                $text_color = $_POST['text_color'] ?? '#fff6df';
                if (!preg_match('/^#[0-9a-fA-F]{6}$/', $text_color)) {
                    $text_color = '#fff6df';
                }
                $border_color = $_POST['border_color'] ?? '#6b2145';
                if (!preg_match('/^#[0-9a-fA-F]{6}$/', $border_color)) {
                    $border_color = '#6b2145';
                }
                $extra_colors = [
                    'bg_color' => '#08070a',
                    'card_color' => '#160d17',
                    'button_color' => '#ffb300',
                    'success_color' => '#b8d82e',
                    'warning_color' => '#ffb300',
                    'danger_color' => '#ef476f',
                    'info_color' => '#ff944d',
                ];
                foreach ($extra_colors as $color_key => $color_fallback) {
                    $color_value = $_POST[$color_key] ?? $color_fallback;
                    $extra_colors[$color_key] = preg_match('/^#[0-9a-fA-F]{6}$/', $color_value) ? $color_value : $color_fallback;
                }
                $theme_mode = $_POST['theme_mode'] ?? 'light';
                $rain_enabled = ($_POST['rain_enabled'] ?? 'off') === 'on' ? 'on' : 'off';
                $rain_density = max(20, min(130, (int)($_POST['rain_density'] ?? 70)));
                $glow_enabled = ($_POST['glow_enabled'] ?? 'off') === 'on' ? 'on' : 'off';
                $glow_speed = max(1, min(10, (int)($_POST['glow_speed'] ?? 5)));
                $chat_status = ($_POST['chat_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $topup_gift_status = ($_POST['topup_gift_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $topup_redeem_status = ($_POST['topup_redeem_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $topup_slip_status = ($_POST['topup_slip_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $topup_promptpay_status = ($_POST['topup_promptpay_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $topup_card_status = ($_POST['topup_card_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $discord_widget_status = ($_POST['discord_widget_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $discord_topup_notify = ($_POST['discord_topup_notify'] ?? 'on') === 'on' ? 'on' : 'off';
                $discord_purchase_notify = ($_POST['discord_purchase_notify'] ?? 'on') === 'on' ? 'on' : 'off';
                $how_to_text = preg_replace('~\R~u', "\n", $_POST['how_to_text'] ?? '');
                $rules_text = preg_replace('~\R~u', "\n", $_POST['rules_text'] ?? '');
                $announcement_status = ($_POST['announcement_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $stats_status = ($_POST['stats_status'] ?? 'off') === 'on' ? 'on' : 'off';
                $insert = dd_q("UPDATE setting SET 
                    name = ? , bg = ? , wallet = ? , main_color  = ? , 
                    sec_color = ? , border_color = ?, text_color = ?, bg_color = ?, card_color = ?, button_color = ?, success_color = ?, warning_color = ?, danger_color = ?, info_color = ?, font_family = ?, font_size = ?, contact = ? , des = ? , logo = ?, ann = ? , fee = ? , webhook_dc = ?, discord_server = ?, discord_topup_notify = ?, discord_purchase_notify = ?, theme_mode = ?,
                    topup_gift_status = ?, topup_redeem_status = ?, topup_slip_status = ?, topup_promptpay_status = ?, topup_card_status = ?,
                    contact_facebook = ?, contact_line = ?, contact_discord = ?, contact_messenger = ?,
                    contact_telegram1 = ?, contact_telegram2 = ?,
                    discord_widget_status = ?, how_to_text = ?, rules_text = ?,
                    announcement_status = ?, stats_status = ?, rain_enabled = ?, rain_density = ?, glow_enabled = ?, glow_speed = ?, chat_status = ?
                ", [
                    $_POST['name'],
                    $_POST['bg'],
                    $_POST['phone'],
                    in_array([strtolower($_POST['main_color']), strtolower($_POST['sec_color'])], [
                        ['#2563eb', '#06b6d4'],
                        ['#00d4ff', '#ff0080'],
                        ['#ff0000', '#ff0000'],
                        ['#facc15', '#16a34a'],
                    ], true) ? '#ffb300' : $_POST['main_color'],
                    in_array([strtolower($_POST['main_color']), strtolower($_POST['sec_color'])], [
                        ['#2563eb', '#06b6d4'],
                        ['#00d4ff', '#ff0080'],
                        ['#ff0000', '#ff0000'],
                        ['#facc15', '#16a34a'],
                    ], true) ? '#ff6d00' : $_POST['sec_color'],
                    $border_color,
                    $text_color,
                    $extra_colors['bg_color'],
                    $extra_colors['card_color'],
                    $extra_colors['button_color'],
                    $extra_colors['success_color'],
                    $extra_colors['warning_color'],
                    $extra_colors['danger_color'],
                    $extra_colors['info_color'],
                    $font_family,
                    $font_size,
                    $_POST['contact'],
                    $des,
                    $_POST['logo'],
                    $_POST['ann'],
                    $_POST['fee'],
                    $_POST['webhook_dc'],
                    $_POST['discord_server'] ?? '',
                    $discord_topup_notify,
                    $discord_purchase_notify,
                    $theme_mode,
                    $topup_gift_status,
                    $topup_redeem_status,
                    $topup_slip_status,
                    $topup_promptpay_status,
                    $topup_card_status,
                    $_POST['contact_facebook'],
                    $_POST['contact_line'],
                    $_POST['contact_discord'],
                    $_POST['contact_messenger'],
                    $_POST['contact_telegram1'],
                    $_POST['contact_telegram2'],
                    $discord_widget_status,
                    $how_to_text,
                    $rules_text,
                    $announcement_status,
                    $stats_status,
                    $rain_enabled,
                    $rain_density,
                    $glow_enabled,
                    $glow_speed,
                    $chat_status
                ]);

                if ($insert) {
                    dd_return(true, "บันทึกสำเร็จ");
                } else {
                    dd_return(false, "SQL ผิดพลาด");
                }
            } else {
                dd_return(false, "เซสชั่นผิดพลาด โปรดล็อกอินใหม่");
                session_destroy();
            }
        } else {
            dd_return(false, "กรุณากรอกข้อมูลให้ครบ");
        }
    } else {
        dd_return(false, "เข้าสู่ระบบก่อน");
    }
} else {
    dd_return(false, "Method '{$_SERVER['REQUEST_METHOD']}' not allowed!");
}
?>
