<?php
require_once '../a_func.php';
header('Content-Type: application/json; charset=utf-8');

function admin_pin_response(bool $ok, string $message): void {
    http_response_code($ok ? 200 : 400);
    echo json_encode(['status' => $ok ? 'success' : 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_SESSION['id'])) {
    admin_pin_response(false, 'กรุณาเข้าสู่ระบบก่อน');
}
$admin = dd_q('SELECT rank FROM users WHERE id = ? LIMIT 1', [$_SESSION['id']]);
$admin_row = $admin ? $admin->fetch(PDO::FETCH_ASSOC) : false;
if (!$admin_row || (string) ($admin_row['rank'] ?? '') !== '1') {
    admin_pin_response(false, 'ไม่มีสิทธิ์ดำเนินการ');
}
$current = preg_replace('/\D+/', '', (string) ($_POST['current_pin'] ?? ''));
$new = preg_replace('/\D+/', '', (string) ($_POST['new_pin'] ?? ''));
$confirm = preg_replace('/\D+/', '', (string) ($_POST['confirm_pin'] ?? ''));
if (!preg_match('/^\d{6}$/', $current) || !preg_match('/^\d{6}$/', $new) || $new !== $confirm) {
    admin_pin_response(false, 'PIN ต้องเป็นตัวเลข 6 หลัก และต้องยืนยันให้ตรงกัน');
}
$pin_file = dirname(__DIR__, 2) . '/admin_pin_config.php';
$admin_pin_hash = '';
if (is_file($pin_file)) {
    require $pin_file;
}
if (!is_string($admin_pin_hash) || !hash_equals($admin_pin_hash, hash('sha256', $current))) {
    admin_pin_response(false, 'PIN ปัจจุบันไม่ถูกต้อง');
}
$contents = "<?php\n// Admin PIN hash.\n\$admin_pin_hash = '" . hash('sha256', $new) . "';\n";
if (@file_put_contents($pin_file, $contents, LOCK_EX) === false) {
    admin_pin_response(false, 'ไม่สามารถบันทึก PIN ได้ กรุณาตรวจสอบสิทธิ์ไฟล์');
}
$_SESSION['admin_pin_verified'] = true;
admin_pin_response(true, 'เปลี่ยน PIN 6 หลักสำเร็จ');
