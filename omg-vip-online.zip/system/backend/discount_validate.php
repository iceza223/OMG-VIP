<?php
header('Content-Type: application/json; charset=utf-8');
require_once '../../system/a_func.php';

function discount_validate_error($message)
{
    echo json_encode(['status' => 'error', 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

$code = strtoupper(preg_replace('/\s+/', '', trim((string) ($_POST['code'] ?? ''))));
$total = max(0, (float) ($_POST['total'] ?? 0));

if ($code === '') {
    discount_validate_error('กรุณากรอกโค้ดส่วนลด');
}
if (!preg_match('/^[A-Z0-9_-]{3,50}$/', $code)) {
    discount_validate_error('รูปแบบโค้ดส่วนลดไม่ถูกต้อง');
}

$result = dd_q('SELECT * FROM discount_codes WHERE code = ? AND is_active = 1 LIMIT 1', [$code]);
if (!$result || $result->rowCount() === 0) {
    discount_validate_error('ไม่พบโค้ดส่วนลดนี้ หรือโค้ดถูกปิดใช้งาน');
}

$discount = $result->fetch(PDO::FETCH_ASSOC);
$today = date('Y-m-d');

if ($discount['usage_limit'] !== null && (int) $discount['used_count'] >= (int) $discount['usage_limit']) {
    discount_validate_error('โค้ดนี้ถูกใช้ครบจำนวนแล้ว');
}
if ($total < (float) $discount['min_purchase']) {
    discount_validate_error('ยอดซื้อขั้นต่ำ ' . number_format((float) $discount['min_purchase'], 2) . ' บาท');
}
if ($discount['start_date'] && $today < $discount['start_date']) {
    discount_validate_error('โค้ดยังไม่เริ่มใช้งาน');
}
if ($discount['end_date'] && $today > $discount['end_date']) {
    discount_validate_error('โค้ดหมดอายุแล้ว');
}

if (isset($_SESSION['id'])) {
    $used = dd_q('SELECT id FROM discount_usage WHERE code_id = ? AND user_id = ? LIMIT 1', [$discount['id'], $_SESSION['id']]);
    if ($used && $used->rowCount() > 0) {
        discount_validate_error('คุณเคยใช้โค้ดนี้แล้ว');
    }
}

if ($discount['discount_type'] === 'percent') {
    $discount_amount = ($total * (float) $discount['discount_value']) / 100;
    if ($discount['max_discount'] !== null) {
        $discount_amount = min($discount_amount, (float) $discount['max_discount']);
    }
    $discount_text = rtrim(rtrim(number_format((float) $discount['discount_value'], 2, '.', ''), '0'), '.') . '%';
} else {
    $discount_amount = (float) $discount['discount_value'];
    $discount_text = '฿' . number_format($discount_amount, 2);
}

$discount_amount = min(max(0, $discount_amount), $total);
$final_total = max(0, $total - $discount_amount);

echo json_encode([
    'status' => 'success',
    'message' => 'ใช้โค้ดสำเร็จ!',
    'discount_id' => (int) $discount['id'],
    'discount_text' => $discount_text,
    'discount_amount' => round($discount_amount, 2),
    'final_total' => round($final_total, 2)
], JSON_UNESCAPED_UNICODE);
