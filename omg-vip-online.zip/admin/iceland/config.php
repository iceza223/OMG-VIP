<?php
/* =========================================
   OMGVIP - Iceland File Manager
   Database Configuration
========================================= */

declare(strict_types=1);

date_default_timezone_set('Asia/Bangkok');

/* ---------- MySQL ---------- */
$db_host = 'localhost';
$db_name = 'zl4gomgvipon_catullusshop';
$db_user = 'zl4gomgvipon_catullusshop';
$db_pass = 'Lk9SnQ9VDHsPrQTpXrvp';

try {
    $pdo = new PDO(
        "mysql:host={$db_host};dbname={$db_name};charset=utf8mb4",
        $db_user,
        $db_pass,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('ไม่สามารถเชื่อมต่อฐานข้อมูลได้');
}


/* ---------- Admin ---------- */
/*
   แนะนำให้เปลี่ยนค่าทั้งสองก่อนใช้งานจริง
*/
const ADMIN_USERNAME = 'ADMINOMG';
const ADMIN_PASSWORD = 'ICEZA2545';


/* ---------- Upload ---------- */

define('UPLOAD_DIR', __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR);

if (!is_dir(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

/*
   URL ของโฟลเดอร์ระบบ
   ตัวอย่าง:
   https://omgvip.shop/admin/iceland
*/
define(
    'BASE_URL',
    'https://omgvip.shop/admin/iceland'
);


/* ---------- Upload limit ---------- */

define('MAX_FILE_SIZE', 500 * 1024 * 1024); // 500 MB


/*
   นามสกุลไฟล์ที่อนุญาต
   เพิ่ม/ลบได้ตามต้องการ
*/
const ALLOWED_EXTENSIONS = [
    'apk',
    'zip',
    'rar',
    '7z',
    'pdf',
    'txt',
    'jpg',
    'jpeg',
    'png',
    'gif',
    'webp',
    'mp4',
    'mp3'
];
