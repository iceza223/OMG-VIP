<?php
declare(strict_types=1);

// Rename this file to config.php and never expose it publicly.
const DISCORD_WEBHOOK_URL = 'https://discord.com/api/webhooks/REPLACE_ID/REPLACE_TOKEN';
const NOTIFY_API_KEY = 'replace-with-a-long-random-secret';
