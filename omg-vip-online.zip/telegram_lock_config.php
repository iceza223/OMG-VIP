<?php
declare(strict_types=1);

const TELEGRAM_BOT_TOKEN = '8925159583:AAHvevM9hOTINK648AjP0hYCpsK_JdiD9Q8';
const TELEGRAM_ADMIN_ID = 6654447461;
const TELEGRAM_WEBHOOK_SECRET = 'omgvip-lock-2026-6654447461';
const TELEGRAM_LOCK_STATE_FILE = __DIR__ . '/system/telegram_lock_state.json';
