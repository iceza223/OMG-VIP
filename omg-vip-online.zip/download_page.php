<?php
$download_versions = [
    [
        'version' => 'V2',
        'image' => 'https://omgvip.shop/download/files/5980502dfad2b123_v2.png',
        'url' => 'https://www.mediafire.com/file/7mi3ohtegjbv69t/THLIVE-OMG.apk/file',
    ],
    [
        'version' => 'V3',
        'image' => 'https://omgvip.shop/download/files/4393b2c44e9e2533_v3.png',
        'url' => 'https://www.mediafire.com/file/exexp44h0809v51/THLIVE-OMGMOD_V3.apk/file',
    ],
    [
        'version' => 'V4',
        'image' => 'https://omgvip.shop/View/thlive-omgmod-v4.png',
        'url' => 'https://www.mediafire.com/file/70kjtfy5hkev69h/THLIVE-OMGMOD_4.apk/file',
    ],
];
?>
<style>
.download-page{max-width:760px;margin:28px auto 48px;padding:0 14px;color:#fff}
.download-hero{text-align:center;padding:24px 18px;border-radius:20px;background:linear-gradient(145deg,#21170a,#090806);border:1px solid #d3a329;box-shadow:0 0 24px rgba(255,193,7,.2)}
.download-hero h1{margin:0;color:#ffe45c;font-weight:900;font-size:clamp(24px,5vw,38px)}
.download-hero .subtitle{margin:8px 0 0;color:#d8cba8}
.download-hero .notice{margin:12px 0 0;color:#ffe36a;font-weight:700;line-height:1.8}
.code-box{margin:18px 0 22px;padding:18px 12px;text-align:center;border:1px solid #d3a329;border-radius:16px;background:linear-gradient(135deg,#241a08,#100d08);box-shadow:0 0 20px rgba(255,174,0,.14)}
.code-box h2{margin:0;color:#ffe36a;font-size:clamp(19px,4vw,27px);font-weight:900}
.code-label{display:inline-block;margin:12px 0 10px;padding:6px 16px;border-radius:999px;background:#ffe45c;color:#241500;font-size:17px;font-weight:900;box-shadow:0 0 14px rgba(255,212,71,.5)}
.example-code{display:inline-block;padding:12px 20px;border:2px solid #ffe45c;border-radius:12px;background:linear-gradient(135deg,#211500,#4a2d00);color:#fff3a3;font-size:clamp(22px,5vw,30px);font-weight:900;letter-spacing:1.5px;text-shadow:0 0 10px rgba(255,228,92,.75);box-shadow:0 0 22px rgba(255,193,7,.45)}
.download-card{margin:18px 0;padding:10px;border:1px solid #624813;border-radius:16px;background:#100d08;box-shadow:0 8px 25px rgba(0,0,0,.35)}
.download-card img{display:block;width:100%;height:auto;border-radius:11px}
.download-card h3{text-align:center;color:#ffe36a;font-size:20px;font-weight:900;margin:12px 0}
.download-btn{display:block;text-align:center;padding:14px;border-radius:11px;background:linear-gradient(115deg,#8ec400,#ffd447,#ff4a17);color:#130d02!important;text-decoration:none!important;font-size:18px;font-weight:900}
</style>
<section class="download-page">
  <div class="download-hero">
    <h1>ดาวโหลดแอปTHLIVEMOD</h1>
    <p class="subtitle">หน้าดาวน์โหลดสำหรับมือถือ</p>
    <p class="notice">-ใช้ V2 ฟรี<br>- (V3-V4 แก้ไม่ให้พิม)</p>
  </div>
  <div class="code-box">
    <h2>🔑 รหัสใหม่ใช้ได้ทุกเวอร์ชั่น</h2>
    <div class="code-label">ตัวอย่างรหัส</div><br>
    <div class="example-code">OMG-ABCD-1234</div>
  </div>
  <?php foreach ($download_versions as $item): ?>
    <article class="download-card">
      <img src="<?= htmlspecialchars($item['image'], ENT_QUOTES, 'UTF-8') ?>" alt="THLIVE-OMGMOD <?= htmlspecialchars($item['version'], ENT_QUOTES, 'UTF-8') ?>">
      <h3>THLIVE-OMGMOD <?= htmlspecialchars($item['version'], ENT_QUOTES, 'UTF-8') ?></h3>
      <a class="download-btn" href="<?= htmlspecialchars($item['url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener noreferrer">⬇️ ดาวน์โหลด <?= htmlspecialchars($item['version'], ENT_QUOTES, 'UTF-8') ?></a>
    </article>
  <?php endforeach; ?>
</section>
